#include "stm32f10x.h"
#include "Delay.h"

/*
 * STM32F103 / Cortex-M3 DWT cycle-counter delay.
 * Use architectural register addresses directly because some older
 * STM32F10x CMSIS headers do not declare the DWT symbol.
 * SysTick is left untouched.
 */
#define DELAY_DEMCR       (*((volatile uint32_t *)0xE000EDFCUL))
#define DELAY_DWT_CTRL    (*((volatile uint32_t *)0xE0001000UL))
#define DELAY_DWT_CYCCNT  (*((volatile uint32_t *)0xE0001004UL))

#define DELAY_TRCENA      (1UL << 24)
#define DELAY_CYCCNTENA   (1UL << 0)

extern uint32_t SystemCoreClock;

static uint8_t s_dwt_initialized = 0U;

/* Initialize the Cortex-M3 DWT cycle counter once. */
static uint8_t Delay_DWT_Init(void)
{
    if (s_dwt_initialized != 0U)
    {
        return 1U;
    }

    DELAY_DEMCR |= DELAY_TRCENA;
    DELAY_DWT_CYCCNT = 0U;
    DELAY_DWT_CTRL |= DELAY_CYCCNTENA;

    if ((DELAY_DWT_CTRL & DELAY_CYCCNTENA) == 0U)
    {
        return 0U;
    }

    s_dwt_initialized = 1U;
    return 1U;
}

/* Wait in chunks smaller than half the 32-bit counter range. */
static void Delay_WaitCycles(uint64_t cycles)
{
    uint32_t start;
    uint32_t chunk;

    while (cycles > 0ULL)
    {
        chunk = (cycles > 0x7FFFFFFFULL) ? 0x7FFFFFFFUL : (uint32_t)cycles;
        start = DELAY_DWT_CYCCNT;

        while ((uint32_t)(DELAY_DWT_CYCCNT - start) < chunk)
        {
            /* Busy wait. Interrupt execution time is included in the delay. */
        }

        cycles -= (uint64_t)chunk;
    }
}

static void Delay_ByUnit(uint32_t duration, uint32_t divisor)
{
    uint32_t core_clock;
    uint64_t cycles;

    if ((duration == 0U) || (divisor == 0U))
    {
        return;
    }

    if (Delay_DWT_Init() == 0U)
    {
        /* Do not silently return without delaying if DWT cannot be enabled. */
        /* The fallback uses SysTick only in this exceptional case. */
        while (duration > 0U)
        {
            uint32_t part = (duration > 1000U && divisor == 1000000UL) ? 1000U : duration;
            uint64_t us = (divisor == 1000UL) ? ((uint64_t)part * 1000ULL) : (uint64_t)part;
            while (us > 0ULL)
            {
                uint32_t this_us = (us > 233015ULL) ? 233015U : (uint32_t)us;
                SysTick->LOAD = (SystemCoreClock / 1000000UL) * this_us - 1UL;
                SysTick->VAL = 0U;
                SysTick->CTRL = 5UL;
                while ((SysTick->CTRL & (1UL << 16)) == 0UL) { }
                SysTick->CTRL = 4UL;
                us -= this_us;
            }
            duration -= part;
        }
        return;
    }

    core_clock = SystemCoreClock;
    if (core_clock == 0U)
    {
        return;
    }

    cycles = ((uint64_t)core_clock * (uint64_t)duration) / (uint64_t)divisor;
    Delay_WaitCycles(cycles);
}

void Delay_us(uint32_t xus)
{
    Delay_ByUnit(xus, 1000000UL);
}

void Delay_ms(uint32_t xms)
{
    Delay_ByUnit(xms, 1000UL);
}

void Delay_s(uint32_t xs)
{
    uint32_t core_clock;
    uint64_t cycles;

    if (xs == 0U)
    {
        return;
    }

    if (Delay_DWT_Init() == 0U)
    {
        while (xs > 0U)
        {
            Delay_ms(1000U);
            --xs;
        }
        return;
    }

    core_clock = SystemCoreClock;
    if (core_clock == 0U)
    {
        return;
    }

    cycles = (uint64_t)core_clock * (uint64_t)xs;
    Delay_WaitCycles(cycles);
}

/*
 * Super Mario Bros. (NES) - multi-level background music themes
 * STM32F103CBT6, passive buzzer on PA0 / TIM2_CH1
 *
 * Ground melody line converted from the supplied MIDI; other themes are
 * single-voice pitch transcriptions converted from user-supplied MP3 files.
 *
 * Assumptions:
 *   - STM32F103 system clock is 72 MHz (standard 8 MHz HSE x 9 setup).
 *   - PA0 is wired to a LOW-active passive buzzer driver.
 *   - Standard Peripheral Library (SPL) is used.
 */

/* 主程序说明：初始化外设，采用 DWT/SysTick 双时基调度，并启用 IWDG 防止死机。 */
#include "stm32f10x.h"
#include "PWM.h"
#include <stdint.h>

/*
 * 兼容部分较旧的 STM32F10x CMSIS 头文件：它们提供 CoreDebug，
 * 但没有声明 Cortex-M3 的 DWT 周期计数器。DWT 位于 ARM 固定系统
 * 控制空间地址 0xE0001000，CYCCNT 位于偏移 0x04。
 */
typedef struct
{
    volatile uint32_t CTRL;
    volatile uint32_t CYCCNT;
} Mario_DWT_Type;
#define MARIO_DWT ((Mario_DWT_Type *)0xE0001000UL)
#define MARIO_DWT_CTRL_CYCCNTENA (1UL << 0)

/* 独立看门狗寄存器：直接访问固定地址，不依赖 SPL 是否编译 IWDG 驱动源文件。 */
typedef struct
{
    volatile uint32_t KR;
    volatile uint32_t PR;
    volatile uint32_t RLR;
    volatile uint32_t SR;
} Mario_IWDG_Type;
#define MARIO_IWDG ((Mario_IWDG_Type *)0x40003000UL)
#define MARIO_RCC_CSR (*((volatile uint32_t *)0x40021024UL))
static uint8_t s_dwt_available = 0U;
static uint8_t s_watchdog_enabled = 0U;

/* 单音蜂鸣器音符：频率、发声时长、音符间隔，单位均为 Hz/ms。 */
typedef struct
{
    uint16_t frequency_hz;
    uint16_t duration_ms;
    uint16_t rest_ms;
} MusicNote;

static const MusicNote g_melody[] =
{
    {659, 107, 35}, /* MIDI 76 */
    {659, 107, 178}, /* MIDI 76 */
    {659, 107, 178}, /* MIDI 76 */
    {523, 107, 35}, /* MIDI 72 */
    {659, 106, 179}, /* MIDI 76 */
    {784, 106, 1035}, /* MIDI 79 */
    {523, 107, 321}, /* MIDI 72 */
    {392, 107, 321}, /* MIDI 67 */
    {330, 107, 321}, /* MIDI 64 */
    {440, 107, 178}, /* MIDI 69 */
    {494, 107, 178}, /* MIDI 71 */
    {466, 107, 35}, /* MIDI 70 */
    {440, 107, 178}, /* MIDI 69 */
    {392, 107, 106}, /* MIDI 67 */
    {659, 107, 71}, /* MIDI 76 */
    {784, 107, 72}, /* MIDI 79 */
    {880, 106, 179}, /* MIDI 81 */
    {698, 106, 37}, /* MIDI 77 */
    {784, 106, 178}, /* MIDI 79 */
    {659, 107, 178}, /* MIDI 76 */
    {523, 107, 35}, /* MIDI 72 */
    {587, 107, 35}, /* MIDI 74 */
    {494, 107, 321}, /* MIDI 71 */
    {523, 107, 321}, /* MIDI 72 */
    {392, 107, 321}, /* MIDI 67 */
    {330, 107, 321}, /* MIDI 64 */
    {440, 107, 178}, /* MIDI 69 */
    {494, 107, 178}, /* MIDI 71 */
    {466, 107, 35}, /* MIDI 70 */
    {440, 107, 178}, /* MIDI 69 */
    {392, 106, 107}, /* MIDI 67 */
    {659, 107, 71}, /* MIDI 76 */
    {784, 107, 72}, /* MIDI 79 */
    {880, 106, 179}, /* MIDI 81 */
    {698, 106, 37}, /* MIDI 77 */
    {784, 106, 178}, /* MIDI 79 */
    {659, 107, 178}, /* MIDI 76 */
    {523, 107, 35}, /* MIDI 72 */
    {587, 107, 35}, /* MIDI 74 */
    {494, 107, 607}, /* MIDI 71 */
    {784, 107, 35}, /* MIDI 79 */
    {740, 107, 35}, /* MIDI 78 */
    {698, 107, 35}, /* MIDI 77 */
    {622, 107, 178}, /* MIDI 75 */
    {659, 107, 178}, /* MIDI 76 */
    {415, 107, 35}, /* MIDI 68 */
    {440, 107, 35}, /* MIDI 69 */
    {523, 106, 179}, /* MIDI 72 */
    {440, 106, 37}, /* MIDI 69 */
    {523, 106, 37}, /* MIDI 72 */
    {587, 106, 322}, /* MIDI 74 */
    {784, 106, 35}, /* MIDI 79 */
    {740, 107, 35}, /* MIDI 78 */
    {698, 107, 35}, /* MIDI 77 */
    {622, 107, 178}, /* MIDI 75 */
    {659, 107, 178}, /* MIDI 76 */
    {1047, 107, 178}, /* MIDI 84 */
    {1047, 107, 35}, /* MIDI 84 */
    {1047, 107, 750}, /* MIDI 84 */
    {784, 107, 35}, /* MIDI 79 */
    {740, 107, 35}, /* MIDI 78 */
    {698, 107, 35}, /* MIDI 77 */
    {622, 107, 178}, /* MIDI 75 */
    {659, 107, 178}, /* MIDI 76 */
    {415, 107, 35}, /* MIDI 68 */
    {440, 107, 35}, /* MIDI 69 */
    {523, 106, 179}, /* MIDI 72 */
    {440, 106, 37}, /* MIDI 69 */
    {523, 106, 37}, /* MIDI 72 */
    {587, 106, 322}, /* MIDI 74 */
    {622, 106, 321}, /* MIDI 75 */
    {587, 107, 321}, /* MIDI 74 */
    {523, 107, 1321}, /* MIDI 72 */
    {784, 107, 35}, /* MIDI 79 */
    {740, 107, 35}, /* MIDI 78 */
    {698, 107, 35}, /* MIDI 77 */
    {622, 107, 178}, /* MIDI 75 */
    {659, 106, 179}, /* MIDI 76 */
    {415, 106, 37}, /* MIDI 68 */
    {440, 106, 37}, /* MIDI 69 */
    {523, 106, 179}, /* MIDI 72 */
    {440, 106, 35}, /* MIDI 69 */
    {523, 107, 35}, /* MIDI 72 */
    {587, 107, 321}, /* MIDI 74 */
    {784, 107, 35}, /* MIDI 79 */
    {740, 107, 35}, /* MIDI 78 */
    {698, 107, 35}, /* MIDI 77 */
    {622, 107, 178}, /* MIDI 75 */
    {659, 107, 178}, /* MIDI 76 */
    {1047, 107, 178}, /* MIDI 84 */
    {1047, 107, 35}, /* MIDI 84 */
    {1047, 107, 750}, /* MIDI 84 */
    {784, 107, 35}, /* MIDI 79 */
    {740, 106, 37}, /* MIDI 78 */
    {698, 107, 35}, /* MIDI 77 */
    {622, 106, 179}, /* MIDI 75 */
    {659, 106, 179}, /* MIDI 76 */
    {415, 106, 37}, /* MIDI 68 */
    {440, 106, 37}, /* MIDI 69 */
    {523, 106, 178}, /* MIDI 72 */
    {440, 107, 35}, /* MIDI 69 */
    {523, 107, 35}, /* MIDI 72 */
    {587, 107, 321}, /* MIDI 74 */
    {622, 107, 321}, /* MIDI 75 */
    {587, 107, 321}, /* MIDI 74 */
    {523, 107, 1035}, /* MIDI 72 */
    {523, 107, 35}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 106, 179}, /* MIDI 72 */
    {523, 106, 37}, /* MIDI 72 */
    {587, 106, 179}, /* MIDI 74 */
    {659, 106, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {440, 107, 35}, /* MIDI 69 */
    {392, 107, 464}, /* MIDI 67 */
    {523, 107, 35}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 107, 35}, /* MIDI 72 */
    {587, 107, 35}, /* MIDI 74 */
    {659, 107, 1178}, /* MIDI 76 */
    {523, 106, 37}, /* MIDI 72 */
    {523, 106, 179}, /* MIDI 72 */
    {523, 106, 179}, /* MIDI 72 */
    {523, 106, 35}, /* MIDI 72 */
    {587, 107, 178}, /* MIDI 74 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {440, 107, 35}, /* MIDI 69 */
    {392, 107, 464}, /* MIDI 67 */
    {659, 107, 35}, /* MIDI 76 */
    {659, 107, 178}, /* MIDI 76 */
    {659, 107, 178}, /* MIDI 76 */
    {523, 107, 35}, /* MIDI 72 */
    {659, 107, 178}, /* MIDI 76 */
    {784, 107, 1035}, /* MIDI 79 */
    {523, 106, 322}, /* MIDI 72 */
    {392, 106, 321}, /* MIDI 67 */
    {330, 107, 321}, /* MIDI 64 */
    {440, 107, 178}, /* MIDI 69 */
    {494, 107, 178}, /* MIDI 71 */
    {466, 107, 35}, /* MIDI 70 */
    {440, 107, 178}, /* MIDI 69 */
    {392, 107, 106}, /* MIDI 67 */
    {659, 107, 72}, /* MIDI 76 */
    {784, 106, 72}, /* MIDI 79 */
    {880, 107, 178}, /* MIDI 81 */
    {698, 107, 35}, /* MIDI 77 */
    {784, 107, 178}, /* MIDI 79 */
    {659, 106, 179}, /* MIDI 76 */
    {523, 106, 37}, /* MIDI 72 */
    {587, 106, 37}, /* MIDI 74 */
    {494, 106, 321}, /* MIDI 71 */
    {523, 107, 321}, /* MIDI 72 */
    {392, 107, 321}, /* MIDI 67 */
    {330, 107, 321}, /* MIDI 64 */
    {440, 107, 178}, /* MIDI 69 */
    {494, 107, 178}, /* MIDI 71 */
    {466, 107, 35}, /* MIDI 70 */
    {440, 107, 178}, /* MIDI 69 */
    {392, 107, 106}, /* MIDI 67 */
    {659, 107, 72}, /* MIDI 76 */
    {784, 106, 72}, /* MIDI 79 */
    {880, 107, 178}, /* MIDI 81 */
    {698, 106, 37}, /* MIDI 77 */
    {784, 106, 179}, /* MIDI 79 */
    {659, 106, 179}, /* MIDI 76 */
    {523, 106, 37}, /* MIDI 72 */
    {587, 106, 37}, /* MIDI 74 */
    {494, 106, 321}, /* MIDI 71 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {392, 107, 321}, /* MIDI 67 */
    {415, 107, 178}, /* MIDI 68 */
    {440, 107, 35}, /* MIDI 69 */
    {698, 107, 178}, /* MIDI 77 */
    {698, 107, 35}, /* MIDI 77 */
    {440, 107, 464}, /* MIDI 69 */
    {494, 107, 106}, /* MIDI 71 */
    {880, 107, 72}, /* MIDI 81 */
    {880, 106, 72}, /* MIDI 81 */
    {880, 106, 107}, /* MIDI 81 */
    {784, 107, 71}, /* MIDI 79 */
    {698, 107, 72}, /* MIDI 77 */
    {659, 106, 37}, /* MIDI 76 */
    {523, 106, 178}, /* MIDI 72 */
    {440, 107, 35}, /* MIDI 69 */
    {392, 107, 464}, /* MIDI 67 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {392, 107, 321}, /* MIDI 67 */
    {415, 107, 178}, /* MIDI 68 */
    {440, 107, 35}, /* MIDI 69 */
    {698, 107, 178}, /* MIDI 77 */
    {698, 107, 35}, /* MIDI 77 */
    {440, 107, 464}, /* MIDI 69 */
    {494, 106, 37}, /* MIDI 71 */
    {698, 107, 178}, /* MIDI 77 */
    {698, 106, 37}, /* MIDI 77 */
    {698, 106, 107}, /* MIDI 77 */
    {659, 107, 71}, /* MIDI 76 */
    {587, 107, 71}, /* MIDI 74 */
    {523, 107, 1035}, /* MIDI 72 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {392, 107, 321}, /* MIDI 67 */
    {415, 107, 178}, /* MIDI 68 */
    {440, 107, 35}, /* MIDI 69 */
    {698, 107, 178}, /* MIDI 77 */
    {698, 107, 35}, /* MIDI 77 */
    {440, 107, 464}, /* MIDI 69 */
    {494, 106, 107}, /* MIDI 71 */
    {880, 107, 71}, /* MIDI 81 */
    {880, 107, 72}, /* MIDI 81 */
    {880, 106, 107}, /* MIDI 81 */
    {784, 107, 71}, /* MIDI 79 */
    {698, 107, 71}, /* MIDI 77 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {440, 107, 35}, /* MIDI 69 */
    {392, 107, 464}, /* MIDI 67 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {392, 107, 321}, /* MIDI 67 */
    {415, 107, 178}, /* MIDI 68 */
    {440, 107, 35}, /* MIDI 69 */
    {698, 106, 179}, /* MIDI 77 */
    {698, 106, 37}, /* MIDI 77 */
    {440, 106, 465}, /* MIDI 69 */
    {494, 106, 35}, /* MIDI 71 */
    {698, 107, 178}, /* MIDI 77 */
    {698, 107, 35}, /* MIDI 77 */
    {698, 107, 107}, /* MIDI 77 */
    {659, 107, 71}, /* MIDI 76 */
    {587, 107, 71}, /* MIDI 74 */
    {523, 107, 1035}, /* MIDI 72 */
    {523, 107, 35}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 107, 35}, /* MIDI 72 */
    {587, 107, 178}, /* MIDI 74 */
    {659, 106, 37}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {440, 106, 37}, /* MIDI 69 */
    {392, 106, 465}, /* MIDI 67 */
    {523, 106, 35}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 107, 35}, /* MIDI 72 */
    {587, 107, 35}, /* MIDI 74 */
    {659, 107, 1178}, /* MIDI 76 */
    {523, 107, 35}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 107, 178}, /* MIDI 72 */
    {523, 106, 37}, /* MIDI 72 */
    {587, 106, 179}, /* MIDI 74 */
    {659, 106, 37}, /* MIDI 76 */
    {523, 106, 179}, /* MIDI 72 */
    {440, 106, 35}, /* MIDI 69 */
    {392, 107, 464}, /* MIDI 67 */
    {659, 107, 35}, /* MIDI 76 */
    {659, 107, 178}, /* MIDI 76 */
    {659, 107, 178}, /* MIDI 76 */
    {523, 107, 35}, /* MIDI 72 */
    {659, 107, 178}, /* MIDI 76 */
    {784, 107, 1035}, /* MIDI 79 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 106, 179}, /* MIDI 72 */
    {392, 106, 322}, /* MIDI 67 */
    {415, 106, 179}, /* MIDI 68 */
    {440, 106, 35}, /* MIDI 69 */
    {698, 107, 178}, /* MIDI 77 */
    {698, 107, 35}, /* MIDI 77 */
    {440, 107, 464}, /* MIDI 69 */
    {494, 107, 107}, /* MIDI 71 */
    {880, 106, 72}, /* MIDI 81 */
    {880, 107, 71}, /* MIDI 81 */
    {880, 107, 107}, /* MIDI 81 */
    {784, 106, 72}, /* MIDI 79 */
    {698, 107, 71}, /* MIDI 77 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {440, 107, 35}, /* MIDI 69 */
    {392, 107, 464}, /* MIDI 67 */
    {659, 107, 35}, /* MIDI 76 */
    {523, 107, 178}, /* MIDI 72 */
    {392, 106, 322}, /* MIDI 67 */
    {415, 106, 178}, /* MIDI 68 */
    {440, 107, 35}, /* MIDI 69 */
    {698, 107, 178}, /* MIDI 77 */
    {698, 107, 35}, /* MIDI 77 */
    {440, 107, 464}, /* MIDI 69 */
    {494, 107, 35}, /* MIDI 71 */
    {698, 107, 178}, /* MIDI 77 */
    {698, 107, 35}, /* MIDI 77 */
    {698, 107, 107}, /* MIDI 77 */
    {659, 106, 72}, /* MIDI 76 */
    {587, 106, 72}, /* MIDI 74 */
    {523, 107, 0}, /* MIDI 72 */
};

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

#include "OLED.h"
#include "GameScene.h"
#include "MusicTracks.h"
#include "EventMusicTracks.h"

/* SysTick 提供无中断的毫秒基准；DWT 可用时负责高精度调度和音乐计时。 */
static void Delay_Init(void)
{
    uint32_t before;
    uint32_t probe;

    SysTick->CTRL = 0U;
    SysTick->LOAD = (SystemCoreClock / 1000U) - 1U;
    SysTick->VAL  = 0U;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_ENABLE_Msk;

    /* 使能 Cortex-M3 跟踪单元后，再实际确认 CYCCNT 确实在递增。 */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    MARIO_DWT->CTRL |= MARIO_DWT_CTRL_CYCCNTENA;
    MARIO_DWT->CYCCNT = 0U;
    before = MARIO_DWT->CYCCNT;
    for (probe = 0U; probe < 2048U; probe++) { __NOP(); }
    s_dwt_available = (MARIO_DWT->CYCCNT != before) ? 1U : 0U;
}

/* 有限等待版本：即使 SysTick 配置异常，也不会永久卡在启动延时中。 */
static void Delay_ms(uint32_t ms)
{
    while (ms-- > 0U)
    {
        uint32_t guard = 2000000UL;
        while ((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) == 0U)
        {
            if (guard-- == 0U) return;
        }
    }
}

/*
 * IWDG 作为最后一道失控保护：正常主循环每 10ms 喂狗；若意外进入死循环、
 * 总线异常路径或其他不可恢复卡死，约 3.2s 后硬件复位，避免蜂鸣器永远保持
 * 在最后一个音符且屏幕永久停住。LSI 启动与寄存器同步等待均有上限。
 */
static void Watchdog_Init(void)
{
    uint32_t guard;

    s_watchdog_enabled = 0U;
    MARIO_RCC_CSR |= (1UL << 0); /* LSION */
    guard = 1000000UL;
    while ((MARIO_RCC_CSR & (1UL << 1)) == 0U) /* LSIRDY */
    {
        if (guard-- == 0U) return;
    }

    MARIO_IWDG->KR = 0x5555U; /* 允许写 PR/RLR */
    MARIO_IWDG->PR = 4U;      /* LSI / 64 */
    MARIO_IWDG->RLR = 1999U;  /* 约 3.2s（按 LSI=40kHz 估算） */

    guard = 1000000UL;
    while ((MARIO_IWDG->SR & 0x03U) != 0U)
    {
        if (guard-- == 0U) return;
    }

    MARIO_IWDG->KR = 0xAAAAU; /* 装载计数器 */
    MARIO_IWDG->KR = 0xCCCCU; /* 启动 IWDG */
    s_watchdog_enabled = 1U;
}

static void Watchdog_Refresh(void)
{
    if (s_watchdog_enabled != 0U)
        MARIO_IWDG->KR = 0xAAAAU;
}

/*
 * 背景音乐调度器：按 DWT 实际经过的毫秒数推进音符，而不是每次循环固定扣
 * 10ms。OLED 绘制/传输耗时因此会计入真实时间，角色移动或场景复杂时不会拖慢旋律。
 * 游戏音效优先；PA1 暂停时强制静音并冻结旋律游标，恢复时从原音符位置继续。
 */
#define MUSIC_TIME_SCALE_PERCENT 95U  /* 保留原有旋律速度设定。 */
/* 当前关卡音乐轨道；主题变化时切换对应音符表并从头开始播放。 */
static const MusicNote *s_music_notes = g_melody;
static uint16_t s_music_note_count = (uint16_t)ARRAY_SIZE(g_melody);
static uint8_t s_music_theme = 0xFFU;
static uint16_t s_music_index = 0U;
static uint32_t s_music_remaining_ms = 0U;
static uint8_t s_music_phase = 0U;       /* 0=音符时长，1=该音符后的休止时长。 */
static uint8_t s_music_segment_loaded = 0U;
static uint8_t s_music_was_sfx = 0U;
static uint8_t s_music_in_loop_gap = 0U;
static uint8_t s_music_paused = 0U;

/* 06~09：关卡完成、Castle 完成、失去生命、Game Over 一次性曲目。 */
static const MusicNote *s_event_music_notes = 0;
static uint16_t s_event_music_count = 0U;
static uint16_t s_event_music_index = 0U;
static uint32_t s_event_music_remaining_ms = 0U;
static uint8_t s_event_music_phase = 0U;
static uint8_t s_event_music_loaded = 0U;
static uint8_t s_event_music_active = 0U;

static uint32_t ScaleMusicMs(uint16_t source_ms)
{
    uint32_t scaled = ((uint32_t)source_ms * MUSIC_TIME_SCALE_PERCENT + 50U) / 100U;
    return scaled ? scaled : 1U;
}

/* 四条常规背景主题按请求使用 25% 低电平有效占空比；其它声音保持 PRE14 的 50%。 */
static void Music_SetBackgroundFrequency(uint32_t frequency_hz)
{
    switch (s_music_theme)
    {
    case GAME_MUSIC_THEME_GROUND:
    case GAME_MUSIC_THEME_UNDERGROUND:
    case GAME_MUSIC_THEME_CASTLE:
    case GAME_MUSIC_THEME_UNDERWATER:
        PWM_SetFrequencyWithDuty(frequency_hz, 25U);
        break;
    default:
        /* 无敌星主题不属于本次指定的四条常规背景音乐，维持 PRE14 输出。 */
        PWM_SetFrequency(frequency_hz);
        break;
    }
}

/* 让当前背景音乐片段重新占用 PA0；静音音符和休止片段保持静音。 */
static void Music_ApplyCurrentSegment(void)
{
    const MusicNote *note = &s_music_notes[s_music_index];

    /* 音效正在占用 PA0 时只更新音乐游标，不允许背景音乐改写 PWM 频率。 */
    if (GameScene_SfxActive()) return;

    if (s_music_phase == 0U && note->frequency_hz != 0U)
        Music_SetBackgroundFrequency(note->frequency_hz);
    else
        PWM_Stop();
}

static void Music_LoadCurrentSegment(void)
{
    const MusicNote *note;

    if (s_music_index >= s_music_note_count)
        s_music_index = 0U;
    note = &s_music_notes[s_music_index];
    s_music_remaining_ms = (s_music_phase == 0U) ?
        ScaleMusicMs(note->duration_ms) : ScaleMusicMs(note->rest_ms);
    s_music_segment_loaded = 1U;
    Music_ApplyCurrentSegment();
}

/* 玩家死亡时复位旋律游标；死亡音效仍优先播放，结束后才从头响起。 */
static void Music_ResetToBeginning(void)
{
    s_music_index = 0U;
    s_music_remaining_ms = 0U;
    s_music_phase = 0U;
    s_music_segment_loaded = 0U;
    s_music_was_sfx = 0U;
    s_music_in_loop_gap = 0U;
    /* 死亡音效通常已在 GameScene 中启动；不能因复位背景音乐而把它静音。 */
    if (!GameScene_SfxActive())
        PWM_Stop();
}

/* 根据场景层返回的主题编号切换背景音乐；每次进入新主题都从开头播放。 */
static void Music_SelectTheme(uint8_t theme)
{
    const MusicNote *next_notes = g_melody;
    uint16_t next_count = (uint16_t)ARRAY_SIZE(g_melody);

    switch (theme)
    {
    case GAME_MUSIC_THEME_UNDERGROUND:
        next_notes = g_underground_melody;
        next_count = (uint16_t)ARRAY_SIZE(g_underground_melody);
        break;
    case GAME_MUSIC_THEME_UNDERWATER:
        next_notes = g_underwater_melody;
        next_count = (uint16_t)ARRAY_SIZE(g_underwater_melody);
        break;
    case GAME_MUSIC_THEME_CASTLE:
        next_notes = g_castle_melody;
        next_count = (uint16_t)ARRAY_SIZE(g_castle_melody);
        break;
    case GAME_MUSIC_THEME_INVINCIBILITY:
        next_notes = g_invincibility_melody;
        next_count = (uint16_t)ARRAY_SIZE(g_invincibility_melody);
        break;
    case GAME_MUSIC_THEME_GROUND:
    default:
        break;
    }

    if (s_music_theme == theme)
        return;

    s_music_theme = theme;
    s_music_notes = next_notes;
    s_music_note_count = next_count;
    s_music_index = 0U;
    s_music_remaining_ms = 0U;
    s_music_phase = 0U;
    s_music_segment_loaded = 0U;
    s_music_was_sfx = 0U;
    s_music_in_loop_gap = 0U;

    /* 音效/暂停正在占用蜂鸣器时不改写 PWM；新主题会在可播放时装载首音。 */
    if (!GameScene_SfxActive() && !GameScene_AudioPaused())
        PWM_Stop();
}

/* 装载一次性音乐事件；事件曲目不循环，播放完成后交还背景音乐。 */
static void MusicEvent_Start(uint8_t event_id)
{
    switch (event_id)
    {
    case GAME_MUSIC_EVENT_LEVEL_COMPLETE:
        s_event_music_notes = g_level_complete_melody;
        s_event_music_count = (uint16_t)ARRAY_SIZE(g_level_complete_melody);
        break;
    case GAME_MUSIC_EVENT_CASTLE_COMPLETE:
        s_event_music_notes = g_castle_complete_melody;
        s_event_music_count = (uint16_t)ARRAY_SIZE(g_castle_complete_melody);
        break;
    case GAME_MUSIC_EVENT_LIFE_LOST:
        s_event_music_notes = g_lost_life_melody;
        s_event_music_count = (uint16_t)ARRAY_SIZE(g_lost_life_melody);
        break;
    case GAME_MUSIC_EVENT_GAME_OVER:
        s_event_music_notes = g_game_over_melody;
        s_event_music_count = (uint16_t)ARRAY_SIZE(g_game_over_melody);
        break;
    default:
        return;
    }

    s_event_music_index = 0U;
    s_event_music_remaining_ms = 0U;
    s_event_music_phase = 0U;
    s_event_music_loaded = 0U;
    s_event_music_active = 1U;
    GameScene_SetMusicEventActive(1U);
}

/* elapsed_ms 按真实经过时间推进事件旋律；不会因 15 FPS 游戏帧率而改变音高/节奏。 */
static uint8_t MusicEvent_TaskElapsed(uint32_t elapsed_ms)
{
    uint16_t guard = 0U;
    const MusicNote *note;

    while (guard++ < 128U)
    {
        if (s_event_music_index >= s_event_music_count)
        {
            s_event_music_active = 0U;
            s_event_music_notes = 0;
            s_event_music_count = 0U;
            s_event_music_loaded = 0U;
            GameScene_SetMusicEventActive(0U);
            s_music_was_sfx = 1U; /* 下一次常规音乐任务恢复冻结的 BGM 当前音符。 */
            PWM_Stop();
            return 0U;
        }

        note = &s_event_music_notes[s_event_music_index];
        if (!s_event_music_loaded)
        {
            s_event_music_remaining_ms = (s_event_music_phase == 0U) ?
                ScaleMusicMs(note->duration_ms) : ScaleMusicMs(note->rest_ms);
            s_event_music_loaded = 1U;
            if (s_event_music_phase == 0U && note->frequency_hz != 0U)
                PWM_SetFrequency(note->frequency_hz);
            else
                PWM_Stop();
        }

        if (elapsed_ms < s_event_music_remaining_ms)
        {
            s_event_music_remaining_ms -= elapsed_ms;
            return 1U;
        }

        elapsed_ms -= s_event_music_remaining_ms;
        s_event_music_remaining_ms = 0U;
        s_event_music_loaded = 0U;
        if (s_event_music_phase == 0U && note->rest_ms != 0U)
            s_event_music_phase = 1U;
        else
        {
            s_event_music_phase = 0U;
            s_event_music_index++;
        }
    }

    return 1U;
}

/*
 * elapsed_ms 是两次音乐任务之间 DWT 测得的真实时间。
 * 能在一次调用中跨越多个音符边界，防止 OLED 重绘耗时时旋律逐渐失拍。
 */
static void Music_TaskElapsed(uint32_t elapsed_ms)
{
    uint16_t guard = 0U;
    const MusicNote *note;
    uint8_t event_id;

    /* 上一关胜利音效后的锁定只在下一关标题卡开始时解除；从新关卡主题的开头续播。 */
    if (GameScene_TakeMusicResumeRequest())
    {
        Music_ResetToBeginning();
        s_music_was_sfx = 0U;
    }

    /* 正在播放一次性事件音乐时冻结背景音乐游标，事件曲完整播放后再恢复。 */
    if (s_event_music_active != 0U)
    {
        (void)MusicEvent_TaskElapsed(elapsed_ms);
        return;
    }

    event_id = GameScene_TakeMusicEvent();
    if (event_id != GAME_MUSIC_EVENT_NONE)
    {
        MusicEvent_Start(event_id);
        if (s_event_music_active != 0U)
        {
            (void)MusicEvent_TaskElapsed(elapsed_ms);
            return;
        }
    }

    Music_SelectTheme((uint8_t)GameScene_GetMusicTheme());

    if (GameScene_TakeMusicRestartRequest())
        Music_ResetToBeginning();

    /* PA1 暂停：立即静音，且不推进背景音乐时间；恢复后从当前音符续播。 */
    if (GameScene_AudioPaused())
    {
        s_music_paused = 1U;
        /* 暂停时背景音乐时钟冻结，但允许 PA1 暂停/恢复提示音独占蜂鸣器。 */
        if (!GameScene_SfxActive())
            PWM_Stop();
        return;
    }
    if (s_music_paused)
    {
        s_music_paused = 0U;
        if (GameScene_SfxActive())
        {
            s_music_was_sfx = 1U;
            if (!GameScene_JumpSfxActive()) return;
        }
        else
        {
            if (s_music_segment_loaded)
                Music_ApplyCurrentSegment();
            return;
        }
    }

    /*
     * 常规长音效仍优先并冻结 BGM；跳跃/游泳短音效则让 BGM 时间继续前进，
     * 只在 PA0 输出上短暂让位。这样跳跃音效可听见，音乐不会因每次起跳而停拍。
     */
    if (GameScene_SfxActive())
    {
        s_music_was_sfx = 1U;
        if (!GameScene_JumpSfxActive()) return;
    }
    else if (s_music_was_sfx)
    {
        /* 短音效结束后恢复当前音符，并继续结算本轮 DWT elapsed_ms，避免音乐时钟少走一拍。 */
        s_music_was_sfx = 0U;
        if (s_music_segment_loaded)
            Music_ApplyCurrentSegment();
    }

    /* 初次启动时只装载并开始当前片段；后续调用再按实际时间递减。 */
    if (!s_music_in_loop_gap && !s_music_segment_loaded)
    {
        Music_LoadCurrentSegment();
        return;
    }

    while (guard++ < 128U)
    {
        if (s_music_in_loop_gap)
        {
            if (elapsed_ms < s_music_remaining_ms)
            {
                s_music_remaining_ms -= elapsed_ms;
                return;
            }
            elapsed_ms -= s_music_remaining_ms;
            s_music_remaining_ms = 0U;
            s_music_in_loop_gap = 0U;
            /* 间隔刚结束，继续装载下一轮第一个音符。 */
        }

        if (!s_music_segment_loaded)
            Music_LoadCurrentSegment();

        if (elapsed_ms < s_music_remaining_ms)
        {
            s_music_remaining_ms -= elapsed_ms;
            return;
        }

        elapsed_ms -= s_music_remaining_ms;
        s_music_remaining_ms = 0U;
        s_music_segment_loaded = 0U;
        note = &s_music_notes[s_music_index];

        if (s_music_phase == 0U && note->rest_ms != 0U)
        {
            /* 当前音符结束，进入该音符后的休止片段。 */
            s_music_phase = 1U;
        }
        else
        {
            s_music_phase = 0U;
            s_music_index++;
            if (s_music_index >= s_music_note_count)
            {
                s_music_index = 0U;
                s_music_in_loop_gap = 1U;
                s_music_remaining_ms = 1200U;
                if (!GameScene_SfxActive()) PWM_Stop();
            }
        }

        /* elapsed_ms 为零时也要立即切换音高/静音状态，然后结束本次处理。 */
        if (s_music_in_loop_gap)
        {
            if (elapsed_ms < s_music_remaining_ms)
            {
                s_music_remaining_ms -= elapsed_ms;
                return;
            }
            elapsed_ms -= s_music_remaining_ms;
            s_music_remaining_ms = 0U;
            s_music_in_loop_gap = 0U;
            continue;
        }

        Music_LoadCurrentSegment();
        if (elapsed_ms < s_music_remaining_ms)
        {
            s_music_remaining_ms -= elapsed_ms;
            return;
        }
    }

    /* 极端长时间阻塞时防止单次追赶循环占满主线程；下一次任务继续推进。 */
}

/* 等待期间继续扫描按键、推进游戏、刷新 OLED 和执行背景音乐调度。
 * DWT 正常时按绝对周期执行；若 DWT 停止或异常，则通过 SysTick 有限超时
 * 退回毫秒等待，避免主循环永远卡在 CYCCNT 等待语句中。
 */
/* 游戏逻辑与画面更新频率：15 FPS。DWT 使用 SystemCoreClock/15 计算周期；
 * SysTick 降级路径使用“毫秒 × FPS”累加，平均每 1000/FPS 毫秒更新一次，
 * 避免简单使用 67ms 导致实际帧率只有约 14.93 FPS。
 */
#define GAME_FPS 15U
static void WaitWithScene(uint32_t ms)
{
    uint32_t slice;
    static uint32_t next_service_cycle = 0U;
    static uint32_t next_frame_cycle = 0U;
    static uint32_t music_last_cycle = 0U;
    static uint32_t music_cycle_remainder = 0U;
    static uint8_t clock_started = 0U;

    while (ms > 0U)
    {
        uint32_t observed_ms = 0U;
        slice = (ms >= 10U) ? 10U : ms;
        ms -= slice;

        if (s_dwt_available != 0U)
        {
            uint32_t spin_guard = 2000000UL;
            if (clock_started == 0U)
            {
                next_service_cycle = MARIO_DWT->CYCCNT;
                music_last_cycle = next_service_cycle;
                music_cycle_remainder = 0U;
                clock_started = 1U;
            }
            next_service_cycle += (SystemCoreClock / 1000U) * slice;

            /* SysTick 计数标志同时充当 DWT 等待看门限；DWT 不动时自动降级。 */
            while ((int32_t)(MARIO_DWT->CYCCNT - next_service_cycle) < 0)
            {
                if ((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) != 0U)
                {
                    observed_ms++;
                    if (observed_ms > (slice + 3U))
                    {
                        s_dwt_available = 0U;
                        break;
                    }
                }
                if (spin_guard-- == 0U)
                {
                    s_dwt_available = 0U;
                    break;
                }
            }

            if (s_dwt_available == 0U)
            {
                /* 失败时不再引用损坏的 DWT 时基；尽量补足当前服务间隔。 */
                clock_started = 0U;
                next_frame_cycle = 0U;
                music_cycle_remainder = 0U;
                if (observed_ms < slice)
                    Delay_ms(slice - observed_ms);
            }
        }
        else
        {
            Delay_ms(slice);
        }

        GameScene_KeyScan10ms();
        GameScene_Task10ms();

        /* 15 FPS 使用绝对 DWT 截止时间；单帧超时后跳过过期时刻，禁止追帧连跑。 */
        if (s_dwt_available != 0U)
        {
            uint32_t now_cycle = MARIO_DWT->CYCCNT;
            uint32_t frame_cycles = SystemCoreClock / GAME_FPS;
            if (frame_cycles == 0U) frame_cycles = 1U;
            if (next_frame_cycle == 0U)
                next_frame_cycle = now_cycle + frame_cycles;
            else if ((int32_t)(now_cycle - next_frame_cycle) >= 0)
            {
                GameScene_Update();
                now_cycle = MARIO_DWT->CYCCNT;
                do { next_frame_cycle += frame_cycles; }
                while ((int32_t)(now_cycle - next_frame_cycle) >= 0);
            }
        }
        else
        {
            static uint16_t refresh_accumulator = 0U;
            /* 以 1000 为一个秒周期累加，10ms 服务步长下保持精确 15Hz 平均帧率。 */
            refresh_accumulator = (uint16_t)(refresh_accumulator + (uint16_t)(slice * GAME_FPS));
            if (refresh_accumulator >= 1000U)
            {
                refresh_accumulator = (uint16_t)(refresh_accumulator - 1000U);
                GameScene_Update();
            }
        }

        /* 音乐优先使用实际 DWT 时间；DWT 不可用时使用 SysTick 服务片段时间。 */
        if (s_dwt_available != 0U)
        {
            uint32_t now_cycle = MARIO_DWT->CYCCNT;
            uint32_t elapsed_cycles = now_cycle - music_last_cycle;
            uint32_t cycles_per_ms = SystemCoreClock / 1000U;
            uint32_t elapsed_ms;
            if (cycles_per_ms == 0U) cycles_per_ms = 1U;
            music_last_cycle = now_cycle;
            elapsed_cycles += music_cycle_remainder;
            elapsed_ms = elapsed_cycles / cycles_per_ms;
            music_cycle_remainder = elapsed_cycles % cycles_per_ms;
            Music_TaskElapsed(elapsed_ms);
        }
        else
        {
            music_last_cycle = MARIO_DWT->CYCCNT;
            Music_TaskElapsed(slice);
        }
    }
}

/* 程序入口：先配置时钟和外设，再进入永不退出的游戏主循环。 */
int main(void)
{
    SystemCoreClockUpdate();
    Delay_Init();
    Watchdog_Init();

    OLED_Init();
    PWM_Init();
    PWM_Stop();

    GameScene_Init();
    /* PA0 为单声道蜂鸣器：跳跃短音效可短暂让位，背景音乐时间轴继续运行。 */
    GameScene_SetBackgroundMusicActive(1U);
    Delay_ms(300);

    while (1)
    {
        /* 以 10ms 小步长循环，游戏和音频使用同一个非阻塞式调度节拍。 */
        WaitWithScene(10U);
        Watchdog_Refresh();
    }
}

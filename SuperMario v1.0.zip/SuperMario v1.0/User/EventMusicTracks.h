/* PRE8 event tracks: melody-focused, monophonic, pitch-quantized. */
#ifndef __EVENT_MUSIC_TRACKS_H
#define __EVENT_MUSIC_TRACKS_H

/* 每项 MusicNote: 频率Hz、发声时长ms、附加休止ms。频率已量化到十二平均律。 */
/* PRE7 / Level Complete Theme，WORLD 1-1、1-3、2-1、2-3 通关（29 个平滑后的单声部音符/休止段）。 */
static const MusicNote g_level_complete_melody[] =
{
    {587U, 160U, 0U},
    {494U, 120U, 0U},
    {587U, 100U, 0U},
    {392U, 180U, 0U},
    {523U, 120U, 0U},
    {659U, 140U, 0U},
    {784U, 400U, 0U},
    {659U, 420U, 0U},
    {622U, 120U, 0U},
    {784U, 120U, 0U},
    {622U, 100U, 0U},
    {415U, 180U, 0U},
    {523U, 120U, 0U},
    {415U, 140U, 0U},
    {523U, 400U, 0U},
    {622U, 420U, 0U},
    {698U, 120U, 0U},
    {880U, 120U, 0U},
    {698U, 100U, 0U},
    {466U, 180U, 0U},
    {587U, 120U, 0U},
    {698U, 140U, 0U},
    {587U, 860U, 0U},
    {1047U, 680U, 0U},
    {932U, 320U, 0U},
    {831U, 100U, 0U},
    {932U, 160U, 0U},
    {988U, 160U, 0U},
    {392U, 180U, 0U},
};

/* PRE7 / Castle Complete Theme，WORLD 2-4 通关（24 个平滑后的单声部音符/休止段）。 */
static const MusicNote g_castle_complete_melody[] =
{
    {523U, 160U, 0U},
    {392U, 220U, 0U},
    {523U, 160U, 0U},
    {392U, 220U, 0U},
    {523U, 860U, 0U},
    {554U, 120U, 0U},
    {415U, 180U, 0U},
    {554U, 240U, 0U},
    {415U, 140U, 0U},
    {622U, 80U, 0U},
    {554U, 840U, 0U},
    {622U, 120U, 0U},
    {466U, 140U, 0U},
    {392U, 260U, 0U},
    {466U, 140U, 0U},
    {392U, 200U, 0U},
    {622U, 320U, 0U},
    {698U, 600U, 0U},
    {494U, 1260U, 0U},
    {831U, 100U, 0U},
    {659U, 180U, 0U},
    {880U, 240U, 0U},
    {784U, 140U, 0U},
    {392U, 200U, 0U},
};

/* PRE14 / Lost A Life Theme：依据 AudioSource/08. Lost A Life Theme.mp3 重新听辨。
 * 12 个单声部音符；保留开头短句、约 360ms 的中间停顿、下降主旋律与约 1200ms 的尾部静音。
 * 原始参考音频约 3.84s；本表 duration_ms + rest_ms 合计 3840ms，仍由全局 95% 速度系数统一缩放。
 */
static const MusicNote g_lost_life_melody[] =
{
    {466U, 100U, 0U},   /* A#4 */
    {494U,  80U, 0U},   /* B4 */
    {440U,  60U, 360U}, /* A4，随后为原音频中的明显停顿 */
    {494U, 160U, 0U},   /* B4 */
    {698U, 160U, 160U}, /* F5，短停顿后重复 */
    {698U, 280U, 0U},   /* F5 */
    {659U, 200U, 0U},   /* E5 */
    {587U, 220U, 0U},   /* D5 */
    {523U, 250U, 0U},   /* C5 */
    {466U, 220U, 0U},   /* A#4 */
    {415U, 230U, 0U},   /* G#4 */
    {392U, 160U, 1200U},/* G4，保留参考音频结尾静音 */
};

/* PRE7 / Game Over Theme，生命数归零（13 个平滑后的单声部音符/休止段）。 */
static const MusicNote g_game_over_melody[] =
{
    {523U, 280U, 0U},
    {392U, 440U, 0U},
    {415U, 100U, 0U},
    {330U, 400U, 0U},
    {349U, 460U, 0U},
    {440U, 120U, 0U},
    {349U, 420U, 0U},
    {466U, 180U, 0U},
    {415U, 320U, 0U},
    {330U, 80U, 0U},
    {392U, 360U, 0U},
    {330U, 640U, 0U},
    {262U, 920U, 0U},
};

#endif /* __MUSIC_TRACKS_H */

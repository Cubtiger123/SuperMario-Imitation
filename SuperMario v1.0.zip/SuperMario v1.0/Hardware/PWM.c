/*
 * 蜂鸣器 PWM 驱动说明：PA0 复用为 TIM2_CH1，使用 1MHz 计数时钟。
 * PWM_SetFrequency() 根据目标音高动态调整 ARR 和 CCR；PWM_Stop() 静音。
 *
 * PWM output: STM32F103CBT6 PA0 / TIM2_CH1
 * TIM2 clock assumed to be 72 MHz (APB1 prescaler = 2).
 * Prescaler 71 gives a 1 MHz timer counter clock.
 */

#include "PWM.h"

/* 初始化 TIM2_CH1，并将定时器计数时钟配置为约 1 MHz。 */
void PWM_Init(void)
{
    GPIO_InitTypeDef gpio;
    TIM_TimeBaseInitTypeDef timebase;
    TIM_OCInitTypeDef oc;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    GPIO_StructInit(&gpio);
    gpio.GPIO_Pin = GPIO_Pin_0;
    gpio.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);

    TIM_TimeBaseStructInit(&timebase);
    timebase.TIM_Prescaler = 72U - 1U;
    timebase.TIM_CounterMode = TIM_CounterMode_Up;
    timebase.TIM_Period = 1000U - 1U;
    timebase.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInit(TIM2, &timebase);

    TIM_OCStructInit(&oc);
    oc.TIM_OCMode = TIM_OCMode_PWM1;
    oc.TIM_OutputState = TIM_OutputState_Enable;
    /* Low-active buzzer: PWM active phase is driven low. */
    oc.TIM_OCPolarity = TIM_OCPolarity_Low;
    oc.TIM_Pulse = 0;
    TIM_OC1Init(TIM2, &oc);
    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM2, ENABLE);

    TIM_SetCompare1(TIM2, 0);
    TIM_Cmd(TIM2, ENABLE);
}

/*
 * 根据目标频率和有效低电平占空比设置 PWM。
 * TIM_OCPolarity_Low 使比较区间对应 PA0 的低电平有效脉冲；
 * duty_percent=50 与 PRE14 默认输出一致，25 用于降低指定背景主题的输出强度。
 */
void PWM_SetFrequencyWithDuty(uint32_t frequency_hz, uint8_t duty_percent)
{
    uint32_t period;
    uint32_t pulse;

    if (frequency_hz < 20U || frequency_hz > 20000U || duty_percent == 0U)
    {
        PWM_Stop();
        return;
    }

    if (duty_percent > 99U)
        duty_percent = 99U;

    /* TIM2 counter clock = 1 MHz. */
    period = (1000000U / frequency_hz);
    if (period < 2U)
        period = 2U;

    pulse = (period * (uint32_t)duty_percent + 50U) / 100U;
    if (pulse == 0U)
        pulse = 1U;
    if (pulse >= period)
        pulse = period - 1U;

    TIM_SetAutoreload(TIM2, period - 1U);
    TIM_SetCompare1(TIM2, (uint16_t)pulse);
    TIM_GenerateEvent(TIM2, TIM_EventSource_Update);
}

/* 保持 PRE14 的默认音效输出：约 50% 低电平有效占空比。 */
void PWM_SetFrequency(uint32_t frequency_hz)
{
    PWM_SetFrequencyWithDuty(frequency_hz, 50U);
}

/* 停止定时器输出，蜂鸣器静音。 */
void PWM_Stop(void)
{
    /* With low polarity, CCR=0 leaves the pin at its inactive high level. */
    TIM_SetCompare1(TIM2, 0);
}

/*
 * OLED 游戏场景 API。
 * GameScene_Init：初始化按键 GPIO 并显示启动标题界面。
 * 启动菜单：PB1 进入选关，PA1 循环选择八关，PB1 再次确认；PC13 手动恢复 OLED。
 * GameScene_KeyScan10ms：每 10ms 调用一次，读取并消抖按键（含 PB1/PA1/PA5/PA7/PC13）。
 * GameScene_Task10ms：每 10ms 调用一次，更新计时器/音效/死亡和关卡状态。
 * GameScene_Update：按游戏帧周期调用，更新物理、敌人、碰撞并刷新 OLED。
 * GameScene_SfxActive：游戏音效占用蜂鸣器或死亡摘要界面强制静音时返回非零。
 * GameScene_TakeMusicRestartRequest：读取并清除死亡后重启背景音乐的一次性请求。
 */
#ifndef __GAME_SCENE_H
#define __GAME_SCENE_H
#include <stdint.h>
void GameScene_Init(void);
/* 通知场景层背景音乐是否启用；启用时由背景音乐与短跳跃提示音进行时间仲裁。 */
void GameScene_SetBackgroundMusicActive(uint8_t active);
typedef enum
{
    GAME_MUSIC_THEME_GROUND = 0U,
    GAME_MUSIC_THEME_UNDERGROUND = 1U,
    GAME_MUSIC_THEME_UNDERWATER = 2U,
    GAME_MUSIC_THEME_CASTLE = 3U,
    GAME_MUSIC_THEME_INVINCIBILITY = 4U
} GameMusicTheme;

typedef enum
{
    GAME_MUSIC_EVENT_NONE = 0U,
    GAME_MUSIC_EVENT_LEVEL_COMPLETE = 1U, /* 06 */
    GAME_MUSIC_EVENT_CASTLE_COMPLETE = 2U, /* 07 */
    GAME_MUSIC_EVENT_LIFE_LOST = 3U, /* 08 */
    GAME_MUSIC_EVENT_GAME_OVER = 4U /* 09 */
} GameMusicEvent;

/* 返回当前应播放的主题：无敌星 > 下水道 > 当前关卡。 */
uint8_t GameScene_GetMusicTheme(void);
/* 读取一次性音乐事件；事件按请求顺序出队。 */
uint8_t GameScene_TakeMusicEvent(void);
/* 主程序告知一次性音乐是否正在播放，以便场景音效让出 PA0。 */
void GameScene_SetMusicEventActive(uint8_t active);
void GameScene_Update(void);
void GameScene_KeyScan10ms(void);
void GameScene_Task10ms(void);
uint8_t GameScene_SfxActive(void);
/* 非零表示正在播放跳跃/游泳短音效；BGM 时间轴可继续推进但不覆盖 PWM。 */
uint8_t GameScene_JumpSfxActive(void);
/* 非零表示 PA1 当前处于暂停状态，主程序应静音并冻结背景音乐时钟。 */
uint8_t GameScene_AudioPaused(void);
uint8_t GameScene_TakeMusicRestartRequest(void);
/* 通关音效结束后的背景音乐保持静音，直到下一关标题卡开始；此接口读取恢复请求。 */
uint8_t GameScene_TakeMusicResumeRequest(void);
#endif

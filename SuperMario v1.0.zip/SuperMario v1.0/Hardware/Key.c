#include "stm32f10x.h"
#include "Key.h"

/*
 * 跳跃按键驱动：PB1 接地触发，内部上拉，低电平有效。
 * Key_GetNum() 每 10ms 调用一次；连续采样稳定后只在按下沿返回 1。
 */
/* 初始化 PB1 输入上拉，按键另一端接地。 */
void Key_Init(void)
{
    GPIO_InitTypeDef gpio;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_StructInit(&gpio);
    gpio.GPIO_Pin = GPIO_Pin_1;
    gpio.GPIO_Mode = GPIO_Mode_IPU;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOB, &gpio);
}

uint8_t Key_GetNum(void)
{
    static uint8_t stable = 1, last_sample = 1, count = 0;
    uint8_t sample = (uint8_t)GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1);

    if (sample == last_sample)
    {
        if (count < 3) count++;
    }
    else
    {
        count = 0;
        last_sample = sample;
    }

    /* 采样值连续两次采样一致后立即更新状态（约 20ms 内确认），过滤机械抖动。 */
    if (count >= 1 && sample != stable)
    {
        stable = sample;
        if (stable == 0) return 1; /* one event on press */
    }
    return 0;
}

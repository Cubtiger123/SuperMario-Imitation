/* PA0/TIM2_CH1 无源蜂鸣器接口。 */
#ifndef __PWM_H
#define __PWM_H

#include "stm32f10x.h"
#include <stdint.h>

/* TIM2_CH1/PA0 无源蜂鸣器：输入频率（Hz）产生方波，Stop 关闭输出。 */
void PWM_Init(void);
/* 自定义低电平有效脉冲占空比（百分比）；普通音效仍使用默认 50%。 */
void PWM_SetFrequencyWithDuty(uint32_t frequency_hz, uint8_t duty_percent);
/* 默认 50% 有效占空比，供游戏音效及未单独调低的曲目使用。 */
void PWM_SetFrequency(uint32_t frequency_hz);
void PWM_Stop(void);

#endif

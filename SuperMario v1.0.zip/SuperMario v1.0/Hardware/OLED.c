/*
 * SSD1306/SH1106 兼容的 128x64 OLED 驱动（1.3 英寸 132 列 RAM 模块使用列偏移）。
 * PB8/PB9 使用 I2C1 硬件重映射，设备地址为 0x3C，总线速率 400kHz。
 * 字符接口直接写屏；图形接口先更新 1KB 显存，再由 OLED_GFX_Refresh() 刷新。
 */
#include "stm32f10x.h"
#include "OLED_Font.h"

/*
 * 1.3 英寸 128x64 OLED 常见 SH1106 控制器内部有 132 列 RAM，
 * 模块可视窗口通常从 RAM 第 2 列开始。逻辑列 0..127 映射到 RAM 2..129，
 * 避免屏幕最右侧遗留 2px 未被刷新。原生 SSD1306 模块请将此值改为 0U。
 */
#define OLED_COLUMN_OFFSET 2U

/* I2C1 重映射到 PB8=SCL、PB9=SDA；使用硬件 I2C，最高 400kHz。 */
#define OLED_I2C_ADDRESS_8BIT 0x78U
#define OLED_I2C_TIMEOUT      60000UL

#define OLED_W_SCL(x) GPIO_WriteBit(GPIOB, GPIO_Pin_8, (BitAction)(x))
#define OLED_W_SDA(x) GPIO_WriteBit(GPIOB, GPIO_Pin_9, (BitAction)(x))

static void OLED_I2C_RecoveryDelay(void)
{
    volatile uint8_t n;
    for (n = 0U; n < 24U; n++) { __NOP(); }
}

static void OLED_I2C_RecoverBus(void);
static uint8_t OLED_SetCursorFast(uint8_t Page, uint8_t X);
static uint8_t OLED_MapColumn(uint8_t LogicalX);
static uint8_t OLED_WriteDataBlock(const uint8_t *Data, uint8_t Length);

/* 等待 I2C 事件，检测 NACK/总线错误并使用有限超时，避免主循环永久卡住。 */
static uint8_t OLED_I2C_WaitEvent(uint32_t event)
{
    uint32_t timeout = OLED_I2C_TIMEOUT;
    while (timeout-- != 0U)
    {
        if (I2C_CheckEvent(I2C1, event) == SUCCESS) return 1U;
        if (I2C_GetFlagStatus(I2C1, I2C_FLAG_AF) == SET)
        {
            I2C_ClearFlag(I2C1, I2C_FLAG_AF);
            return 0U;
        }
        if (I2C_GetFlagStatus(I2C1, I2C_FLAG_BERR) == SET)
        {
            I2C_ClearFlag(I2C1, I2C_FLAG_BERR);
            return 0U;
        }
        if (I2C_GetFlagStatus(I2C1, I2C_FLAG_ARLO) == SET)
        {
            I2C_ClearFlag(I2C1, I2C_FLAG_ARLO);
            return 0U;
        }
    }
    return 0U;
}

static uint8_t OLED_I2C_WaitFlag(uint32_t flag)
{
    uint32_t timeout = OLED_I2C_TIMEOUT;
    while (timeout-- != 0U)
    {
        if (I2C_GetFlagStatus(I2C1, flag) == SET) return 1U;
        if (I2C_GetFlagStatus(I2C1, I2C_FLAG_AF) == SET)
        {
            I2C_ClearFlag(I2C1, I2C_FLAG_AF);
            return 0U;
        }
        if (I2C_GetFlagStatus(I2C1, I2C_FLAG_BERR) == SET)
        {
            I2C_ClearFlag(I2C1, I2C_FLAG_BERR);
            return 0U;
        }
        if (I2C_GetFlagStatus(I2C1, I2C_FLAG_ARLO) == SET)
        {
            I2C_ClearFlag(I2C1, I2C_FLAG_ARLO);
            return 0U;
        }
    }
    return 0U;
}

static uint8_t OLED_I2C_WaitBusIdle(void)
{
    uint32_t timeout = OLED_I2C_TIMEOUT;
    while (timeout-- != 0U)
    {
        if (I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY) == RESET) return 1U;
        if (I2C_GetFlagStatus(I2C1, I2C_FLAG_BERR) == SET)
        {
            I2C_ClearFlag(I2C1, I2C_FLAG_BERR);
            return 0U;
        }
    }
    return 0U;
}

/* 初始化 I2C1 并重映射到现有 OLED 接线 PB8/PB9，不需要改动杜邦线。 */
void OLED_I2C_Init(void)
{
    GPIO_InitTypeDef gpio;
    I2C_InitTypeDef i2c;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_I2C1, ENABLE);

    GPIO_StructInit(&gpio);
    gpio.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
    gpio.GPIO_Mode = GPIO_Mode_AF_OD;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio);

    I2C_DeInit(I2C1);
    I2C_StructInit(&i2c);
    i2c.I2C_ClockSpeed = 400000U;
    i2c.I2C_Mode = I2C_Mode_I2C;
    i2c.I2C_DutyCycle = I2C_DutyCycle_2;
    i2c.I2C_OwnAddress1 = 0x00U;
    i2c.I2C_Ack = I2C_Ack_Enable;
    i2c.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_Init(I2C1, &i2c);
    I2C_Cmd(I2C1, ENABLE);
}

/* 使用硬件 I2C 发送一次事务；失败时由上层重新设定 OLED 页/列后再重试。 */
static uint8_t OLED_I2C_WriteTransactionOnce(uint8_t control,
                                             const uint8_t *data,
                                             uint8_t length)
{
    uint8_t i;

    if (data == 0 && length != 0U) return 0U;
    if (OLED_I2C_WaitBusIdle() == 0U)
    {
        /* BUSY 超时通常表示上一次事务未正常释放，由上层执行总线恢复。 */
        return 0U;
    }

    I2C_GenerateSTART(I2C1, ENABLE);
    if (OLED_I2C_WaitEvent(I2C_EVENT_MASTER_MODE_SELECT) == 0U) goto error;

    I2C_Send7bitAddress(I2C1, OLED_I2C_ADDRESS_8BIT, I2C_Direction_Transmitter);
    if (OLED_I2C_WaitEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == 0U) goto error;

    I2C_SendData(I2C1, control);
    if (OLED_I2C_WaitFlag(I2C_FLAG_TXE) == 0U) goto error;

    for (i = 0U; i < length; i++)
    {
        I2C_SendData(I2C1, data[i]);
        if (OLED_I2C_WaitFlag(I2C_FLAG_TXE) == 0U) goto error;
    }
    if (OLED_I2C_WaitFlag(I2C_FLAG_BTF) == 0U) goto error;

    I2C_GenerateSTOP(I2C1, ENABLE);
    return 1U;

error:
    I2C_GenerateSTOP(I2C1, ENABLE);
    return 0U;
}

/* 命令事务可安全地从头重发；图形数据块重试前必须重新设置页/列地址。 */
static uint8_t OLED_I2C_WriteTransaction(uint8_t control,
                                         const uint8_t *data,
                                         uint8_t length)
{
    uint8_t retry;
    for (retry = 0U; retry < 2U; retry++)
    {
        if (OLED_I2C_WriteTransactionOnce(control, data, length) != 0U)
            return 1U;
        if ((uint8_t)(retry + 1U) < 2U)
            OLED_I2C_RecoverBus();
    }
    return 0U;
}

/* 写入一条 SSD1306 命令；单字节事务同样检查 ACK 并有限重试。 */
void OLED_WriteCommand(uint8_t Command)
{
    (void)OLED_I2C_WriteTransaction(0x00U, &Command, 1U);
}

/* 写入一个 OLED 数据字节。 */
void OLED_WriteData(uint8_t Data)
{
    (void)OLED_I2C_WriteTransaction(0x40U, &Data, 1U);
}

/**
  * @brief  OLED设置光标位置
  * @param  Y 以左上角为原点，向下方向的坐标，范围：0~7
  * @param  X 以左上角为原点，向右方向的坐标，范围：0~127
  * @retval 无
  */
static uint8_t OLED_MapColumn(uint8_t LogicalX)
{
    uint16_t physical_x;
    if (LogicalX > 127U) LogicalX = 127U;
    physical_x = (uint16_t)LogicalX + OLED_COLUMN_OFFSET;
    return (uint8_t)physical_x; /* 逻辑 0..127 -> SH1106 RAM 2..129 */
}

void OLED_SetCursor(uint8_t Y, uint8_t X)
{
    uint8_t physical_x = OLED_MapColumn(X);
    OLED_WriteCommand((uint8_t)(0xB0U | (Y & 0x07U)));
    OLED_WriteCommand((uint8_t)(0x10U | ((physical_x & 0xF0U) >> 4)));
    OLED_WriteCommand((uint8_t)(0x00U | (physical_x & 0x0FU)));
}

/**
  * @brief  OLED清屏
  * @param  无
  * @retval 无
  */
void OLED_Clear(void)
{
    uint8_t page;
    static const uint8_t zeros[128] = {0U};
    for (page = 0U; page < 8U; page++)
    {
        (void)OLED_SetCursorFast(page, 0U);
        (void)OLED_WriteDataBlock(zeros, 128U);
    }
}

/**
  * @brief  OLED显示一个字符
  * @param  Line 行位置，范围：1~4
  * @param  Column 列位置，范围：1~16
  * @param  Char 要显示的一个字符，范围：ASCII可见字符
  * @retval 无
  */
static uint8_t OLED_SetCursorFast(uint8_t Page, uint8_t X)
{
    uint8_t command[3];
    uint8_t physical_x = OLED_MapColumn(X);
    command[0] = (uint8_t)(0xB0U | (Page & 0x07U));
    command[1] = (uint8_t)(0x10U | ((physical_x & 0xF0U) >> 4));
    command[2] = (uint8_t)(physical_x & 0x0FU);
    return OLED_I2C_WriteTransaction(0x00U, command, 3U);
}

static uint8_t OLED_WriteDataBlock(const uint8_t *Data, uint8_t Length)
{
    if (Data == 0 || Length == 0U) return 0U;
    return OLED_I2C_WriteTransaction(0x40U, Data, Length);
}

void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char)
{
    uint8_t code;
    const uint8_t *glyph;

    /* SSD1306 128x64 只容纳 4 行 16 像素字模；越界写入会破坏显示地址。 */
    if (Line < 1U || Line > 4U || Column < 1U || Column > 16U) return;

    code = (uint8_t)Char;
    if (code < (uint8_t)' ' || code > (uint8_t)'~') code = (uint8_t)'?';
    /* 字模表按 ASCII 顺序平铺，每个字符固定 16 字节。 */
    glyph = &OLED_F8x16[(uint16_t)(code - (uint8_t)' ') * 16U];

    (void)OLED_SetCursorFast((uint8_t)((Line - 1U) * 2U), (uint8_t)((Column - 1U) * 8U));
    (void)OLED_WriteDataBlock(glyph, 8U);
    (void)OLED_SetCursorFast((uint8_t)((Line - 1U) * 2U + 1U), (uint8_t)((Column - 1U) * 8U));
    (void)OLED_WriteDataBlock(glyph + 8, 8U);
}

/**
  * @brief  OLED显示字符串
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  String 要显示的字符串，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowString(uint8_t Line, uint8_t Column, const char *String)
{
    uint16_t i;
    if (String == 0 || Line < 1U || Line > 4U || Column < 1U || Column > 16U) return;
    for (i = 0U; String[i] != '\0' && ((uint16_t)Column + i) <= 16U; i++)
        OLED_ShowChar(Line, (uint8_t)((uint16_t)Column + i), String[i]);
}

/**
  * @brief  OLED次方函数
  * @retval 返回值等于X的Y次方
  */
uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--)
	{
		Result *= X;
	}
	return Result;
}

/**
  * @brief  OLED显示数字（十进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~4294967295
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0');
	}
}

/**
  * @brief  OLED显示数字（十进制，带符号数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：-2147483648~2147483647
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length)
{
	uint8_t i;
	uint32_t Number1;
	if (Number >= 0)
	{
		OLED_ShowChar(Line, Column, '+');
		Number1 = Number;
	}
	else
	{
		OLED_ShowChar(Line, Column, '-');
		Number1 = -Number;
	}
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0');
	}
}

/**
  * @brief  OLED显示数字（十六进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~0xFFFFFFFF
  * @param  Length 要显示数字的长度，范围：1~8
  * @retval 无
  */
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i, SingleNumber;
	for (i = 0; i < Length; i++)							
	{
		SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
		if (SingleNumber < 10)
		{
			OLED_ShowChar(Line, Column + i, SingleNumber + '0');
		}
		else
		{
			OLED_ShowChar(Line, Column + i, SingleNumber - 10 + 'A');
		}
	}
}

/**
  * @brief  OLED显示数字（二进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~1111 1111 1111 1111
  * @param  Length 要显示数字的长度，范围：1~16
  * @retval 无
  */
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(2, Length - i - 1) % 2 + '0');
	}
}

/**
  * @brief  OLED初始化
  * @param  无
  * @retval 无
  */
static uint8_t OLED_ControllerInit(void)
{
    /*
     * 将初始化命令合并到同一笔命令事务，避免逐字节 START/STOP 期间出现
     * 不必要的总线空隙。绝不发送 0xAE，运行中重新同步不会主动关闭显示。
     */
    static const uint8_t init_commands[] = {
        0xD5U, 0x80U, 0xA8U, 0x3FU, 0xD3U, 0x00U, 0x40U,
        0xA1U, 0xC8U, 0xDAU, 0x12U, 0x81U, 0xCFU, 0xD9U,
        0xF1U, 0xDBU, 0x30U, 0xA4U, 0xA6U, 0x8DU, 0x14U,
        0x20U, 0x02U, 0xAFU
    };
    return OLED_I2C_WriteTransaction(0x00U, init_commands,
                                     (uint8_t)sizeof(init_commands));
}

void OLED_Init(void)
{
    uint32_t i, j;
    for (i = 0U; i < 1000U; i++)
        for (j = 0U; j < 1000U; j++) { __NOP(); }

    OLED_I2C_Init();
    (void)OLED_ControllerInit();
    OLED_Clear();
}


/* ================= OLED 128x64 framebuffer graphics ================= */
static uint8_t OLED_GFX_Buffer[8][128];
/* 已成功写入 OLED 的页缓存；只发送变化页以减少移动时的事务开销。 */
static uint8_t OLED_GFX_Sent[8][128];
static uint8_t OLED_GFX_SentValid[8] = {0U};
#define OLED_GFX_PAGE_SIZE 128U

void OLED_GFX_Clear(void)
{
    uint8_t page, x;
    for (page = 0; page < 8; page++)
        for (x = 0; x < 128; x++)
            OLED_GFX_Buffer[page][x] = 0x00;
}

void OLED_GFX_DrawPixel(int16_t x, int16_t y, uint8_t color)
{
    uint8_t page, bit;
    if (x < 0 || x >= 128 || y < 0 || y >= 64) return;
    page = (uint8_t)y >> 3;
    bit = (uint8_t)y & 0x07;
    if (color)
        OLED_GFX_Buffer[page][x] |= (uint8_t)(1U << bit);
    else
        OLED_GFX_Buffer[page][x] &= (uint8_t)~(1U << bit);
}

void OLED_GFX_FillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color)
{
    int16_t xx, yy;
    for (yy = y; yy < y + h; yy++)
        for (xx = x; xx < x + w; xx++)
            OLED_GFX_DrawPixel(xx, yy, color);
}

void OLED_GFX_DrawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color)
{
    int16_t xx, yy;
    for (xx = x; xx < x + w; xx++)
    {
        OLED_GFX_DrawPixel(xx, y, color);
        OLED_GFX_DrawPixel(xx, y + h - 1, color);
    }
    for (yy = y; yy < y + h; yy++)
    {
        OLED_GFX_DrawPixel(x, yy, color);
        OLED_GFX_DrawPixel(x + w - 1, yy, color);
    }
}

static uint8_t OLED_GFX_LineOutCode(int32_t x, int32_t y)
{
    uint8_t code = 0U;
    if (x < 0) code |= 0x01U;
    else if (x > 127) code |= 0x02U;
    if (y < 0) code |= 0x04U;
    else if (y > 63) code |= 0x08U;
    return code;
}

void OLED_GFX_DrawLine(int16_t x0_in, int16_t y0_in,
                       int16_t x1_in, int16_t y1_in, uint8_t color)
{
    int32_t x0 = x0_in, y0 = y0_in;
    int32_t x1 = x1_in, y1 = y1_in;
    int32_t dx, dy, sx, sy, err, e2;
    uint8_t code0, code1, out;
    uint8_t clip_guard = 0U;
    uint16_t step;

    /* 先裁剪到 128x64 可视区域，避免远距离端点让 Bresenham 循环过长。 */
    for (;;)
    {
        int32_t ix, iy;
        code0 = OLED_GFX_LineOutCode(x0, y0);
        code1 = OLED_GFX_LineOutCode(x1, y1);
        if ((code0 | code1) == 0U) break;
        if ((code0 & code1) != 0U || clip_guard++ >= 8U) return;

        out = (code0 != 0U) ? code0 : code1;
        if (code0 != 0U)
        {
            if ((out & 0x04U) != 0U) /* top */
            {
                if (y1 == y0) return;
                ix = x0 + (int32_t)(((int64_t)(x1 - x0) * (0 - y0)) / (y1 - y0));
                x0 = ix; y0 = 0;
            }
            else if ((out & 0x08U) != 0U) /* bottom */
            {
                if (y1 == y0) return;
                ix = x0 + (int32_t)(((int64_t)(x1 - x0) * (63 - y0)) / (y1 - y0));
                x0 = ix; y0 = 63;
            }
            else if ((out & 0x02U) != 0U) /* right */
            {
                if (x1 == x0) return;
                iy = y0 + (int32_t)(((int64_t)(y1 - y0) * (127 - x0)) / (x1 - x0));
                x0 = 127; y0 = iy;
            }
            else /* left */
            {
                if (x1 == x0) return;
                iy = y0 + (int32_t)(((int64_t)(y1 - y0) * (0 - x0)) / (x1 - x0));
                x0 = 0; y0 = iy;
            }
        }
        else
        {
            if ((out & 0x04U) != 0U) /* top */
            {
                if (y1 == y0) return;
                ix = x1 + (int32_t)(((int64_t)(x0 - x1) * (0 - y1)) / (y0 - y1));
                x1 = ix; y1 = 0;
            }
            else if ((out & 0x08U) != 0U) /* bottom */
            {
                if (y1 == y0) return;
                ix = x1 + (int32_t)(((int64_t)(x0 - x1) * (63 - y1)) / (y0 - y1));
                x1 = ix; y1 = 63;
            }
            else if ((out & 0x02U) != 0U) /* right */
            {
                if (x1 == x0) return;
                iy = y1 + (int32_t)(((int64_t)(y0 - y1) * (127 - x1)) / (x0 - x1));
                x1 = 127; y1 = iy;
            }
            else /* left */
            {
                if (x1 == x0) return;
                iy = y1 + (int32_t)(((int64_t)(y0 - y1) * (0 - x1)) / (x0 - x1));
                x1 = 0; y1 = iy;
            }
        }
    }

    dx = (x1 > x0) ? (x1 - x0) : (x0 - x1);
    dy = (y1 > y0) ? (y1 - y0) : (y0 - y1);
    sx = (x0 < x1) ? 1 : -1;
    sy = (y0 < y1) ? 1 : -1;
    err = dx - dy;

    /* 裁剪后最长线段不超过屏幕对角线；额外步数上限作为最后保护。 */
    for (step = 0U; step < 192U; step++)
    {
        OLED_GFX_DrawPixel((int16_t)x0, (int16_t)y0, color);
        if (x0 == x1 && y0 == y1) break;
        e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 < dx)  { err += dx; y0 += sy; }
    }
}

/*
 * I2C 硬件异常时临时切回 GPIO 开漏模式恢复 PB8/PB9：最多补发 9 个时钟，
 * 再生成 STOP，最后重新初始化 I2C1。该路径只在总线错误时执行，不占用正常帧。
 */
static void OLED_I2C_RecoverBus(void)
{
    GPIO_InitTypeDef gpio;
    uint8_t pulse, wait;

    I2C_Cmd(I2C1, DISABLE);
    GPIO_StructInit(&gpio);
    gpio.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
    gpio.GPIO_Mode = GPIO_Mode_Out_OD;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOB, &gpio);
    OLED_W_SDA(1);
    OLED_W_SCL(1);
    OLED_I2C_RecoveryDelay();

    for (wait = 0U; wait < 20U; wait++)
    {
        if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) != Bit_RESET) break;
    }

    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) != Bit_RESET &&
        GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9) == Bit_RESET)
    {
        for (pulse = 0U; pulse < 9U; pulse++)
        {
            OLED_W_SCL(0);
            OLED_I2C_RecoveryDelay();
            OLED_W_SCL(1);
            OLED_I2C_RecoveryDelay();
            if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9) != Bit_RESET) break;
        }
    }

    /* STOP：SCL 拉高后再释放 SDA。 */
    OLED_W_SCL(0);
    OLED_W_SDA(0);
    OLED_I2C_RecoveryDelay();
    OLED_W_SCL(1);
    OLED_I2C_RecoveryDelay();
    OLED_W_SDA(1);
    OLED_I2C_RecoveryDelay();
    OLED_I2C_Init();
}

/* 设置指定页和逻辑列地址；内部统一映射到控制器 RAM 的可视窗口。 */
static uint8_t OLED_GFX_SetAddress(uint8_t page, uint8_t column)
{
    uint8_t command[3];
    uint8_t physical_x = OLED_MapColumn(column);
    command[0] = (uint8_t)(0xB0U | (page & 0x07U));
    command[1] = (uint8_t)(0x10U | ((physical_x & 0xF0U) >> 4));
    command[2] = (uint8_t)(physical_x & 0x0FU);
    return OLED_I2C_WriteTransaction(0x00U, command, 3U);
}

/* 向 OLED 控制器写入完整一页 128 字节；每页只有一次地址事务和一次数据事务。 */
static uint8_t OLED_GFX_WritePage(uint8_t page)
{
    uint8_t retry;
    for (retry = 0U; retry < 2U; retry++)
    {
        if (OLED_GFX_SetAddress(page, 0U) != 0U &&
            OLED_I2C_WriteTransactionOnce(0x40U,
                &OLED_GFX_Buffer[page][0], OLED_GFX_PAGE_SIZE) != 0U)
            return 1U;

        if ((uint8_t)(retry + 1U) < 2U)
            OLED_I2C_RecoverBus();
    }
    return 0U;
}

/* 对比一整页的 128 字节；镜头移动时页面通常整体变化，整页发送比碎片事务更快。 */
static uint8_t OLED_GFX_PageChanged(uint8_t page)
{
    uint8_t i;
    if (OLED_GFX_SentValid[page] == 0U) return 1U;
    for (i = 0U; i < OLED_GFX_PAGE_SIZE; i++)
        if (OLED_GFX_Buffer[page][i] != OLED_GFX_Sent[page][i]) return 1U;
    return 0U;
}

static void OLED_GFX_InvalidateSent(void)
{
    uint8_t page;
    for (page = 0U; page < 8U; page++) OLED_GFX_SentValid[page] = 0U;
}

static void OLED_GFX_SaveSentPage(uint8_t page)
{
    uint8_t i;
    for (i = 0U; i < OLED_GFX_PAGE_SIZE; i++)
        OLED_GFX_Sent[page][i] = OLED_GFX_Buffer[page][i];
    OLED_GFX_SentValid[page] = 1U;
}

void OLED_GFX_Refresh(void)
{
    /*
     * 每页 128 字节合并为一笔硬件 I2C 数据事务：全屏移动场景仍传输必要的
     * 1KB 像素，但将事务数量从最多 32 组降为 8 组，并把总线提升至 400kHz。
     * 静态画面仍按页差分；每 16 次刷新巡检一页，约 6.4 秒覆盖完整屏幕。
     */
    static uint8_t scrub_page = 0U;
    static uint8_t scrub_divider = 0U;
    static uint8_t consecutive_failures = 0U;
    uint8_t page;
    uint8_t failed = 0U;

    scrub_divider++;
    if (scrub_divider >= 16U) scrub_divider = 0U;

    for (page = 0U; page < 8U; page++)
    {
        uint8_t changed = OLED_GFX_PageChanged(page);
        uint8_t scrub_this = (uint8_t)((scrub_divider == 0U && page == scrub_page) ? 1U : 0U);
        if (changed == 0U && scrub_this == 0U) continue;

        if (OLED_GFX_WritePage(page) == 0U)
        {
            OLED_GFX_SentValid[page] = 0U;
            failed = 1U;
            continue;
        }
        OLED_GFX_SaveSentPage(page);
    }

    if (scrub_divider == 0U)
        scrub_page = (uint8_t)((scrub_page + 1U) & 0x07U);

    if (failed != 0U)
    {
        if (consecutive_failures < 10U) consecutive_failures++;
        OLED_I2C_RecoverBus();
        if (consecutive_failures >= 10U)
        {
            if (OLED_ControllerInit() != 0U)
            {
                OLED_GFX_InvalidateSent();
                consecutive_failures = 0U;
            }
            else
            {
                consecutive_failures = 9U;
            }
        }
        return;
    }

    consecutive_failures = 0U;
}

/*
 * 手动恢复 OLED：PC13 按键触发时重新配置硬件 I2C、释放总线、初始化控制器，
 * 最后把现存的图形显存完整重发。故意不清空 OLED_GFX_Buffer，避免恢复后丢帧。
 */
void OLED_RecoverDisplay(void)
{
    OLED_I2C_Init();
    OLED_I2C_RecoverBus();
    OLED_GFX_InvalidateSent();
    (void)OLED_ControllerInit();
    OLED_GFX_Refresh();
}

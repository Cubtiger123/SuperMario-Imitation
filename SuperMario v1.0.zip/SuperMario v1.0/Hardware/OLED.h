#ifndef __OLED_H
#define __OLED_H

/* 初始化 OLED 控制器和 I2C1 硬件总线；字符显示 API 以 1 为起始行/列。 */
void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, const char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);


/*
 * 128x64 单色图形显存接口：坐标原点在左上角，color=1 点亮像素。
 * DrawPixel/FillRect/DrawRect/DrawLine 只更新显存，Refresh 才实际写屏。
 */
void OLED_GFX_Clear(void);
void OLED_GFX_DrawPixel(int16_t x, int16_t y, uint8_t color);
void OLED_GFX_FillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color);
void OLED_GFX_DrawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color);
void OLED_GFX_DrawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint8_t color);
void OLED_GFX_Refresh(void);
/* PC13 手动恢复键调用：重新初始化 SSD1306 并重发当前 1KB 图形显存。 */
void OLED_RecoverDisplay(void);

#endif

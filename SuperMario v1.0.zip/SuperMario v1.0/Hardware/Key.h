/* PB1 跳跃/启动按键接口：按下时 Key_GetNum() 仅返回一次非零事件。 */
#ifndef __KEY_H
#define __KEY_H
#include <stdint.h>
void Key_Init(void);
/* 每次按下只返回一次 1；未产生新按下事件时返回 0。 */
uint8_t Key_GetNum(void);
#endif

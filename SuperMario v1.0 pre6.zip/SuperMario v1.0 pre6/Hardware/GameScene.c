#include "stm32f10x.h"
#include "OLED.h"
#include "GameScene.h"
#include "PWM.h"
#include "Key.h"
#include <stdint.h>

/*
 * OLED 版 Super Mario Bros. 游戏逻辑。
 * 本文件集中管理关卡地图、碰撞、敌人、道具、音效触发和画面绘制。
 * 坐标约定：地图对象使用世界坐标；绘制到 OLED 时减去 s_camera。
 * GameScene_Task10ms() 负责按键消抖、音效/状态计时和状态切换；
 * GameScene_Update() 负责物理、碰撞、敌人行为、镜头和画面更新。
 * 受 128x64 OLED 限制，关卡为原版布局风格的缩略实现，并非 NES ROM 逐像素复刻。
 */
#define MARIO_X       27
#define MARIO_W       10
#define MARIO_H       14
#define GROUND_TOP    56
#define WORLD_LENGTH  1740
#define PIPE_COUNT    8
#define BLOCK_COUNT   72 /* 扩容后容纳每关新增砖块组。 */
#define ENEMY_COUNT   7
#define TURTLE_COUNT  3
#define ITEM_COUNT    1
#define COINS_PER_GROUP 5U
#define COIN_COUNT    70U /* 固定容量：World 1 每关 50 枚，World 2 每关 70 枚。 */
#define SKY_COIN_COUNT 24
#define CLOUD_COUNT   2
#define HEDGEHOG_COUNT 2
#define FIREBALL_COUNT 2
#define BULLET_BILL_COUNT 2
#define HAMMER_BRO_COUNT 4
#define HAMMER_COUNT 8
#define FISH_COUNT 6
#define FIREBAR_COUNT 2
#define PODOBOO_COUNT 2
#define SPRING_WIDTH 12
#define SPRING_TOP 48
#define SKY_LIFT_Y 26
#define SKY_LIFT_WIDTH 24
#define SEWER_COIN_COUNT 20
#define SEWER_WORLD_LENGTH 440
#define SEWER_EXIT_X 350
#define LIFT_COUNT 6
#define LIFT_TOP_Y 14U
#define LIFT_BOTTOM_Y 48U
#define LIFT_HALF_CYCLE (LIFT_BOTTOM_Y - LIFT_TOP_Y)
#define LIFT_PERIOD (2U * LIFT_HALF_CYCLE)
/* 1-2 六部升降台分别布置在六段悬崖上方。 */
static const int16_t s_lift_x[LIFT_COUNT] = {260, 520, 800, 1080, 1360, 1580};
#define CLIFF_LEFT    1030
#define CLIFF_RIGHT   1050 /* shorter 20-pixel gap */

static const int16_t pipe_x[PIPE_COUNT] = {190, 285, 405, 590, 770, 1015, 1280, 1450};
static const uint8_t pipe_top[PIPE_COUNT] = {40, 36, 32, 40, 36, 32, 40, 36};
static const int16_t block_x[BLOCK_COUNT] = {
  540, 549, 558, 470, 479, 488, 665, 674, 683,
  880, 889, 898, 1040, 1049, 1058, 1190, 1199, 1208,
  1360, 1369, 1378, 1500, 1509, 1518, 1527, 1536, 920,
  333, 342, 351, 497, 506, 515, 1080, 1089, 1098,
  390, 399, 408, 735, 744, 753, 1100, 1109, 1118,
  1400, 1409, 1418, 0, 0, 0, 0, 0, 0
};
static const uint8_t block_y[BLOCK_COUNT] = {
  36, 36, 36, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 36, 36, 36,
  36, 36, 36, 29, 29, 29, 29, 29, 29,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 0, 0, 0, 0, 0, 0
};
static const int16_t enemy_start[ENEMY_COUNT] = {155, 360, 545, 735, 955, 1190, 1400};
static const int16_t item_start[ITEM_COUNT] = {320};
static const int16_t turtle_start[TURTLE_COUNT] = {270, 820, 1325};

/* WORLD 2-1：地面关，采用更长的砖块组间距和分散的管道。 */
static const int16_t pipe_x_21[PIPE_COUNT] = {205, 390, 590, 805, 1015, 1230, 1450, 1650};
static const uint8_t pipe_top_21[PIPE_COUNT] = {40,36,32,40,36,32,40,36};
static const int16_t block_x_21[BLOCK_COUNT] = {
  250, 259, 268, 440, 449, 458, 625, 634, 643,
  830, 839, 848, 1035, 1044, 1053, 1190, 1199, 1208,
  1370, 1379, 1388, 1510, 1519, 1528, 1537, 1546, 930,
  300, 309, 318, 700, 709, 718, 1110, 1119, 1128,
  900, 909, 918, 467, 476, 485, 652, 661, 670,
  1300, 1309, 1318, 0, 0, 0, 0, 0, 0
};
static const uint8_t block_y_21[BLOCK_COUNT] = {
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 29, 29, 36,
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 0, 0, 0, 0, 0, 0
};
static const int16_t enemy_start_21[ENEMY_COUNT] = {190,410,635,855,1065,1285,1495};
static const int16_t turtle_start_21[TURTLE_COUNT] = {300,900,1400};

/* WORLD 2-2：水下主题关卡；索引 27~35 构成带 18px 游泳通道的起点高墙。 */
static const int16_t pipe_x_22[PIPE_COUNT] = {160,350,545,740,935,1130,1330,1640};
static const uint8_t pipe_top_22[PIPE_COUNT] = {44,40,36,44,40,36,44,40};
static const int16_t block_x_22[BLOCK_COUNT] = {
  280, 289, 298, 470, 479, 488, 660, 669, 678,
  850, 859, 868, 1040, 1049, 1058, 1230, 1239, 1248,
  1400, 1409, 1418, 1510, 1519, 1528, 1537, 1546, 960,
  100, 109, 118, 100, 109, 118, 100, 109, 118,
  1000, 1009, 1018, 760, 769, 778, 199, 208, 217,
  398, 407, 416, 0, 0, 0, 0, 0, 0
};
static const uint8_t block_y_22[BLOCK_COUNT] = {
  30, 30, 30, 38, 38, 38, 30, 30, 30,
  38, 38, 38, 30, 30, 30, 38, 38, 38,
  30, 30, 30, 38, 38, 38, 38, 38, 30,
  /* 高墙上下两段之间留出 18px 通道，马里奥可在水中游过。 */
  11, 11, 11, 38, 38, 38, 47, 47, 47,
  30, 30, 30, 38, 38, 38, 38, 38, 38,
  30, 30, 30, 0, 0, 0, 0, 0, 0
};
static const int16_t enemy_start_22[ENEMY_COUNT] = {230,440,650,870,1080,1300,1500};
static const int16_t turtle_start_22[TURTLE_COUNT] = {320,980,1450};

/* WORLD 2-3：桥梁/平台关，地图中用间断地面表现水面上的桥段。 */
static const int16_t pipe_x_23[PIPE_COUNT] = {180,370,570,770,970,1170,1370,1570};
static const uint8_t pipe_top_23[PIPE_COUNT] = {40,36,40,36,40,36,40,36};
static const int16_t block_x_23[BLOCK_COUNT] = {
  230, 239, 248, 420, 429, 438, 610, 619, 628,
  800, 809, 818, 990, 999, 1008, 1190, 1199, 1208,
  1260, 1269, 1278, 1390, 1399, 1408, 1417, 1426, 880,
  300, 309, 318, 700, 709, 718, 1100, 1109, 1118,
  1500, 1509, 1518, 730, 739, 748, 1070, 1079, 1088,
  447, 456, 465, 637, 646, 655, 0, 0, 0
};
static const uint8_t block_y_23[BLOCK_COUNT] = {
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 29, 29, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 0, 0, 0
};
static const int16_t enemy_start_23[ENEMY_COUNT] = {260,470,680,890,1100,1310,1510};
static const int16_t turtle_start_23[TURTLE_COUNT] = {350,950,1420};

/* WORLD 2-4：第二世界城堡，Boss 的耐久和城堡外观会进一步增加。 */
static const int16_t pipe_x_24[PIPE_COUNT] = {160,360,560,760,960,1160,1360,1540};
static const uint8_t pipe_top_24[PIPE_COUNT] = {40,40,36,40,36,40,36,40};
static const int16_t block_x_24[BLOCK_COUNT] = {
  230, 239, 248, 430, 439, 448, 620, 629, 638,
  830, 839, 848, 1030, 1039, 1048, 1210, 1219, 1228,
  1390, 1399, 1408, 1560, 1569, 1578, 1587, 1596, 980,
  300, 309, 318, 690, 699, 708, 1110, 1119, 1128,
  380, 389, 398, 780, 789, 798, 1300, 1309, 1318,
  1470, 1479, 1488, 457, 466, 475, 857, 866, 875
};
static const uint8_t block_y_24[BLOCK_COUNT] = {
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 29, 29, 29,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29
};
static const int16_t enemy_start_24[ENEMY_COUNT] = {280,500,720,940,1160,1380,1510};
static const int16_t turtle_start_24[TURTLE_COUNT] = {400,880,1300};

/* WORLD 1-2：地下关原始地图数据采用两档高度；BlockY() 会微调平台高度，
 * 实际平台为 y=31 与 y=29，既为地面角色留出下方通道，也保留原本可跳上的高层平台。 */
static const int16_t pipe_x_12[PIPE_COUNT] = {150, 330, 515, 700, 890, 1090, 1320, 1640};
static const uint8_t pipe_top_12[PIPE_COUNT] = {36, 32, 40, 36, 32, 40, 36, 32};
static const int16_t block_x_12[BLOCK_COUNT] = {
  275, 284, 293, 455, 464, 473, 660, 669, 678,
  820, 829, 838, 960, 969, 978, 1110, 1119, 1128,
  1270, 1279, 1288, 1410, 1419, 1428, 1437, 1446, 920,
  1000, 1009, 1018, 189, 198, 207, 378, 387, 396,
  1040, 1049, 1058, 760, 769, 778, 1180, 1189, 1198,
  1460, 1469, 1478, 0, 0, 0, 0, 0, 0
};
static const uint8_t block_y_12[BLOCK_COUNT] = {
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 0, 0, 0, 0, 0, 0
};
static const int16_t enemy_start_12[ENEMY_COUNT] = {220, 420, 640, 850, 1080, 1300, 1510};
static const int16_t item_start_12[ITEM_COUNT] = {390};
static const int16_t turtle_start_12[TURTLE_COUNT] = {300, 970, 1450};
/* WORLD 1-3: sky/overworld bonus route with vine and winged Koopas. */
static const int16_t pipe_x_13[PIPE_COUNT] = {180, 390, 610, 820, 1030, 1210, 1390, 1510};
static const uint8_t pipe_top_13[PIPE_COUNT] = {40,36,32,40,36,32,40,36};
static const int16_t block_x_13[BLOCK_COUNT] = {
  220, 229, 238, 760, 769, 778, 630, 639, 648,
  790, 799, 808, 970, 979, 988, 1140, 1149, 1158,
  1240, 1249, 1258, 1330, 1339, 1348, 1357, 1366, 850,
  300, 309, 318, 700, 709, 718, 438, 447, 456,
  528, 537, 546, 930, 939, 948, 1050, 1059, 1068,
  1460, 1469, 1478, 0, 0, 0, 0, 0, 0
};
static const uint8_t block_y_13[BLOCK_COUNT] = {
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 29, 29, 36,
  29, 29, 29, 36, 36, 36, 36, 36, 36,
  29, 29, 29, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 0, 0, 0, 0, 0, 0
};
static const int16_t enemy_start_13[ENEMY_COUNT] = {300,520,740,960,1160,1350,1480};
static const int16_t turtle_start_13[TURTLE_COUNT] = {430,900,1370};
/* WORLD 1-4：城堡战斗区；击败库巴后公主出现，公主为本关终点。 */
static const int16_t pipe_x_14[PIPE_COUNT] = {160,360,560,760,960,1160,1360,1540};
static const uint8_t pipe_top_14[PIPE_COUNT] = {40,40,36,40,36,40,36,40};
static const int16_t block_x_14[BLOCK_COUNT] = {
  260, 269, 278, 490, 499, 508, 700, 709, 718,
  920, 929, 938, 1120, 1129, 1138, 1300, 1309, 1318,
  1450, 1459, 1468, 1560, 1569, 1578, 1587, 1596, 980,
  330, 339, 348, 600, 609, 618, 1080, 1089, 1098,
  199, 208, 217, 408, 417, 426, 1060, 1069, 1078,
  1460, 1469, 1478, 0, 0, 0, 0, 0, 0
};
static const uint8_t block_y_14[BLOCK_COUNT] = {
  36, 36, 36, 29, 29, 29, 36, 36, 36,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 29, 29, 29,
  29, 29, 29, 36, 36, 36, 29, 29, 29,
  36, 36, 36, 29, 29, 29, 18, 18, 18,
  36, 36, 36, 0, 0, 0, 0, 0, 0
};
static const int16_t enemy_start_14[ENEMY_COUNT] = {280,500,720,940,1160,1380,1510};
static const int16_t turtle_start_14[TURTLE_COUNT] = {400,880,1300};
static uint8_t s_level = 1;
static int16_t s_stair_x_cache[8];
static uint8_t s_stair_layout_ready;
/* 地图砖块避让管道：新增砖块也放在管道净空区之外，避免形成跳跃死角。 */


/* 关卡编号：1~4 对应 WORLD 1-1~1-4；5~8 对应 WORLD 2-1~2-4。 */
/* Pipe helpers are used by spawn/collision code before their definitions below. */
static int16_t PipeX(uint8_t i);
static uint8_t PipeActiveCount(void);
static uint16_t WorldLength(void);
static uint8_t ActiveBlockCount(void);
static int16_t BlockX(uint8_t i);
static uint8_t BlockY(uint8_t i);
static uint8_t IsWorld2(void) { return (s_level >= 5U) ? 1U : 0U; }
static uint8_t IsUnderwaterLevel(void) { return (s_level == 6U) ? 1U : 0U; }
static uint8_t IsCastleLevel(void) { return (s_level == 4U || s_level == 8U) ? 1U : 0U; }
/* 1-2 / 2-2 的最终出口是横向管道，不绘制城堡终点。 */
static uint8_t IsHorizontalGoalPipeLevel(void) { return (s_level==2U || s_level==6U) ? 1U : 0U; }
static uint8_t LevelCoinCount(void) { return (s_level==7U)?0U:(IsWorld2()?70U:50U); }
static int16_t GoalPipeX(void) { return (int16_t)(WorldLength()-84U); }
static uint16_t WorldLength(void) { return (s_level==7U)?1600U:((s_level==3U)?1580U:1760U); }
static int16_t GoalX(void) { return (s_level==3U)?1480:((s_level==7U)?1500:1660); }
/* 公主位于城堡桥的后方，作为 1-4 / 2-4 的实际救援终点。 */
static int16_t PrincessX(void) { return (int16_t)(GoalX()+64); }

/* 各关卡的多组经典阶梯，避开主要水管并保留城堡桥前的通行空间。 */
static uint8_t StaircaseBaseCount(void)
{
 static const uint8_t count[8] = {4U,4U,4U,2U,4U,4U,3U,2U};
 return (s_level==7U)?0U:count[(s_level>=1U && s_level<=8U)?(s_level-1U):0U];
}
/* 每组正向楼梯都配一组反向矮楼梯；末端城堡/终点区域不放反向楼梯。 */
static uint8_t StaircaseCount(void) { return (uint8_t)(StaircaseBaseCount()*2U); }
static uint8_t StaircaseRows(void) { return (s_level==6U)?2U:4U; }
static uint8_t StaircaseRowsFor(uint8_t index) { return (index&1U)?2U:StaircaseRows(); }
static uint8_t StairCandidateTouchesBrick(uint8_t index,int16_t candidate)
{
 uint8_t row,col,b,rows=StaircaseRowsFor(index);
 for(row=0U;row<rows;row++)for(col=0U;col<(uint8_t)(rows-row);col++){
  int16_t stair_x=(int16_t)(candidate+(int16_t)(((index&1U)?col:(uint8_t)(row+col))*9U));
  int16_t stair_y=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
  for(b=0U;b<ActiveBlockCount();b++){
   int16_t block_x=BlockX(b),block_y=BlockY(b);
   /* 至少保留一格砖宽的横向净距，避免阶梯与砖块连成不可落脚的墙。 */
   if(stair_x+18>block_x && stair_x-9<block_x+9 &&
      stair_y+9>block_y-2 && stair_y<block_y+11)return 1U;
  }
 }
 return 0U;
}
static uint8_t StairCandidateTouchesOtherStair(uint8_t index,int16_t candidate)
{
 uint8_t other,row,col,rows=StaircaseRowsFor(index);
 for(other=0U;other<index;other++){
  uint8_t other_rows=StaircaseRowsFor(other);
  for(row=0U;row<rows;row++)for(col=0U;col<(uint8_t)(rows-row);col++){
   int16_t ax=(int16_t)(candidate+(int16_t)(((index&1U)?col:(uint8_t)(row+col))*9U));
   int16_t ay=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
   uint8_t other_row,other_col;
   for(other_row=0U;other_row<other_rows;other_row++)for(other_col=0U;other_col<(uint8_t)(other_rows-other_row);other_col++){
    int16_t bx=(int16_t)(s_stair_x_cache[other]+(int16_t)(((other&1U)?other_col:(uint8_t)(other_row+other_col))*9U));
    int16_t by=(int16_t)(GROUND_TOP-9-(int16_t)other_row*9);
    /* 不同楼梯组之间至少留 2 像素，避免两组台阶连成一整堵墙。 */
    if(ax+9>bx-2 && ax<bx+11 && ay+9>by-2 && ay<by+11)return 1U;
   }
  }
 }
 return 0U;
}
static void BuildStaircaseLayout(void)
{
 static const int16_t x[8][4] = {
  {610,820,1140,1330}, {550,850,1215,1410},
  {470,890,1080,1300}, {640,1020,0,0},
  {520,740,1140,1380}, {430,800,1270,1540},
  {500,920,1300,0}, {500,890,0,0}
 };
 static const int16_t reverse_x[8][4] = {
  {695,938,1109,1388}, {488,794,1298,1361}, {416,1001,1118,1271},
  {731,992,0,0}, {569,785,1253,1343}, {371,713,1208,1451},
  {398,893,1235,0}, {335,938,0,0}
 };
 uint8_t level_index=(s_level>=1U && s_level<=8U)?(uint8_t)(s_level-1U):0U;
 uint8_t index;
 int16_t max_x=(int16_t)(WorldLength()-90U);
 for(index=0U;index<StaircaseCount();index++){
  uint8_t base=(uint8_t)(index/2U);
  int16_t preferred=(index&1U)?reverse_x[level_index][base]:x[level_index][base];
  int16_t chosen=preferred;
  uint16_t delta;
  uint8_t found=0U;
  /* 在原坐标附近按 9 像素网格向两侧搜索；每组只计算一次，避免每帧重复扫描砖块。 */
  for(delta=0U;delta<=(uint16_t)WorldLength() && !found;delta=(uint16_t)(delta+9U)){
   int16_t candidates[2];
   uint8_t n;
   candidates[0]=(int16_t)(preferred+(int16_t)delta);
   candidates[1]=(int16_t)(preferred-(int16_t)delta);
   for(n=0U;n<2U;n++){
    int16_t candidate=candidates[n];
    if(n==1U && delta==0U)continue;
    if(candidate<18 || candidate>max_x)continue;
    if(StairCandidateTouchesBrick(index,candidate) || StairCandidateTouchesOtherStair(index,candidate))continue;
    chosen=candidate;found=1U;break;
   }
  }
  /* 关卡空间若极端拥挤，使用边界内最近的候选点；当前八关布局均可找到净空位置。 */
  if(!found){if(chosen<18)chosen=18;if(chosen>max_x)chosen=max_x;}
  s_stair_x_cache[index]=chosen;
 }
 s_stair_layout_ready=1U;
}
static int16_t StaircaseX(uint8_t index)
{
 if(index>=StaircaseCount())return -1;
 if(!s_stair_layout_ready)BuildStaircaseLayout();
 return s_stair_x_cache[index];
}
static int16_t StairBlockX(uint8_t staircase,uint8_t row,uint8_t col)
{
 int16_t x=StaircaseX(staircase);
 return (int16_t)(x+(int16_t)(((staircase&1U)?col:(uint8_t)(row+col))*9U));
}
/* 阶梯是实心方块；供敌人横向移动时检测侧碰撞。 */
static uint8_t IntersectsStairBlock(int16_t object_x,int16_t object_y,uint8_t object_w,uint8_t object_h)
{
 uint8_t st,row,col;
 for(st=0U;st<StaircaseCount();st++)for(row=0U;row<StaircaseRowsFor(st);row++)for(col=0U;col<(uint8_t)(StaircaseRowsFor(st)-row);col++){
  int16_t bx=StairBlockX(st,row,col);
  int16_t by=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
  if(object_x+object_w>bx && object_x<bx+9 && object_y+object_h>by && object_y<by+9)return 1U;
 }
 return 0U;
}
/* 敌人与锤子兄弟出生点避开楼梯实体；向两侧逐格搜索，避免把怪物放进台阶内部。 */
static int16_t SpawnOutsideStairs(int16_t x,int16_t y,uint8_t w,uint8_t h)
{
 uint8_t step;
 if(!IntersectsStairBlock(x,y,w,h))return x;
 for(step=1U;step<=12U;step++){
  int16_t right=(int16_t)(x+(int16_t)step*18);
  int16_t left=(int16_t)(x-(int16_t)step*18);
  if(right+w<WorldLength()-8 && !IntersectsStairBlock(right,y,w,h))return right;
  if(left>8 && !IntersectsStairBlock(left,y,w,h))return left;
 }
 return x;
}
#define BOSS_WIDTH 18
#define BOSS_HEIGHT 16
static int16_t BossBridgeLeft(void) { return (int16_t)(GoalX()-210); }
static uint8_t BossBridgeWidth(void) { return (uint8_t)(s_level==8U?200U:180U); }
static int16_t BossBridgeTop(void) { return 46; }
static int16_t BossStandingY(void) { return (int16_t)(BossBridgeTop()-BOSS_HEIGHT+1); }
/* 库巴初始位于桥面中央，横向巡逻范围也限制在桥面内。 */
static int16_t BossX(void) { return (int16_t)(BossBridgeLeft()+((int16_t)BossBridgeWidth()-BOSS_WIDTH)/2); }
static int16_t SpringX(void) { return 980; }
static uint8_t SpringActive(void) { return (s_level==5U)?1U:0U; }
static uint8_t PipeExitIndex(uint8_t entry_index)
{
 /* 水平终点管替代原第 7 号竖管；保留的第 6 号普通管改从第 5 号管出场。 */
 if(IsHorizontalGoalPipeLevel() && entry_index==6U)return 5U;
 /* 普通管道按相邻两根成对连接；进入后始终从另一根管道出现。 */
 return (entry_index&1U)?(uint8_t)(entry_index-1U):(uint8_t)(entry_index+1U);
}
static int16_t PipeX(uint8_t i)
{
 if(s_level==2U)return pipe_x_12[i];
 if(s_level==3U)return pipe_x_13[i];
 if(s_level==4U)return pipe_x_14[i];
 if(s_level==5U)return pipe_x_21[i];
 if(s_level==6U)return pipe_x_22[i];
 if(s_level==7U)return pipe_x_23[i];
 if(s_level==8U)return pipe_x_24[i];
 return pipe_x[i];
}
static uint8_t PipeTop(uint8_t i)
{
 uint8_t top;
 if(s_level==2U)top=pipe_top_12[i];
 else if(s_level==3U)top=pipe_top_13[i];
 else if(s_level==4U)top=pipe_top_14[i];
 else if(s_level==5U)top=pipe_top_21[i];
 else if(s_level==6U)top=pipe_top_22[i];
 else if(s_level==7U)top=pipe_top_23[i];
 else if(s_level==8U)top=pipe_top_24[i];
 else top=pipe_top[i];
 /* 屏幕空间地面在 56；将竖管限制为最多 18px 高，避免无法越过。 */
 return (top<38U)?38U:top;
}
static uint8_t PipeActiveCount(void) { return (s_level==7U || IsCastleLevel())?0U:(IsHorizontalGoalPipeLevel()?7U:PIPE_COUNT); }
static uint8_t BaseActiveBlockCount(void) { return (uint8_t)(36U + (uint16_t)(s_level-1U) * 3U); }
static uint8_t LegacyExtraBlockCount(void) { return (s_level==8U)?3U:5U; }
static uint8_t NewExtraBlockCount(void) { return 5U; }
/* 在原有新增组之外，再增加一组 5 块砖；每关的总量都不超过数组容量。 */
static uint8_t ActiveBlockCount(void)
{
 uint16_t count;
 if(s_level==7U)return 0U;
 count=(uint16_t)BaseActiveBlockCount()+LegacyExtraBlockCount()+NewExtraBlockCount();
 return (uint8_t)(count>BLOCK_COUNT?BLOCK_COUNT:count);
}
static int16_t ExtraBlockStartX(void)
{
 static const int16_t x[8]={960,600,560,840,960,580,1017,1327};
 return x[(s_level>=1U && s_level<=8U)?(s_level-1U):0U];
}
static int16_t ExtraBlock2StartX(void)
{
 /* 新砖块组放在管道/阶梯空档；1-3 单独上移，避开末端旗杆并与管道错层。 */
 static const int16_t x[8]={1228,1160,1168,790,1062,1470,830,1058};
 return x[(s_level>=1U && s_level<=8U)?(s_level-1U):0U];
}
static uint8_t NewExtraBlockStartIndex(void)
{
 return (uint8_t)(BaseActiveBlockCount()+LegacyExtraBlockCount());
}
static int16_t BlockX(uint8_t i)
{
 uint8_t base=BaseActiveBlockCount(),legacy=LegacyExtraBlockCount();
 if(i>=base && i<(uint8_t)(base+legacy))
  return (int16_t)(ExtraBlockStartX()+(int16_t)(i-base)*9);
 if(i>=(uint8_t)(base+legacy) && i<(uint8_t)(base+legacy+NewExtraBlockCount()))
  return (int16_t)(ExtraBlock2StartX()+(int16_t)(i-base-legacy)*9);
 /* WORLD 2-4 将原有一组三块砖移出 1300 区域，避免与桥前六块连续砖重叠。 */
 if(s_level==8U && i>=42U && i<=44U)return (int16_t)(1180+(int16_t)(i-42U)*9);
 /* 旧地图尾部高位砖仍保留原坐标。 */
 if(s_level==6U && i>=48U)return (int16_t)(1000+(i-48U)*9U);
 if(s_level==7U && i>=51U)return (int16_t)(1500+(i-51U)*9U);
 if(s_level==8U && i>=54U)return (int16_t)(1300+(i-54U)*9U);
 if(s_level==2U)return block_x_12[i];
 if(s_level==3U)return block_x_13[i];
 if(s_level==4U)return block_x_14[i];
 if(s_level==5U)return block_x_21[i];
 if(s_level==6U)return block_x_22[i];
 if(s_level==7U)return block_x_23[i];
 if(s_level==8U)return block_x_24[i];
 return block_x[i];
}
static uint8_t BlockY(uint8_t i)
{
 uint8_t y;
 /* 旧新增组在 y=25；本次新增组一般位于 y=29，1-3 调至 y=20 以避开末端实体。 */
 if(i>=BaseActiveBlockCount() && i<(uint8_t)(BaseActiveBlockCount()+LegacyExtraBlockCount()))return 25U;
 if(i>=NewExtraBlockStartIndex() && i<(uint8_t)(NewExtraBlockStartIndex()+NewExtraBlockCount()))return (s_level==3U)?20U:29U;
 if((s_level==6U && i>=48U)||(s_level==7U && i>=51U))return 18U;
 if(s_level==8U && i>=54U)return 25U;
 if(s_level==2U)y=block_y_12[i];
 else if(s_level==3U)y=block_y_13[i];
 else if(s_level==4U)y=block_y_14[i];
 else if(s_level==5U)y=block_y_21[i];
 else if(s_level==6U)y=block_y_22[i];
 else if(s_level==7U)y=block_y_23[i];
 else if(s_level==8U)y=block_y_24[i];
 else y=block_y[i];
 /*
  * 地面/地下/桥梁/城堡关的旧 y=36 平台底部会到 y=45，
  * 与地面马里奥的身体范围（顶部约 y=42）重叠，导致角色无法从砖块下方通过。
  * 现将平台高度调整为 y=31 与 y=29：砖块底面分别为 y=40 / y=38，
  * 地面角色顶部 y=42 下方至少留 2 像素通道；原高层 y=29 保持不变，避免增加跳跃难度。
  * 水下关的高墙布局有意贴近地面/顶部，保持原坐标不变。
  */
 if(s_level!=6U && y==36U)y=31U;
 return y;
}
static int16_t EnemyStart(uint8_t i)
{
 if(s_level==2U)return enemy_start_12[i];
 if(s_level==3U)return enemy_start_13[i];
 if(s_level==4U)return enemy_start_14[i];
 if(s_level==5U)return enemy_start_21[i];
 if(s_level==6U)return enemy_start_22[i];
 if(s_level==7U)return enemy_start_23[i];
 if(s_level==8U)return enemy_start_24[i];
 return enemy_start[i];
}
static int16_t TurtleStart(uint8_t i)
{
 if(s_level==2U)return turtle_start_12[i];
 if(s_level==3U)return turtle_start_13[i];
 if(s_level==4U)return turtle_start_14[i];
 if(s_level==5U)return turtle_start_21[i];
 if(s_level==6U)return turtle_start_22[i];
 if(s_level==7U)return turtle_start_23[i];
 if(s_level==8U)return turtle_start_24[i];
 return turtle_start[i];
}
static int16_t ItemStart(uint8_t i) { (void)i; return IsWorld2() ? 410 : (s_level==2U?item_start_12[0]:item_start[0]); }
/* 每关五个问号箱；索引 26 是独立特殊砖块，World 1 的四关可掉落无敌星星。 */
static uint8_t IsQuestionBlock(uint8_t i) { return (i==1U || i==7U || i==13U || i==19U || i==25U); }
static uint8_t IsTenCoinBlock(uint8_t i) { return (i==25U)?1U:0U; }
static uint8_t IsHiddenCoinBlock(uint8_t i) { return (i==3U || i==16U || i==30U || i==42U || i==54U); }
static uint8_t BlockWidth(uint8_t i) { (void)i; return 9U; }
static uint8_t BlockMergedFollower(uint8_t i) { (void)i; return 0U; }
static const char *LevelName(void)
{
 static const char *const names[8] = {"WORLD 1-1","WORLD 1-2","WORLD 1-3","WORLD 1-4","WORLD 2-1","WORLD 2-2","WORLD 2-3","WORLD 2-4"};
 return (s_level>=1U && s_level<=8U)?names[s_level-1U]:"WORLD 1-1";
}
/* 金币按 5 枚一组沿关卡分布；首组固定悬在新增砖块组上方。 */
static int16_t s_coin_x[COIN_COUNT],s_coin_y[COIN_COUNT];
static uint8_t CoinOnBrick(uint8_t index) { return (index<COINS_PER_GROUP)?1U:0U; }
static uint8_t CoinSupportBlock(uint8_t index)
{
 return (uint8_t)(NewExtraBlockStartIndex()+(index%COINS_PER_GROUP));
}
/* 其余金币组在多个高度/相邻空档中搜索，避免被砖块、水管或阶梯遮住。 */
static uint8_t CoinGroupSpotClear(int16_t start_x,int16_t y)
{
 uint8_t n,i;
 for(n=0U;n<COINS_PER_GROUP;n++){
  int16_t cx=(int16_t)(start_x+(int16_t)n*9);
  for(i=0U;i<ActiveBlockCount();i++){
   int16_t bx=BlockX(i),by=BlockY(i);
   if(cx+8>bx && cx<bx+BlockWidth(i) && y+8>by && y<by+9)return 0U;
  }
  for(i=0U;i<PipeActiveCount();i++){
   int16_t px=PipeX(i);
   if(cx+8>px && cx<px+17 && y+8>PipeTop(i) && y<GROUND_TOP)return 0U;
  }
  if(IsHorizontalGoalPipeLevel()){
   int16_t gx=GoalPipeX();
   if(cx+8>gx && cx<gx+38 && y+8>30 && y<55)return 0U;
  }
  if(IntersectsStairBlock(cx,y,8U,8U))return 0U;
  /* 1-2 的升降台会在 14~48 像素范围移动，金币不放在其扫掠区域。 */
  if(s_level==2U){
   uint8_t lift;
   for(lift=0U;lift<LIFT_COUNT;lift++)
    if(cx+8>s_lift_x[lift] && cx<s_lift_x[lift]+28 && y+8>14 && y<48)return 0U;
  }
 }
 return 1U;
}
static void BuildCoinLayout(void)
{
 static const int8_t x_offset[11]={0,-9,9,-18,18,-27,27,-36,36,-45,45};
 static const uint8_t y_candidates[8]={22U,26U,20U,32U,38U,44U,14U,8U};
 uint8_t group,n,oi,yi;
 uint8_t total=LevelCoinCount();
 if(total==0U)return;
 for(n=0U;n<COINS_PER_GROUP;n++){
  uint8_t block=CoinSupportBlock(n);
  s_coin_x[n]=(int16_t)(BlockX(block)+1);
  s_coin_y[n]=(int16_t)(BlockY(block)-8);
 }
 for(group=1U;group<(uint8_t)(total/COINS_PER_GROUP);group++){
  uint16_t span=(uint16_t)(WorldLength()-260U);
  uint8_t group_count=(uint8_t)(total/COINS_PER_GROUP);
  uint8_t denominator=(group_count>2U)?(uint8_t)(group_count-2U):1U;
  int16_t nominal=(int16_t)(100U+((uint16_t)(group-1U)*span)/denominator);
  int16_t chosen_x=nominal,chosen_y=22;
  uint8_t found=0U;
  for(yi=0U;yi<8U && !found;yi++){
   for(oi=0U;oi<11U;oi++){
    int16_t candidate=(int16_t)(nominal+x_offset[oi]);
    if(candidate<40 || candidate+44>WorldLength()-40)continue;
    if(CoinGroupSpotClear(candidate,y_candidates[yi])){
     chosen_x=candidate;chosen_y=y_candidates[yi];found=1U;break;
    }
   }
  }
  for(n=0U;n<COINS_PER_GROUP;n++){
   uint8_t index=(uint8_t)(group*COINS_PER_GROUP+n);
   s_coin_x[index]=(int16_t)(chosen_x+(int16_t)n*9);
   s_coin_y[index]=chosen_y;
  }
 }
}
static int16_t CoinX(uint8_t index) { return s_coin_x[index]; }
static int16_t CoinY(uint8_t index) { return s_coin_y[index]; }

typedef struct { uint16_t hz; uint8_t ticks; } SfxNote;
static void StartGameSfx(const SfxNote *p,uint8_t n);
static uint8_t s_sfx_priority=0U;
/*
 * 单声道蜂鸣器音效库：频率单位 Hz，ticks 每格为 10ms。
 * 参考用户提供的 smb-2j.zip 中 smb 目录中的 WAV 音源，按 PA0 无源蜂鸣器能力
 * 改编成单音旋律。原 WAV 是多声道/多音色采样，不能直接由单路 PWM 还原；
 * 这里保留主要音高走向与节奏，后续新增音效只需增加音符表并调用 StartGameSfx。
 */
/* 音高序列按用户提供的 NES 原版 WAV 频谱轮廓重新校准；单声道蜂鸣器仅能近似原音色。 */
static const SfxNote jump_sfx[]       = {{330,1},{294,1},{330,1},{375,1},{422,1},{469,1},{516,1},{562,1},{0,1}}; /* SMB 跳跃短版：约 90ms */
static const SfxNote small_jump_sfx[] = {{422,1},{469,1},{422,1},{469,1},{516,1},{562,1},{609,1},{656,1},{703,1},{750,1},{844,1},{0,1}}; /* 小马里奥跳跃短版：约 120ms */
static const SfxNote swim_sfx[]       = {{523,1},{659,1},{784,1},{0,1}};                 /* 游泳短音：约 40ms */
static const SfxNote stomp_sfx[]      = {{784,2},{988,3},{0,1}};                         /* smbkickkill/stomp */
static const SfxNote kick_sfx[]       = {{392,2},{587,2},{784,3},{0,1}};                  /* 踢龟壳 */
static const SfxNote bump_sfx[]       = {{220,2},{165,3},{0,1}};                          /* smbbump.wav */
static const SfxNote brick_sfx[]      = {{392,1},{523,1},{659,2},{784,2},{0,1}};         /* smbbrick.wav */
static const SfxNote coin_sfx[]       = {{988,3},{1319,7},{0,1}};                         /* smbcoin.wav */
static const SfxNote oneup_sfx[]      = {{659,3},{784,3},{988,3},{1319,4},{1568,4},{2093,8},{0,2}}; /* smb1up.wav */
static const SfxNote powerup_sfx[]    = {{523,3},{659,3},{784,3},{1047,4},{1319,6},{1568,6},{0,2}}; /* smbpowerup.wav */
static const SfxNote powerdown_sfx[]  = {{1047,3},{784,3},{659,3},{523,5},{392,6},{0,2}}; /* smbpipepowerdown.wav */
static const SfxNote star_sfx[]       = {{1319,2},{1568,2},{1760,2},{1568,2},{1319,2},{1760,2},{2093,4},{0,1}}; /* 星星取得 */
static const SfxNote fire_sfx[]       = {{375,2},{797,2},{1594,3},{141,2},{0,1}};       /* smbfireball.wav */
static const SfxNote item_sfx[]       = {{234,2},{281,2},{375,2},{422,2},{375,2},{281,2},{422,2},{281,2},{422,2},{469,2},{328,2},{281,2},{328,2},{469,2},{516,2},{562,3}}; /* smbitem.wav */
static const SfxNote pause_sfx[]      = {{1312,8},{1031,8},{1312,8},{1031,8},{0,2}}; /* smbpause.wav */
static const SfxNote firework_sfx[]   = {{281,3},{234,3},{188,3},{141,5},{234,3},{188,3},{141,6},{0,2}}; /* smbbillfirework.wav */
static const SfxNote cannon_sfx[]     = {{188,2},{375,2},{797,2},{1594,3},{141,3},{0,1}}; /* smbfireball.wav 的短促发射轮廓 */
static const SfxNote pipe_sfx[]       = {{523,3},{392,3},{330,4},{262,8},{0,2}};          /* 管道转场 */
static const SfxNote pipe_enter_sfx[] = {{784,2},{659,2},{523,3},{392,4},{330,6},{0,2}}; /* 原版进入管道的下降音型 */
static const SfxNote pipe_exit_sfx[]  = {{392,2},{523,2},{659,3},{784,4},{0,2}};          /* 出管提示 */
static const SfxNote spring_sfx[] = {{330,2},{523,2},{784,3},{1047,4},{0,1}}; /* 原版弹簧弹跳音型 */
static const SfxNote vine_sfx[]       = {{392,2},{523,2},{659,2},{784,2},{988,3},{0,1}};  /* smbvine.wav */
static const SfxNote flag_slide_sfx[] = {{1047,2},{880,2},{784,2},{659,3},{587,3},{494,4},{392,5},{0,2}}; /* 旗杆滑落 */
static const SfxNote bowserfall_sfx[] = {{988,3},{784,3},{659,4},{523,5},{392,7},{262,9},{0,2}}; /* smbbowserfall.wav */
static const SfxNote gameover_sfx[]   = {{784,4},{659,4},{587,4},{523,6},{392,8},{330,10},{262,14},{0,4}}; /* smbgameover.wav */
static const SfxNote death_sfx[]      = {{784,5},{659,5},{523,7},{392,9},{262,18},{196,24},{0,8}}; /* smbdeath.wav */
/* 终点通关旋律：参考 smblevelclear.wav，适配单音蜂鸣器。 */
static const SfxNote clear_sfx[] = {
 /* 单音蜂鸣器上的原创上行庆祝提示音；多声部原版音频需使用独立音频素材/解码器。 */
 {587,5},{740,5},{880,7},{1175,12},{0,3}
};
static const SfxNote worldclear_sfx[] = {
 {523,8},{659,8},{784,8},{1047,12},{988,8},{784,8},{659,8},
 {784,12},{988,12},{1319,16},{1568,20},{2093,35},{0,12}
}; /* smbworldclear.wav */
/* 公主救出：使用原版 smbworldclear.wav 的结尾庆祝旋律，1-4/2-4 均在接近公主时播放。 */
static const SfxNote princess_rescue_sfx[] = {
 {523,8},{659,8},{784,8},{1047,12},{988,8},{784,8},{659,8},
 {784,12},{988,12},{1319,16},{1568,20},{2093,35},{0,12}
};
static const SfxNote *s_sfx;
static uint8_t s_sfx_len, s_sfx_index, s_sfx_active;
static uint8_t s_sfx_is_jump = 0U;
static uint16_t s_sfx_ms;
/* 主循环告知场景层背景音乐已启用；单声道 PA0 蜂鸣器不能同时混合两路音频。 */
static uint8_t s_background_music_active = 0U;
/* 死亡事件通知主程序：背景音乐游标应复位，等死亡音效结束后从头播放。 */
static uint8_t s_music_restart_request;

static int16_t s_camera, s_mario_y;
static int8_t s_velocity_y;
static int16_t s_flag_pole_y=16; /* 旗杆上的旗帜当前纵坐标。 */
/* s_state：0=正常游戏，1=死亡动画，3=通关，4=管道传送，
 * 5=选关，6/11=藤蔓动画，7=地面行走进终点，8=死亡摘要，
 * 9=标题界面，10=暂停，12=旗杆滑落，14=出管，17=关卡标题卡，18=城堡升旗，19=旗杆停留，20=1-1门洞收尾，21~23=库巴关斧头过场。
 */
static uint8_t s_frame, s_state, s_grounded, s_on_platform;
/* 标题/选关/暂停画面只在状态变化时重绘，避免 PA1 后重复整屏刷新造成短暂花屏。 */
static uint8_t s_scene_dirty = 1U;
static uint8_t s_direction, s_powered, s_fire_powered;
/* 两个独立火球槽位：同屏最多两颗，可分别更新和检测碰撞。 */
static uint8_t s_fireball_active[FIREBALL_COUNT];
static int16_t s_fireball_x[FIREBALL_COUNT], s_fireball_y[FIREBALL_COUNT];
static int8_t s_fireball_dir[FIREBALL_COUNT];
static uint8_t s_enemy_alive[ENEMY_COUNT], s_item_available[ITEM_COUNT];
static int16_t s_enemy_x[ENEMY_COUNT], s_enemy_home_x[ENEMY_COUNT], s_enemy_y[ENEMY_COUNT], s_item_x[ITEM_COUNT];
static int16_t s_item_y;
static uint8_t s_item_age, s_item_is_1up;
static int8_t s_item_vx[ITEM_COUNT],s_item_vy[ITEM_COUNT];
static uint8_t s_pipe_dest_level;
static int16_t s_pipe_dest_x;
static uint8_t s_pipe_dest_top;
static int16_t s_pipe_entry_start_y;
static int16_t s_pipe_exit_target_y; /* 管道出口处马里奥完全露出时的目标 Y 坐标。 */
static int8_t s_enemy_dir[ENEMY_COUNT];
/* Goomba 离开砖块边缘后使用独立垂直速度下落，避免继续悬空巡逻。 */
static int8_t s_enemy_vy[ENEMY_COUNT];
/* Koopa states: 0=walking, 1=stationary shell, 2=sliding shell, 3=cliff-seeking shell. */
#define TURTLE_W 12
#define TURTLE_H 10
static uint8_t s_turtle_alive[TURTLE_COUNT], s_turtle_state[TURTLE_COUNT], s_turtle_timer[TURTLE_COUNT];
static int16_t s_turtle_x[TURTLE_COUNT], s_turtle_y[TURTLE_COUNT], s_turtle_home_x[TURTLE_COUNT];
static int8_t s_turtle_dir[TURTLE_COUNT], s_turtle_vy[TURTLE_COUNT];
static uint8_t s_block_broken[BLOCK_COUNT], s_block_used[BLOCK_COUNT];
static uint8_t s_coin_block_hits[BLOCK_COUNT];
static uint8_t s_pa5_last, s_pa5_count, s_pa7_last, s_pa7_count;
static uint8_t s_pa1_last=1U, s_pa1_count=0U;
/* PC13 黑屏恢复按键消抖状态；低电平有效、内部上拉。 */
static uint8_t s_pc13_last=1U, s_pc13_count=0U;
static uint16_t s_jump_buffer_ms=0U; /* PB1 跳跃输入缓冲，避免落地帧附近漏跳 */
static uint8_t s_down_latch;
static uint16_t s_state_ms;
static uint16_t s_invuln_ms; /* 受伤保护时间，单位 ms。 */
static uint16_t s_pipe_invuln_ms; /* 出管后 500ms 保护：不受伤，也不消灭敌人。 */
static uint8_t s_pipe_intro_pending, s_intro_exit_sfx_pending;
static uint8_t s_lives = 3;  /* 剩余生命，HUD 最多显示 9。 */
static int16_t s_checkpoint_x; /* 当前关卡已抵达的最远检查点（摄像机世界坐标）。 */
static uint8_t s_checkpoint_level; /* 检查点所属关卡，切换关卡时重置进度。 */
static uint8_t s_coin_taken[COIN_COUNT], s_coin_count;
static uint8_t s_sky_coin_taken[SKY_COIN_COUNT]; /* 本关金币状态、跨关累计金币数。 */
static int16_t s_cloud_x[CLOUD_COUNT], s_cloud_spike_x[CLOUD_COUNT], s_cloud_spike_y[CLOUD_COUNT];
static uint8_t s_cloud_alive[CLOUD_COUNT], s_cloud_timer[CLOUD_COUNT], s_cloud_spike_active[CLOUD_COUNT];
static int16_t s_hedgehog_x[HEDGEHOG_COUNT];
static int8_t s_hedgehog_dir[HEDGEHOG_COUNT];
static uint8_t s_hedgehog_alive[HEDGEHOG_COUNT];
static int16_t s_boss_x, s_boss_home_x, s_boss_y;
static int8_t s_boss_jump_vy;
static uint8_t s_boss_jump_timer;
static int8_t s_boss_walk_dir;
static uint8_t s_boss_fall_vy, s_boss_death_frame;
static uint8_t s_level_select, s_select_group;
/* 启动界面独立选关游标：1~8 对应 WORLD 1-1 至 WORLD 2-4。 */
static uint8_t s_title_level = 1U;
static uint8_t s_block_flower_active;
static int16_t s_block_flower_x, s_block_flower_y;
static uint8_t s_block_flower_age, s_poison_age;
static int8_t s_poison_vx,s_poison_vy;
static uint8_t s_star_age,s_coin_pop_active,s_coin_pop_frame;
static int16_t s_coin_pop_x,s_coin_pop_y;
static uint8_t s_poison_active;
static int16_t s_poison_x, s_poison_y;
static uint8_t s_vine_active, s_vine_climbing, s_sky_mode;
static int16_t s_vine_x;
static uint8_t s_vine_anim_tick;
static int16_t s_mario_draw_x;
static uint8_t s_plant_phase[PIPE_COUNT];
static uint8_t s_plant_dead[PIPE_COUNT];
static uint16_t s_star_ms;
static uint8_t s_star_active;
static int16_t s_star_x, s_star_y;
static int8_t s_star_dir=1, s_star_vy=0;
static uint8_t s_lift_phase[LIFT_COUNT];
static int16_t s_lift_y[LIFT_COUNT];
/* WORLD 1-3 天空奖励区：横向电梯往返移动；角色站在上面时随平台平移。 */
static int16_t s_sky_lift_x;
static int8_t s_sky_lift_dir;
static int8_t s_sky_lift_delta;
static int16_t s_fly_turtle_x[2], s_fly_turtle_y[2];
static int8_t s_fly_turtle_dir[2];
static uint8_t s_fly_turtle_alive[2];
/* WORLD 2-3 飞鱼：在三段木桥之间的水面周期性跃出并落回水中。 */
static const int16_t s_fish_left[FISH_COUNT] = {80,330,580,830,1080,1330};
static const int16_t s_fish_right[FISH_COUNT] = {112,362,612,862,1112,1362};
static int16_t s_fish_x[FISH_COUNT], s_fish_y[FISH_COUNT];
static int8_t s_fish_dir[FISH_COUNT];
static uint8_t s_fish_phase[FISH_COUNT], s_fish_alive[FISH_COUNT];
static uint8_t s_fish_respawn_frames[FISH_COUNT]; /* 每帧倒计时；改为 15 FPS 后，30 帧约为 2 秒 */
/* 2-2 水母：在水中上下浮动，碰撞会伤害马里奥。 */
#define JELLY_COUNT 4
static int16_t s_jelly_x[JELLY_COUNT], s_jelly_y[JELLY_COUNT];
static int8_t s_jelly_dir[JELLY_COUNT];
static uint8_t s_jelly_alive[JELLY_COUNT];
/* 2-1 炮弹车/炮弹：固定炮台按间隔发射，炮弹沿地面方向飞行。 */
static const int16_t s_bill_cannon_base_x[BULLET_BILL_COUNT] = {610, 1260};
static int16_t s_bill_cannon_x[BULLET_BILL_COUNT] = {610, 1260};
static uint8_t s_bill_cannon_timer[BULLET_BILL_COUNT];
static uint8_t s_bill_active[BULLET_BILL_COUNT];
static int16_t s_bill_x[BULLET_BILL_COUNT], s_bill_y[BULLET_BILL_COUNT];
/* 2-1 两名锤子兄弟（Hammer Bro）及其抛出的锤子。 */
/* 锤子兄弟当前世界坐标及砖台巡逻边界；每名兄弟独占两个锤子槽位。 */
static int16_t s_hammer_bro_start[HAMMER_BRO_COUNT] = {560, 578, 1120, 1138};
static int16_t s_hammer_bro_min_x[HAMMER_BRO_COUNT], s_hammer_bro_max_x[HAMMER_BRO_COUNT];
static int16_t s_hammer_bro_home_y[HAMMER_BRO_COUNT];
static int8_t s_hammer_bro_dir[HAMMER_BRO_COUNT];
static uint8_t s_hammer_bro_alive[HAMMER_BRO_COUNT], s_hammer_bro_timer[HAMMER_BRO_COUNT];
static uint8_t s_hammer_bro_walk_timer[HAMMER_BRO_COUNT];
static int16_t s_hammer_bro_y[HAMMER_BRO_COUNT];
static uint8_t s_hammer_active[HAMMER_COUNT];
static int16_t s_hammer_x[HAMMER_COUNT], s_hammer_y[HAMMER_COUNT];
static int8_t s_hammer_vx[HAMMER_COUNT], s_hammer_vy[HAMMER_COUNT];
/* 2-1 弹簧、2-4 火焰棒和波多布：均采用独立状态，不与普通敌人槽位混用。 */
static uint8_t s_firebar_phase[FIREBAR_COUNT];
static int8_t s_firebar_dir[FIREBAR_COUNT];
static const int16_t s_podoboo_start[PODOBOO_COUNT]={820,1000};
static uint8_t s_podoboo_timer[PODOBOO_COUNT];
static int16_t s_podoboo_x[PODOBOO_COUNT],s_podoboo_y[PODOBOO_COUNT];
static int8_t s_podoboo_vy[PODOBOO_COUNT];
static uint8_t s_podoboo_active[PODOBOO_COUNT];
/* 地下奖励场景：进管时记录地面位置，收集金币后从右侧横向水管返回。 */
static uint8_t s_sewer_mode, s_sewer_enter_pending;
/* 每个关卡的奖励下水道在一次生命周期内只能进入一次；死亡重生时清零。 */
static uint8_t s_sewer_used_mask = 0U;
static int16_t s_sewer_return_camera, s_sewer_return_y;
static uint8_t s_sewer_coin_taken[SEWER_COIN_COUNT];
/* 下水道奖励场景扩展为 4 组、每组 5 枚金币，沿路线错层排列。 */
static const int16_t s_sewer_coin_x[SEWER_COIN_COUNT] = {
 38,53,68,83,98, 118,133,148,163,178,
 198,213,228,243,258, 278,293,308,323,338
};
static const int16_t s_sewer_coin_y[SEWER_COIN_COUNT] = {
 30,22,34,26,38, 38,26,34,22,30,
 30,22,34,26,38, 38,26,34,22,30
};
/* 1-4/2-4 拉杆触发断桥，库巴随后下落至岩浆。 */
static uint8_t s_boss_bridge_broken, s_boss_falling;
/* 1-4 小型岩浆池及周期性喷发状态。 */
#define LAVA_COUNT 3
static const int16_t s_lava_x[LAVA_COUNT] = {520, 900, 1240};
static uint8_t s_lava_phase[LAVA_COUNT];
static uint8_t s_boss_hp, s_boss_defeated;
static uint16_t s_sky_timer;
static uint8_t s_boss_attack_timer, s_boss_hammer_timer, s_boss_move_phase;
static uint8_t s_firebar_slow_tick;
#define BOSS_FIREBALL_COUNT 2
static uint8_t s_boss_fire_active[BOSS_FIREBALL_COUNT],s_boss_fire_phase[BOSS_FIREBALL_COUNT];
static int16_t s_boss_fire_x[BOSS_FIREBALL_COUNT],s_boss_fire_y[BOSS_FIREBALL_COUNT];
static int8_t s_boss_fire_vx[BOSS_FIREBALL_COUNT],s_boss_fire_vy[BOSS_FIREBALL_COUNT];
/* 1=镜头移向桥，2=库巴坠落，3=镜头返回；该过场中马里奥保持原地。 */
static int16_t s_boss_cine_return_camera,s_boss_cine_target_camera,s_boss_cine_mario_y,s_boss_cine_mario_world_x;
static uint8_t s_boss_cine_timer;

/* 拉杆或无敌状态撞上 Boss 时，触发桥断裂与坠落动画。火球击败不走此分支。 */
static void BeginBossFall(void)
{
 uint8_t i;
 s_boss_bridge_broken=1U;
 s_boss_falling=1U;
 s_boss_fall_vy=1U;
 s_boss_death_frame=0U;
 s_boss_y=BossStandingY(); /* 保留库巴当前世界坐标，从实际桥面位置坠落。 */
 s_boss_attack_timer=0U;s_boss_hammer_timer=0U;
 for(i=0U;i<BOSS_FIREBALL_COUNT;i++)s_boss_fire_active[i]=0U;
 for(i=0U;i<HAMMER_COUNT;i++)s_hammer_active[i]=0U;
}
static void AdvanceBossFallFrame(void)
{
 if(!s_boss_falling)return;
 s_boss_death_frame++;
 s_boss_x=(int16_t)(s_boss_x+((s_boss_death_frame&1U)?1:-1));
 s_boss_y=(int16_t)(s_boss_y+s_boss_fall_vy);
 if(s_boss_fall_vy<7U)s_boss_fall_vy++;
 if(s_boss_y>=66){
  uint8_t i;s_boss_falling=0U;s_boss_defeated=1U;
  for(i=0U;i<BOSS_FIREBALL_COUNT;i++)s_boss_fire_active[i]=0U;
  StartGameSfx(bowserfall_sfx,(uint8_t)(sizeof(bowserfall_sfx)/sizeof(bowserfall_sfx[0])));
 }
}
/* 火球击败库巴时仅结束 Boss 战，不触发拉杆式断桥；桥面保持完整。 */
static void DefeatBossByFireball(void)
{
 uint8_t i;
 s_boss_hp=0U;
 s_boss_defeated=1U;
 s_boss_falling=0U;
 s_boss_attack_timer=0U;s_boss_hammer_timer=0U;
 for(i=0U;i<BOSS_FIREBALL_COUNT;i++)s_boss_fire_active[i]=0U;
 for(i=0U;i<HAMMER_COUNT;i++)s_hammer_active[i]=0U;
 StartGameSfx(kick_sfx,(uint8_t)(sizeof(kick_sfx)/sizeof(kick_sfx[0])));
}

static const uint16_t mario_run1[16] = {
 0x0780,0x0FC0,0x0FE0,0x07C0,0x0FF0,0x1FF8,0x1FE0,0x0FC0,
 0x07E0,0x0FF0,0x1B78,0x3318,0x0318,0x0618,0x0618,0x0C18
};
static const uint16_t mario_run2[16] = {
 0x0780,0x0FC0,0x0FE0,0x07C0,0x0FF0,0x1FF8,0x1FE0,0x0FC0,
 0x07E0,0x0FF0,0x1B78,0x3318,0x0318,0x0618,0x0630,0x08C0
};

static void StartSfx(const SfxNote *p,uint8_t n,uint8_t priority)
{
 s_sfx=p; s_sfx_len=n; s_sfx_index=0; s_sfx_ms=0; s_sfx_active=1U; s_sfx_priority=priority;
 if(p[0].hz) PWM_SetFrequency(p[0].hz); else PWM_Stop();
}
/* 音效仲裁：死亡/通关等关键音效最高；能力、星星其次；短促动作音效最低。
 * 同一金币音效尚未结束时不重复抢占，防止密集拾取造成音效被切碎。 */
static uint8_t SfxPriority(const SfxNote *p)
{
 if(p==gameover_sfx || p==death_sfx || p==clear_sfx || p==worldclear_sfx || p==princess_rescue_sfx || p==bowserfall_sfx)return 7U;
 if(p==oneup_sfx || p==powerup_sfx || p==powerdown_sfx || p==star_sfx)return 6U;
 if(p==flag_slide_sfx || p==pipe_sfx || p==pipe_enter_sfx || p==pipe_exit_sfx || p==vine_sfx)return 5U;
 if(p==pause_sfx)return 4U;
 if(p==jump_sfx || p==small_jump_sfx || p==swim_sfx || p==fire_sfx || p==cannon_sfx || p==kick_sfx || p==stomp_sfx)return 3U;
 if(p==coin_sfx || p==brick_sfx || p==bump_sfx || p==item_sfx || p==firework_sfx)return 2U;
 return 1U;
}
/* 地下场景略微降低音高；主音效仲裁在转调前完成。 */
static SfxNote s_level_sfx[16];
static void StartGameSfx(const SfxNote *p,uint8_t n)
{
 uint8_t i,priority=SfxPriority(p);
 if(n==0U || n>16U)return;
 /*
  * 跳跃/游泳提示音恢复启用，并压缩为约 40~120ms，避免长时间占用单路 PA0。
  * BGM 游标在跳跃音效期间继续按实际时间推进，但 PWM 输出暂时让给跳跃音效；
  * 音效结束后从当前音乐位置续播，不冻结或重新播放刚才的音符。
  */
 if(s_sfx_active && (priority<=s_sfx_priority))return;
 if(s_level==1U){
  StartSfx(p,n,priority);
  s_sfx_is_jump=(uint8_t)((s_background_music_active != 0U &&
      (p==jump_sfx || p==small_jump_sfx || p==swim_sfx))?1U:0U);
  return;
 }
 for(i=0;i<n;i++){
  s_level_sfx[i]=p[i];
  if(s_level_sfx[i].hz) s_level_sfx[i].hz=(uint16_t)(((uint32_t)s_level_sfx[i].hz*85U)/100U);
 }
 StartSfx(s_level_sfx,n,priority);
 s_sfx_is_jump=(uint8_t)((s_background_music_active != 0U &&
      (p==jump_sfx || p==small_jump_sfx || p==swim_sfx))?1U:0U);
}
/* 返回指定世界坐标是否处于地面缺口中。1-3 用多个断崖模拟原版高低平台路线。 */
static uint8_t InCliff(int16_t world_x)
{
 if(s_level==1U && world_x>=CLIFF_LEFT && world_x<CLIFF_RIGHT)return 1U;
 if(s_level==2U && ((world_x>=245 && world_x<305) || (world_x>=505 && world_x<565) || (world_x>=785 && world_x<845) || (world_x>=1065 && world_x<1125) || (world_x>=1345 && world_x<1405) || (world_x>=1565 && world_x<1625)))return 1U;
 if(s_level==3U){
  if((world_x>=260 && world_x<286) || (world_x>=590 && world_x<616) ||
     (world_x>=930 && world_x<956) || (world_x>=1230 && world_x<1256))return 1U;
 }
 /* 2-3 全程为水面上的桥，不存在地面支撑。 */
 if(s_level==7U)return 1U;
 /* WORLD 2-4 的波多布从两处岩浆口跃出；岩浆口本身也是地面缺口。 */
 if(s_level==8U && ((world_x>=812 && world_x<836) || (world_x>=992 && world_x<1016)))return 1U;
 return 0U;
}

/* 道具与管道、砖块、阶梯侧面碰撞；命中后由统一移动器反向。 */
static uint8_t ItemHitsSolid(int16_t x,int16_t y,uint8_t w,uint8_t h)
{
 uint8_t i;
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i),top=PipeTop(i);
  if(x+w>px && x<px+17 && y+h>top+2 && y<GROUND_TOP)return 1U;
 }
 for(i=0U;i<ActiveBlockCount();i++)if(!s_block_broken[i]){
  int16_t bx=BlockX(i),by=BlockY(i);
  if(x+w>bx && x<bx+BlockWidth(i) && y+h>by && y<by+9)return 1U;
 }
 return IntersectsStairBlock(x,y,w,h);
}

/* 返回道具下落时可接触的最近顶面；悬崖和断桥区域没有地面支撑。 */
static int16_t ItemFindSupport(int16_t x,int16_t old_bottom,int16_t next_bottom,uint8_t w)
{
 uint8_t i,st,row,col;
 int16_t best=32767,center=(int16_t)(x+w/2);
 uint8_t castle_gap=(uint8_t)(IsCastleLevel() && s_boss_bridge_broken &&
     center>=GoalX()-170 && center<GoalX()-55);
 if(!InCliff(center) && !castle_gap && old_bottom<=GROUND_TOP && next_bottom>=GROUND_TOP)best=GROUND_TOP;
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i),top=PipeTop(i);
  if(x+w>px && x<px+17 && old_bottom<=top && next_bottom>=top && top<best)best=top;
 }
 for(i=0U;i<ActiveBlockCount();i++)if(!s_block_broken[i]){
  int16_t bx=BlockX(i),top=BlockY(i);
  if(x+w>bx && x<bx+BlockWidth(i) && old_bottom<=top && next_bottom>=top && top<best)best=top;
 }
 for(st=0U;st<StaircaseCount();st++)for(row=0U;row<StaircaseRowsFor(st);row++)for(col=0U;col<(uint8_t)(StaircaseRowsFor(st)-row);col++){
  int16_t bx=StairBlockX(st,row,col);
  int16_t top=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
  if(x+w>bx && x<bx+9 && old_bottom<=top && next_bottom>=top && top<best)best=top;
 }
 return best==32767?-1:best;
}

/* 统一更新道具：弹出、水平反弹、重力、平台支撑与掉崖回收。 */
static uint8_t MoveWorldItem(int16_t *x,int16_t *y,int8_t *vx,int8_t *vy,
                             uint8_t *age,uint8_t pop_out,uint8_t w,uint8_t h,uint8_t bounce)
{
 int16_t next_x,old_bottom,next_bottom,support;
 if(pop_out && *age<8U){(*y)--;(*age)++;return 1U;}
 next_x=(int16_t)(*x+*vx);
 if(*vx!=0 && ItemHitsSolid(next_x,*y,w,h)){
  *vx=(int8_t)(-*vx);
  next_x=(int16_t)(*x+*vx);
  if(!ItemHitsSolid(next_x,*y,w,h))*x=next_x;
 }else *x=next_x;
 old_bottom=(int16_t)(*y+h);
 if(*vy<3)(*vy)++;
 next_bottom=(int16_t)(old_bottom+*vy);
 support=ItemFindSupport(*x,old_bottom,next_bottom,w);
 if(support>=0 && support<=next_bottom){
  *y=(int16_t)(support-h);
  *vy=(bounce!=0U)?-3:0;
 }else *y=(int16_t)(*y+*vy);
 return (*y<64)?1U:0U;
}

/*
 * 查询 Goomba 当前脚下最近的可落脚面。
 * bottom 是怪物脚底的世界 Y 坐标；只接受位于脚底下方（或当前脚底处）的砖块，
 * 并检查怪物中心是否仍在砖块横向范围内。地面缺口不提供支撑。
 */
static int16_t EnemyFindSupport(int16_t world_center_x,int16_t bottom)
{
 uint8_t i;
 int16_t best=32767;
 for(i=0;i<ActiveBlockCount();i++){
  int16_t bx,top;
  if(s_block_broken[i] || BlockMergedFollower(i))continue;
  bx=BlockX(i);top=BlockY(i);
  if(world_center_x>=bx && world_center_x<bx+BlockWidth(i) &&
     top>=bottom-1 && top<best)best=top;
 }
 if(!InCliff(world_center_x) && GROUND_TOP>=bottom-1 && GROUND_TOP<best)
  best=GROUND_TOP;
 /* Goomba 从上方落到阶梯时可站稳，离开台阶边缘后自然下落。 */
 {
  uint8_t st,row,col;
  for(st=0U;st<StaircaseCount();st++)for(row=0U;row<StaircaseRowsFor(st);row++)for(col=0U;col<(uint8_t)(StaircaseRowsFor(st)-row);col++){
   int16_t bx=StairBlockX(st,row,col);
   int16_t top=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
   if(world_center_x>=bx && world_center_x<bx+9 && top>=bottom-1 && top<best)best=top;
  }
 }
 return best==32767?-1:best;
}
/* Goomba 与马里奥一样不能穿过水管侧壁；从正面碰到管道时应掉头。 */
static uint8_t EnemyIntersectsPipe(int16_t enemy_x,int16_t enemy_y)
{
 uint8_t i;
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i);
  int16_t top=PipeTop(i);
  /* Goomba 尺寸约 11×7；站在管口顶面（脚底刚好等于 top）不算侧面相交。 */
  if(enemy_x+11>px && enemy_x<px+17 &&
     enemy_y+7>top && enemy_y<GROUND_TOP)return 1U;
 }
 return 0U;
}
/* 若 Goomba 因下落等情况已经进入管道侧面，选择较近的一侧退出，避免卡在管体内。 */
static int8_t EnemyDirectionAwayFromPipe(int16_t enemy_x,int16_t enemy_y,int8_t fallback)
{
 uint8_t i;
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i);
  if(enemy_x+11>px && enemy_x<px+17 &&
     enemy_y+7>PipeTop(i) && enemy_y<GROUND_TOP)
   return ((enemy_x+5)<(px+8))?-1:1;
 }
 return fallback;
}
/*
 * Koopa 支撑检测：乌龟与 Goomba 一样使用独立重力。
 * 支撑面包括砖块、正常地面、管道顶面，以及 WORLD 1-3 的蘑菇平台。
 * 地面缺口不提供支撑，因此乌龟走入悬崖后会自然下落，而不会在空中巡逻。
 */
static int16_t TurtleFindSupport(int16_t turtle_x,int16_t bottom)
{
 uint8_t i;
 int16_t best=32767;
 int16_t center=(int16_t)(turtle_x+TURTLE_W/2);
 for(i=0U;i<ActiveBlockCount();i++)if(!s_block_broken[i] && !BlockMergedFollower(i)){
  int16_t bx=BlockX(i),top=BlockY(i);
  if(turtle_x+TURTLE_W>bx && turtle_x<bx+BlockWidth(i) &&
     top>=bottom-1 && top<best)best=top;
 }
 if(!InCliff(center) && GROUND_TOP>=bottom-1 && GROUND_TOP<best)best=GROUND_TOP;
 /* 掉落到管道顶面时可以站稳；从地面正面接近时仍会被管道侧壁挡回。 */
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i),top=PipeTop(i);
  if(turtle_x+TURTLE_W>px && turtle_x<px+17 && top>=bottom-1 && top<best)best=top;
 }
 if(s_level==7U && turtle_x+TURTLE_W>0 && turtle_x<WorldLength() &&
    46>=bottom-1 && 46<best)best=46;
 if(s_level==3U){
  static const int16_t platform_x[4]={250,580,920,1200};
  static const int16_t platform_y[4]={34,27,36,29};
  static const uint8_t platform_w[4]={30,34,30,36};
  for(i=0U;i<4U;i++){
   int16_t px=platform_x[i],top=platform_y[i];
   if(turtle_x+TURTLE_W>px && turtle_x<px+platform_w[i] &&
      top>=bottom-1 && top<best)best=top;
  }
 }
 {
  uint8_t st,row,col;
  for(st=0U;st<StaircaseCount();st++)for(row=0U;row<StaircaseRowsFor(st);row++)for(col=0U;col<(uint8_t)(StaircaseRowsFor(st)-row);col++){
   int16_t bx=StairBlockX(st,row,col);
   int16_t top=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
   if(turtle_x+TURTLE_W>bx && turtle_x<bx+9 && top>=bottom-1 && top<best)best=top;
  }
 }
 return best==32767?-1:best;
}
/* Koopa 的身体与管道侧壁做矩形碰撞；脚底恰好位于管口顶面时不视为穿墙。 */
static uint8_t TurtleIntersectsPipe(int16_t turtle_x,int16_t turtle_y,uint8_t *pipe_index)
{
 uint8_t i;
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i),top=PipeTop(i);
  if(turtle_x+TURTLE_W>px && turtle_x<px+17 &&
     turtle_y+TURTLE_H>top && turtle_y<GROUND_TOP){
   if(pipe_index!=0)*pipe_index=i;
   return 1U;
  }
 }
 return 0U;
}
/*
 * 移动乌龟时先做扫掠式管道碰撞：左侧来敌停在管道左边并掉头，
 * 右侧来敌停在管道右边并掉头。壳体高速滑行也使用同一规则，不能穿过管道。
 */
static void TurtleMoveRespectPipes(uint8_t index,int16_t delta)
{
 int16_t next_x=(int16_t)(s_turtle_x[index]+delta);
 uint8_t pipe_index;
 if(TurtleIntersectsPipe(s_turtle_x[index],s_turtle_y[index],&pipe_index)){
  int16_t px=PipeX(pipe_index);
  /* 依当前行进方向判断来路，避免已擦入管体时被推到错误一侧。 */
  if(delta>0){
   s_turtle_x[index]=(int16_t)(px-TURTLE_W);
   s_turtle_dir[index]=-1;
  }else{
   s_turtle_x[index]=(int16_t)(px+17);
   s_turtle_dir[index]=1;
  }
  return;
 }
 if(TurtleIntersectsPipe(next_x,s_turtle_y[index],&pipe_index)){
  int16_t px=PipeX(pipe_index);
  if(delta>0){
   s_turtle_x[index]=(int16_t)(px-TURTLE_W);
   s_turtle_dir[index]=-1;
  }else{
   s_turtle_x[index]=(int16_t)(px+17);
   s_turtle_dir[index]=1;
  }
  return;
 }
 if(IntersectsStairBlock(next_x,s_turtle_y[index],TURTLE_W,TURTLE_H)){
  s_turtle_dir[index]=(int8_t)(-s_turtle_dir[index]);
  return;
 }
 s_turtle_x[index]=next_x;
}
/* 乌龟失去支撑后逐帧受重力下落；落到砖块/管道顶/平台/地面后重新站稳。 */
static void ConvertFlyingKoopaToTurtle(uint8_t index)
{
 uint8_t slot=(uint8_t)(index%TURTLE_COUNT);
 s_fly_turtle_alive[index]=0U;
 s_turtle_alive[slot]=1U;s_turtle_state[slot]=0U;s_turtle_timer[slot]=0U;
 s_turtle_x[slot]=s_fly_turtle_x[index];
 s_turtle_home_x[slot]=s_fly_turtle_x[index];
 s_turtle_y[slot]=(int16_t)(s_fly_turtle_y[index]+2);
 s_turtle_dir[slot]=s_fly_turtle_dir[index];s_turtle_vy[slot]=0;
}
static void UpdateTurtleVertical(uint8_t index)
{
 int16_t bottom=(int16_t)(s_turtle_y[index]+TURTLE_H);
 int16_t support=TurtleFindSupport(s_turtle_x[index],bottom);
 if(support>=0 && support<=bottom+1){
  s_turtle_y[index]=(int16_t)(support-TURTLE_H);
  s_turtle_vy[index]=0;
 }else{
  int16_t next_bottom;
  if(s_turtle_vy[index]<4)s_turtle_vy[index]++;
  next_bottom=(int16_t)(bottom+s_turtle_vy[index]);
  support=TurtleFindSupport(s_turtle_x[index],bottom);
  if(support>=bottom && support<=next_bottom){
   s_turtle_y[index]=(int16_t)(support-TURTLE_H);
   s_turtle_vy[index]=0;
  }else{
   s_turtle_y[index]=(int16_t)(s_turtle_y[index]+s_turtle_vy[index]);
  }
 }
 if(s_turtle_y[index]>64)s_turtle_alive[index]=0U;
}
/* 初始化当前关卡对象。关卡切换时调用；生命/金币等全局数据不在此清零。 */
static void ResetLevel(void)
{
 uint8_t i;
 s_stair_layout_ready=0U;
 if(s_checkpoint_level!=s_level){s_checkpoint_level=s_level;s_checkpoint_x=0;}
 s_camera=0; s_mario_y=(s_level==7U)?(int16_t)(46-MARIO_H):(int16_t)(GROUND_TOP-MARIO_H); s_mario_draw_x=MARIO_X; s_velocity_y=0;
 s_flag_pole_y=16;
 s_grounded=1; s_on_platform=(s_level==7U)?1U:0U; s_state=0; s_state_ms=0; s_invuln_ms=0; s_pipe_invuln_ms=0U;
 s_pipe_intro_pending=0U;s_intro_exit_sfx_pending=0U;
 s_direction=0; s_powered=0; s_fire_powered=0; s_down_latch=0;
 for(i=0;i<FIREBALL_COUNT;i++)s_fireball_active[i]=0U;
 s_block_flower_active=0; s_poison_active=0;
 s_block_flower_age=0U;s_poison_age=0U;s_poison_vx=-1;s_poison_vy=0;
 s_star_active=0;s_star_ms=0;s_star_dir=1;s_star_vy=0;s_star_age=8U;
 s_coin_pop_active=0U;s_coin_pop_frame=0U;s_coin_pop_x=0;s_coin_pop_y=0;
 s_vine_active=0; s_vine_climbing=0; s_vine_anim_tick=0; s_sky_mode=0; s_sky_timer=0; s_block_flower_age=0; s_poison_age=0;
 s_sky_lift_x=0;s_sky_lift_dir=1;s_sky_lift_delta=0;
 s_boss_hp=IsCastleLevel()?(uint8_t)(s_level==8U?5U:3U):0U; s_boss_defeated=0; s_boss_attack_timer=0; s_boss_hammer_timer=0U; s_boss_move_phase=0; s_firebar_slow_tick=0U; s_boss_bridge_broken=0U; s_boss_falling=0U;
 s_boss_home_x=BossX(); s_boss_x=s_boss_home_x; s_boss_y=BossStandingY(); s_boss_jump_vy=0; s_boss_jump_timer=0; s_boss_walk_dir=1; s_boss_fall_vy=1U; s_boss_death_frame=0U;
 for(i=0U;i<BOSS_FIREBALL_COUNT;i++){s_boss_fire_active[i]=0U;s_boss_fire_phase[i]=0U;s_boss_fire_x[i]=0;s_boss_fire_y[i]=0;s_boss_fire_vx[i]=0;s_boss_fire_vy[i]=0;}
 s_boss_cine_return_camera=0;s_boss_cine_target_camera=0;s_boss_cine_mario_y=s_mario_y;s_boss_cine_mario_world_x=MARIO_X;s_boss_cine_timer=0U;
 for(i=0;i<LevelCoinCount();i++)s_coin_taken[i]=0;
 for(i=0;i<SKY_COIN_COUNT;i++)s_sky_coin_taken[i]=0U;
 for(i=0;i<CLOUD_COUNT;i++){
  int16_t cloud_y=(int16_t)(10+i*4);
  s_cloud_x[i]=SpawnOutsideStairs((int16_t)(500+i*620),cloud_y,20U,13U);
  s_cloud_alive[i]=(s_level==3U)?1U:0U;s_cloud_timer[i]=(uint8_t)(i*25U);
  s_cloud_spike_active[i]=0;s_cloud_spike_x[i]=0;s_cloud_spike_y[i]=0;
 }
 for(i=0;i<HEDGEHOG_COUNT;i++){
  s_hedgehog_x[i]=SpawnOutsideStairs((int16_t)(680+i*420),44,13U,14U);
  s_hedgehog_dir[i]=(i==0U)?1:-1;s_hedgehog_alive[i]=(s_level==3U)?1U:0U;
 }
 for(i=0;i<PIPE_COUNT;i++){s_plant_phase[i]=0;s_plant_dead[i]=0;}
 for(i=0;i<JELLY_COUNT;i++){s_jelly_x[i]=(int16_t)(300+i*360);s_jelly_y[i]=(int16_t)(25+(i%2U)*12U);s_jelly_dir[i]=(i%2U)?-1:1;s_jelly_alive[i]=(s_level==6U)?1U:0U;}
 for(i=0;i<BULLET_BILL_COUNT;i++){
  s_bill_cannon_x[i]=SpawnOutsideStairs(s_bill_cannon_base_x[i],45,17U,11U);
  s_bill_cannon_timer[i]=(uint8_t)(i*35U);s_bill_active[i]=0U;s_bill_x[i]=0;s_bill_y[i]=45;
 }
 {
  /* WORLD 2-1 四个锤子兄弟分别站在三块连续砖组成的平台上：
   * 索引 3/42/15/45 对应四组砖台，平台宽 27px；角色宽 14px，
   * 因此每名兄弟只在平台左端至左端 +13px 之间往返，不会走出砖台。
   */
  static const uint8_t perch_block[HAMMER_BRO_COUNT]={3U,42U,15U,45U};
  static const uint8_t throw_timer[HAMMER_BRO_COUNT]={0U,0U,28U,28U};
  for(i=0U;i<HAMMER_BRO_COUNT;i++){
   if(s_level==5U){
    int16_t platform_x=BlockX(perch_block[i]);
    int16_t platform_top=BlockY(perch_block[i]);
    s_hammer_bro_start[i]=platform_x;
    s_hammer_bro_min_x[i]=platform_x;
    s_hammer_bro_max_x[i]=(int16_t)(platform_x+13);
    s_hammer_bro_home_y[i]=(int16_t)(platform_top-15);
    s_hammer_bro_y[i]=s_hammer_bro_home_y[i];
    s_hammer_bro_alive[i]=1U;
   }else{
    s_hammer_bro_start[i]=(int16_t)(560U+i*18U);
    s_hammer_bro_min_x[i]=s_hammer_bro_start[i];
    s_hammer_bro_max_x[i]=s_hammer_bro_start[i];
    s_hammer_bro_home_y[i]=41;
    s_hammer_bro_y[i]=41;
    s_hammer_bro_alive[i]=0U;
   }
   s_hammer_bro_dir[i]=(i&1U)?-1:1;
   s_hammer_bro_timer[i]=throw_timer[i];
   s_hammer_bro_walk_timer[i]=(uint8_t)(i&1U);
  }
 }
 for(i=0;i<HAMMER_COUNT;i++){s_hammer_active[i]=0U;s_hammer_x[i]=0;s_hammer_y[i]=0;s_hammer_vx[i]=0;s_hammer_vy[i]=0;}
 for(i=0;i<FIREBAR_COUNT;i++){s_firebar_phase[i]=(uint8_t)(i*7U);s_firebar_dir[i]=(s_level==8U)?-1:((i==0U)?1:-1);}
 for(i=0;i<PODOBOO_COUNT;i++){s_podoboo_x[i]=s_podoboo_start[i];s_podoboo_y[i]=GROUND_TOP-8;s_podoboo_vy[i]=0;s_podoboo_timer[i]=(uint8_t)(i*42U);s_podoboo_active[i]=0U;}
 s_sewer_mode=0U;s_sewer_enter_pending=0U;s_sewer_return_camera=0;s_sewer_return_y=GROUND_TOP-MARIO_H;
 for(i=0;i<SEWER_COIN_COUNT;i++)s_sewer_coin_taken[i]=0U;
 for(i=0;i<LAVA_COUNT;i++)s_lava_phase[i]=(uint8_t)(i*18U);
 s_sky_lift_x=0;s_sky_lift_dir=1;s_sky_lift_delta=0;
 for(i=0;i<LIFT_COUNT;i++){
  s_lift_phase[i]=(uint8_t)((i*13U)%LIFT_PERIOD);
  /* 初始高度与 68 步三角波保持一致；电梯现在在 y=14~48 之间往返。 */
  s_lift_y[i]=(int16_t)(s_level==2U ?
      (LIFT_TOP_Y + (s_lift_phase[i]<=LIFT_HALF_CYCLE ?
       s_lift_phase[i] : (LIFT_PERIOD-s_lift_phase[i]))) : 44U);
 }
 /* 飞行乌龟只有两个槽位，单独初始化，避免随电梯数量扩展而越界。 */
 for(i=0;i<2U;i++){
  s_fly_turtle_x[i]=(int16_t)((s_level==3U || s_level==7U)?650+i*450:700+i*430);
  s_fly_turtle_y[i]=(int16_t)(22+i*10);s_fly_turtle_dir[i]=-1;
  s_fly_turtle_alive[i]=(s_level==3U)?1U:0U;
  s_fly_turtle_x[i]=SpawnOutsideStairs(s_fly_turtle_x[i],s_fly_turtle_y[i],14U,12U);
 }
 for(i=0U;i<FISH_COUNT;i++){
  s_fish_x[i]=(int16_t)((s_level==7U)?(s_fish_left[i]+14):0);
  s_fish_y[i]=62;s_fish_dir[i]=(i&1U)?-1:1;
  s_fish_phase[i]=(uint8_t)(i*19U);s_fish_alive[i]=(s_level==7U)?1U:0U;s_fish_respawn_frames[i]=0U;
 }
 for(i=0;i<ENEMY_COUNT;i++){
  uint8_t block_index;
  s_enemy_alive[i]=(s_level==7U || i==ENEMY_COUNT-1U)?0U:1U;
  s_enemy_x[i]=EnemyStart(i);
  s_enemy_home_x[i]=EnemyStart(i);
  s_enemy_y[i]=49;
  /* 约三分之一的 Goomba 会生成在砖块顶部，而不只出现在地面。 */
  if(s_level!=7U && ((uint8_t)(i+s_level)%3U)==0U){
   block_index=(uint8_t)((i*5U+s_level*3U)%ActiveBlockCount());
   s_enemy_x[i]=(int16_t)(BlockX(block_index)+1);
   s_enemy_home_x[i]=s_enemy_x[i];
   s_enemy_y[i]=(int16_t)(BlockY(block_index)-7);
  }
  s_enemy_x[i]=SpawnOutsideStairs(s_enemy_x[i],s_enemy_y[i],11U,7U);
  s_enemy_home_x[i]=s_enemy_x[i];
  s_enemy_dir[i]=-1;
  s_enemy_vy[i]=0;
 }
 for(i=0;i<TURTLE_COUNT;i++){
  s_turtle_alive[i]=(s_level==7U)?0U:1U;s_turtle_state[i]=0;s_turtle_timer[i]=0;
  s_turtle_x[i]=SpawnOutsideStairs(TurtleStart(i),GROUND_TOP-TURTLE_H,TURTLE_W,TURTLE_H);
  s_turtle_home_x[i]=s_turtle_x[i];s_turtle_y[i]=GROUND_TOP-TURTLE_H;
  s_turtle_dir[i]=-1;s_turtle_vy[i]=0;
 }
 for(i=0U;i<ITEM_COUNT;i++){
  s_item_available[i]=0U;s_item_x[i]=ItemStart(i);s_item_vx[i]=1;s_item_vy[i]=0;s_item_is_1up=0U;
 }
 s_item_y=GROUND_TOP-8;s_item_age=0U;s_item_is_1up=0U;
 s_pipe_dest_level=s_level;s_pipe_dest_x=0;s_pipe_dest_top=GROUND_TOP;
 for(i=0;i<BLOCK_COUNT;i++){s_block_broken[i]=0;s_block_used[i]=0;s_coin_block_hits[i]=0U;}
 BuildCoinLayout();
}
/* 新关卡开始卡片固定显示 1 秒；GameScene_AudioPaused() 同步冻结背景音乐。 */
static void BeginLevelIntro(void)
{
 s_state=17U;s_state_ms=0U;s_scene_dirty=1U;s_jump_buffer_ms=0U;s_down_latch=0U;
 s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_ms=0U;s_sfx_priority=0U;PWM_Stop();
}
/* 3x5 微型字模：HUD 固定绘制在最顶端的 7 像素带内，不会盖住跳跃中的马里奥。 */
static uint8_t TinyGlyphRow(char ch,uint8_t row)
{
 static const uint8_t digits[10][5]={
  {7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},{5,5,7,1,1},
  {7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},{7,5,7,5,7},{7,5,7,1,7}
 };
 if(row>=5U)return 0U;
 if(ch>='a' && ch<='z')ch=(char)(ch-'a'+'A');
 if(ch>='0' && ch<='9')return digits[(uint8_t)(ch-'0')][row];
 if(ch=='!'){static const uint8_t g[5]={2,2,2,0,2};return g[row];}
 switch(ch){
  case 'B': {static const uint8_t g[5]={6,5,6,5,6};return g[row];}
  case 'W': {static const uint8_t g[5]={5,5,5,7,5};return g[row];}
  case 'O': {static const uint8_t g[5]={7,5,5,5,7};return g[row];}
  case 'R': {static const uint8_t g[5]={6,5,6,5,5};return g[row];}
  case 'L': {static const uint8_t g[5]={4,4,4,4,7};return g[row];}
  case 'D': {static const uint8_t g[5]={6,5,5,5,6};return g[row];}
  case 'U': {static const uint8_t g[5]={5,5,5,5,7};return g[row];}
  case 'C': {static const uint8_t g[5]={7,4,4,4,7};return g[row];}
  case 'S': {static const uint8_t g[5]={7,4,7,1,7};return g[row];}
  case 'M': {static const uint8_t g[5]={5,7,7,5,5};return g[row];}
  case 'A': {static const uint8_t g[5]={2,5,7,5,5};return g[row];}
  case 'P': {static const uint8_t g[5]={6,5,6,4,4};return g[row];}
  case 'E': {static const uint8_t g[5]={7,4,6,4,7};return g[row];}
  case 'V': {static const uint8_t g[5]={5,5,5,5,2};return g[row];}
  case '.': {static const uint8_t g[5]={0,0,0,0,2};return g[row];}
  case 'T': {static const uint8_t g[5]={7,2,2,2,2};return g[row];}
  case 'I': {static const uint8_t g[5]={7,2,2,2,7};return g[row];}
  case 'N': {static const uint8_t g[5]={5,7,7,7,5};return g[row];}
  case 'X': {static const uint8_t g[5]={5,5,2,5,5};return g[row];}
  case 'Y': {static const uint8_t g[5]={5,5,2,2,2};return g[row];}
  case 'K': {static const uint8_t g[5]={5,5,6,5,5};return g[row];}
  case '-': {static const uint8_t g[5]={0,0,7,0,0};return g[row];}
  default:return 0U;
 }
}
static void DrawTinyString(int16_t x,int16_t y,const char *text)
{
 uint8_t i,row,col;
 if(text==0)return;
 for(i=0U;text[i]!='\0';i++){
  for(row=0U;row<5U;row++){
   uint8_t bits=TinyGlyphRow(text[i],row);
   for(col=0U;col<3U;col++)
    if(bits & (uint8_t)(1U<<(2U-col)))OLED_GFX_DrawPixel((int16_t)(x+i*4U+col),(int16_t)(y+row),1U);
  }
 }
}
static void DrawMiniHud(void)
{
 char status[7]={'U','0',' ','C','0','0','\0'};
 status[1]=(char)('0'+(s_lives%10U));
 status[4]=(char)('0'+((s_coin_count/10U)%10U));
 status[5]=(char)('0'+(s_coin_count%10U));
 OLED_GFX_FillRect(0,0,128,7,0U);
 DrawTinyString(2,1,LevelName());
 DrawTinyString(101,1,status);
 /* 库巴生命值也绘制到同一图形帧缓冲，避免字符模式与图形刷新交替写屏造成闪烁。 */
 if(IsCastleLevel() && !s_boss_defeated && s_boss_hp>0U){
  char boss_hp_text[2];
  boss_hp_text[0]=(char)('0'+(s_boss_hp%10U));
  boss_hp_text[1]='\0';
  DrawTinyString(54,1,"BOWSER");
  DrawTinyString(80,1,boss_hp_text);
 }
}
/* HUD 改由 DrawMiniHud() 绘入图形帧缓冲；此函数保留给计数事件调用。 */
static void UpdateLivesHud(void)
{
 /* HUD 在下一帧统一绘制。 */
}
static void AwardCoin(void)
{
 s_coin_count++;
 if(s_coin_count>=100U){
  s_coin_count=0U;
  if(s_lives<9U){s_lives++;StartGameSfx(oneup_sfx,(uint8_t)(sizeof(oneup_sfx)/sizeof(oneup_sfx[0])));}
  else StartGameSfx(coin_sfx,(uint8_t)(sizeof(coin_sfx)/sizeof(coin_sfx[0])));
 }else StartGameSfx(coin_sfx,(uint8_t)(sizeof(coin_sfx)/sizeof(coin_sfx[0])));
 UpdateLivesHud();
}
/* 顶击新砖块组时，领取该砖块正上方对应的金币；每枚金币只记一次。 */
static void CollectCoinAboveBlock(uint8_t block_index)
{
 uint8_t n;
 for(n=0U;n<COINS_PER_GROUP;n++){
  uint8_t coin_index=n;
  if(CoinSupportBlock(coin_index)==block_index && !s_coin_taken[coin_index]){
   s_coin_taken[coin_index]=1U;
   AwardCoin();
  }
 }
}

/* 问号箱内容类型：0=按马里奥形态发放能力道具，1=藤蔓，2=Goomba，3=金币。 */
static uint8_t QuestionBlockReward(uint8_t block_index)
{
 if(s_level==3U && (block_index==13U || block_index==14U))return 1U;
 if(s_level!=7U && ((block_index==19U && (s_level==2U || s_level==5U || s_level==8U)) ||
                    (block_index==7U && s_level==4U)))return 2U;
 if((block_index==7U && (s_level==1U || s_level==6U)) ||
    (block_index==19U && s_level==3U))return 3U;
 return 0U;
}
static void SpawnQuestionGoomba(uint8_t block_index)
{
 uint8_t slot=(uint8_t)(ENEMY_COUNT-1U);
 if(s_enemy_alive[slot])return;
 s_enemy_alive[slot]=1U;
 s_enemy_y[slot]=(int16_t)(BlockY(block_index)-7);
 s_enemy_x[slot]=SpawnOutsideStairs(BlockX(block_index),s_enemy_y[slot],11U,7U);
 s_enemy_home_x[slot]=s_enemy_x[slot];
 s_enemy_dir[slot]=(s_direction!=0U)?-1:1;
 s_enemy_vy[slot]=0;
}
static void SpawnQuestionPowerup(uint8_t block_index)
{
 int16_t x=BlockX(block_index),y=(int16_t)(BlockY(block_index)-8);
 if(s_fire_powered){
  /* 火焰形态再次得到奖励时，改为一命蘑菇。 */
  s_item_available[0]=1U;s_item_is_1up=1U;s_item_x[0]=x;s_item_y=y;
  s_item_age=0U;s_item_vx[0]=1;s_item_vy[0]=0;
 }else if(s_powered){
  /* 超级形态顶箱子得到静止的火焰花，不会像蘑菇一样行走。 */
  s_block_flower_active=1U;s_block_flower_x=x;s_block_flower_y=y;
  s_block_flower_age=0U;
 }else{
  /* 小形态顶箱子只会得到普通蘑菇。 */
  s_item_available[0]=1U;s_item_is_1up=0U;s_item_x[0]=x;s_item_y=y;
  s_item_age=0U;s_item_vx[0]=1;s_item_vy[0]=0;
 }
 StartGameSfx(item_sfx,(uint8_t)(sizeof(item_sfx)/sizeof(item_sfx[0])));
}
static void DrawSprite(int16_t x,int16_t y,const uint16_t *sp,uint8_t flip)
{
 uint8_t r,c;
 for(r=0;r<16;r++) for(c=0;c<12;c++)
  if(sp[r] & (uint16_t)(1U << (11U-c))) OLED_GFX_DrawPixel(x+(flip?(11-c):c),y+r,1);
}

/* 火焰马里奥专属识别细节：帽檐上方增加火焰羽饰，前侧增加火花。
   不改写基础点阵，因此超级马里奥与火焰马里奥仍共享动作帧，但轮廓可区分。 */
static void DrawFireMarioDetails(int16_t x,int16_t y,uint8_t flip)
{
 int16_t crest_x=(int16_t)(x+(flip?3:8));
 int16_t spark_x=(int16_t)(x+(flip?-1:12));
 OLED_GFX_DrawPixel(crest_x,y-2,1U);
 OLED_GFX_DrawPixel((int16_t)(crest_x+(flip?1:-1)),y-1,1U);
 OLED_GFX_DrawPixel(crest_x,y,1U);
 OLED_GFX_DrawPixel(spark_x,y+9,1U);
 OLED_GFX_DrawPixel((int16_t)(spark_x+(flip?-1:1)),y+8,1U);
 OLED_GFX_DrawPixel((int16_t)(spark_x+(flip?-1:1)),y+10,1U);
}

/*
 * 统一绘制马里奥：主体继续采用透明像素精灵，不填充矩形碰撞框。
 * 受伤保护、重生无敌或星星无敌期间，主体固定使用同一帧，并在外围
 * 每隔一帧绘制一次闪烁矩形框，明确提示无敌状态。
 * force_large=1 用于原本始终使用 12x16 精灵的天空奖励场景。
 */
static void DrawMarioSpriteAt(int16_t x,int16_t y,uint8_t force_large)
{
 const uint16_t *sp;
 uint8_t r,c;
 uint8_t invincible=(uint8_t)((s_invuln_ms>0U || s_pipe_invuln_ms>0U || s_star_ms>0U)?1U:0U);
 sp=(invincible || ((s_frame&1U)==0U))?mario_run1:mario_run2;
 if(force_large || s_powered || s_fire_powered){
  DrawSprite(x,y,sp,s_direction);
  if(s_fire_powered)DrawFireMarioDetails(x,y,s_direction);
 }else{
  /* 小马里奥保持透明像素绘制，不填充 9x12 外接矩形。 */
  for(r=0U;r<12U;r++)for(c=0U;c<9U;c++){
   uint8_t src_r=(uint8_t)(r*16U/12U);
   uint8_t src_c=(uint8_t)(c*12U/9U);
   uint8_t bit=(uint8_t)(11U-src_c);
   if(sp[src_r] & (uint16_t)(1U<<bit))
    OLED_GFX_DrawPixel((int16_t)(x+(s_direction?(8U-c):c)),(int16_t)(y+1U+r),1U);
  }
 }
 /* 受伤保护/死亡重生/无敌星星期间，角色外围交替显示闪烁矩形框。 */
 if(invincible && (s_frame&1U)==0U)
  OLED_GFX_DrawRect((int16_t)(x-2),(int16_t)(y-2),14,18,1U);
}
static void Cloud(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x+4,y,13,4,1); OLED_GFX_FillRect(x,y+3,23,5,1); OLED_GFX_FillRect(x+5,y+7,14,2,1);
}
static void Block(int16_t x,int16_t y,uint8_t q,uint8_t used,uint8_t ten_coin,uint8_t hits)
{
 OLED_GFX_DrawRect(x,y,9,9,1U);
 if(ten_coin){
  /* 十金币砖中央画金币，顶部短刻线显示已经顶过的次数。 */
  if(used){
   OLED_GFX_DrawRect(x+1,y+1,7,7,1U);
   OLED_GFX_DrawLine(x+3,y+3,x+5,y+3,1U);
   OLED_GFX_DrawLine(x+3,y+5,x+5,y+5,1U);
  }else{
   OLED_GFX_DrawLine(x+4,y+2,x+4,y+6,1U);
   OLED_GFX_DrawLine(x+3,y+3,x+5,y+3,1U);
   OLED_GFX_DrawLine(x+3,y+5,x+5,y+5,1U);
   if(hits>0U)OLED_GFX_DrawPixel(x+1,y+1,1U);
   if(hits>2U)OLED_GFX_DrawPixel(x+3,y+1,1U);
   if(hits>4U)OLED_GFX_DrawPixel(x+5,y+1,1U);
   if(hits>6U)OLED_GFX_DrawPixel(x+7,y+1,1U);
   if(hits>8U)OLED_GFX_DrawPixel(x+7,y+7,1U);
  }
 }else if(q && !used){
  OLED_GFX_DrawPixel(x+4,y+2,1U);OLED_GFX_DrawPixel(x+5,y+3,1U);OLED_GFX_DrawPixel(x+4,y+5,1U);
 }else if(q){
  /* 已用问号箱采用内凹纹理，与普通砖块区分。 */
  OLED_GFX_DrawRect(x+1,y+1,7,7,1U);OLED_GFX_DrawLine(x+2,y+2,x+6,y+2,1U);
  OLED_GFX_DrawPixel(x+4,y+4,1U);OLED_GFX_DrawLine(x+2,y+6,x+6,y+6,1U);
 }else if(used){
  OLED_GFX_DrawRect(x+1,y+1,7,7,1U);OLED_GFX_DrawPixel(x+4,y+2,1U);
  OLED_GFX_DrawLine(x+3,y+4,x+5,y+4,1U);OLED_GFX_DrawPixel(x+4,y+6,1U);
 }else{
  OLED_GFX_DrawLine(x,y+4,x+8,y+4,1U);OLED_GFX_DrawLine(x+4,y,x+4,y+3,1U);
 }
}
static void Pipe(int16_t x,int16_t top)
{
 OLED_GFX_FillRect(x+2,top+4,13,56-top-4,1); OLED_GFX_FillRect(x,top,17,5,1); OLED_GFX_DrawRect(x,top,17,5,1);
 OLED_GFX_DrawLine(x+4,top+6,x+4,55,0);
}
static void Goomba(int16_t x,int16_t y)
{
 /* 用逐行收窄的像素轮廓强化原版栗宝宝的菱形/蘑菇形剪影。 */
 OLED_GFX_FillRect(x+4,y,3,1,1U);
 OLED_GFX_FillRect(x+2,y+1,7,1,1U);
 OLED_GFX_FillRect(x+1,y+2,9,3,1U);
 OLED_GFX_FillRect(x+2,y+5,7,1,1U);
 OLED_GFX_FillRect(x+3,y+6,5,1,1U);
 OLED_GFX_FillRect(x+1,y+7,3,1,1U);
 OLED_GFX_FillRect(x+7,y+7,3,1,1U);
 /* 眼睛使用斜向留白像素，避免原来两个孤立方点的效果。 */
 OLED_GFX_DrawPixel(x+3,y+3,0U);OLED_GFX_DrawPixel(x+4,y+4,0U);
 OLED_GFX_DrawPixel(x+7,y+4,0U);OLED_GFX_DrawPixel(x+8,y+3,0U);
}
static void Koopa(int16_t x,int16_t y,uint8_t state)
{
 /* 乌龟精灵整体跟随动态 y 坐标； walking / shell 共用同一个底部锚点。 */
 if(state==0){
  OLED_GFX_FillRect(x+2,y+2,8,7,1); OLED_GFX_FillRect(x+7,y,5,5,1);
  OLED_GFX_DrawPixel(x+10,y+2,0); OLED_GFX_DrawLine(x+2,y+8,x+1,y+10,1);
  OLED_GFX_DrawLine(x+7,y+8,x+9,y+10,1);
  OLED_GFX_DrawLine(x+3,y+3,x+8,y+3,0);
 }else{
  OLED_GFX_FillRect(x+1,y+4,10,6,1); OLED_GFX_DrawRect(x+1,y+4,10,6,1);
  OLED_GFX_DrawLine(x+5,y+5,x+5,y+9,0); OLED_GFX_DrawPixel(x+8,y+7,0);
  if(state==3U){OLED_GFX_DrawLine(x+2,y+2,x+7,y,1);OLED_GFX_DrawLine(x+9,y+10,x+12,y+12,1);}
 }
}
static void Mushroom(int16_t x,int16_t y);
static void Piranha(int16_t x,int16_t y,uint8_t mouth_open)
{
 /* 经典食人花：圆润花冠、两侧白斑、锯齿状大嘴与细茎叶片。 */
 OLED_GFX_FillRect(x+5,y,7,2,1);OLED_GFX_FillRect(x+3,y+2,11,5,1);
 OLED_GFX_FillRect(x+1,y+4,15,3,1);
 OLED_GFX_DrawPixel(x+5,y+2,0);OLED_GFX_DrawPixel(x+11,y+2,0);
 OLED_GFX_DrawPixel(x+4,y+4,0);OLED_GFX_DrawPixel(x+12,y+4,0);
 if(mouth_open){OLED_GFX_FillRect(x+5,y+5,8,3,0);OLED_GFX_DrawLine(x+5,y+5,x+12,y+5,1);OLED_GFX_DrawLine(x+6,y+7,x+11,y+7,1);}
 else OLED_GFX_DrawLine(x+5,y+6,x+12,y+6,0);
 OLED_GFX_FillRect(x+7,y+7,3,5,1);
 OLED_GFX_DrawLine(x+7,y+10,x+2,y+9,1);OLED_GFX_DrawLine(x+9,y+10,x+14,y+9,1);
}
static void FlyingKoopa(int16_t x,int16_t y)
{
 /* 翅膀两帧交替摆动，壳体轮廓与普通龟一致，便于辨认受击前后形态。 */
 OLED_GFX_FillRect(x+2,y+4,8,6,1); OLED_GFX_FillRect(x+8,y+1,5,5,1);
 OLED_GFX_DrawPixel(x+11,y+3,0); OLED_GFX_DrawLine(x+2,y+9,x+1,y+12,1);
 OLED_GFX_DrawLine(x+7,y+9,x+9,y+12,1); OLED_GFX_DrawLine(x+2,y+4,x+8,y+4,0);
 if(s_frame&1U){
  OLED_GFX_FillRect(x-3,y,5,3,1);OLED_GFX_FillRect(x+10,y-1,5,3,1);
  OLED_GFX_DrawLine(x-3,y+2,x+1,y-1,1);OLED_GFX_DrawLine(x+9,y-1,x+14,y+2,1);
 }else{
  OLED_GFX_FillRect(x-3,y+3,5,3,1);OLED_GFX_FillRect(x+10,y+2,5,3,1);
  OLED_GFX_DrawLine(x-3,y+4,x+1,y+1,1);OLED_GFX_DrawLine(x+9,y+1,x+14,y+4,1);
 }
}
static void FlyingFish(int16_t x,int16_t y,uint8_t flip)
{
 OLED_GFX_FillRect(x+2,y+2,7,4,1U);
 OLED_GFX_FillRect(x+4,y+1,4,6,1U);
 if(!flip){OLED_GFX_DrawLine(x,y+4,x+3,y+1,1U);OLED_GFX_DrawLine(x,y+4,x+3,y+7,1U);OLED_GFX_DrawPixel(x+7,y+3,0U);}
 else {OLED_GFX_DrawLine(x+11,y+4,x+8,y+1,1U);OLED_GFX_DrawLine(x+11,y+4,x+8,y+7,1U);OLED_GFX_DrawPixel(x+3,y+3,0U);}
 OLED_GFX_DrawLine(x+4,y+1,x+7,y,1U);
}
static void PoisonMushroom(int16_t x,int16_t y)
{
 Mushroom(x,y); OLED_GFX_DrawPixel(x+2,y+1,0); OLED_GFX_DrawPixel(x+8,y+1,0);
 OLED_GFX_DrawPixel(x+5,y+3,0);
}
static void DrawLift(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x,y,24,3,1); OLED_GFX_DrawLine(x+2,y+3,x+2,y+5,1); OLED_GFX_DrawLine(x+21,y+3,x+21,y+5,1);
}
static void DrawVine(int16_t x)
{
 OLED_GFX_DrawLine(x,55,x,0,1);
 {int16_t y; for(y=4;y<56;y+=7){OLED_GFX_DrawLine(x,y,x-3,y+2,1);OLED_GFX_DrawLine(x,y+3,x+3,y+5,1);}}
}
static void DrawBowser(int16_t x,int16_t y,uint8_t walk_frame)
{
 /* 18×16 像素。脚部最低像素 y+15 与桥面顶边 y=46 对齐。 */
 OLED_GFX_FillRect(x+2,y+4,12,9,1); OLED_GFX_FillRect(x+10,y+1,7,7,1);
 OLED_GFX_DrawLine(x+3,y+4,x+5,y,1); OLED_GFX_DrawLine(x+7,y+4,x+10,y,1);
 OLED_GFX_DrawPixel(x+14,y+3,0); OLED_GFX_DrawLine(x+4,y+8,x+10,y+11,0);
 if(walk_frame&1U){OLED_GFX_DrawLine(x+3,y+12,x,y+15,1);OLED_GFX_DrawLine(x+11,y+12,x+14,y+14,1);}
 else{OLED_GFX_DrawLine(x+3,y+12,x+2,y+15,1);OLED_GFX_DrawLine(x+11,y+12,x+15,y+15,1);}
}
static void DrawBowserFalling(int16_t x,int16_t y,uint8_t frame)
{
 /* 坠落时逐帧翻滚：三种倾斜轮廓循环，避免只把站立精灵直线下移。 */
 if((frame%3U)==0U){DrawBowser(x,y,frame);}
 else if((frame%3U)==1U){
  OLED_GFX_DrawLine(x+2,y+6,x+11,y+2,1);OLED_GFX_DrawLine(x+4,y+12,x+15,y+8,1);
  OLED_GFX_FillRect(x+11,y+1,6,6,1);OLED_GFX_DrawPixel(x+15,y+3,0);
  OLED_GFX_DrawLine(x+4,y+11,x+1,y+15,1);OLED_GFX_DrawLine(x+11,y+8,x+16,y+12,1);
  OLED_GFX_DrawLine(x+5,y+5,x+8,y,1);OLED_GFX_DrawLine(x+9,y+4,x+13,y,1);
 }
 else{
  OLED_GFX_FillRect(x+3,y+5,11,8,1);OLED_GFX_FillRect(x,y+2,7,6,1);
  OLED_GFX_DrawPixel(x+3,y+4,0);OLED_GFX_DrawLine(x+2,y+12,x+6,y+15,1);
  OLED_GFX_DrawLine(x+12,y+12,x+16,y+14,1);OLED_GFX_DrawLine(x+7,y+5,x+12,y+1,1);
 }
}
static void DrawCannon(int16_t x)
{
 OLED_GFX_FillRect(x+2,45,12,11,1); OLED_GFX_DrawRect(x+2,45,12,11,1);
 OLED_GFX_FillRect(x+7,48,10,5,1); OLED_GFX_DrawRect(x+7,48,10,5,1);
 OLED_GFX_DrawLine(x+4,46,x+4,54,0);
}
static void DrawBulletBill(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x+2,y,8,7,1); OLED_GFX_FillRect(x,y+2,12,4,1);
 OLED_GFX_DrawPixel(x+8,y+2,0); OLED_GFX_DrawLine(x+2,y+1,x,y-1,1);
 OLED_GFX_DrawLine(x+2,y+6,x,y+8,1); OLED_GFX_DrawLine(x+10,y+1,x+12,y-1,1);
}
static void DrawSpring(int16_t x)
{
 /* 2-1 弹簧：底座、三段弹簧线圈和顶板，接触顶面会触发高跳。 */
 OLED_GFX_FillRect(x+1,53,10,3,1U);
 OLED_GFX_DrawLine(x+2,52,x+9,52,1U);
 OLED_GFX_DrawLine(x+2,50,x+9,52,1U);
 OLED_GFX_DrawLine(x+9,50,x+2,50,1U);
 OLED_GFX_DrawLine(x+2,50,x+9,48,1U);
 OLED_GFX_FillRect(x,48,12,2,1U);
 OLED_GFX_DrawRect(x,48,12,2,1U);
}
static void DrawFirebar(int16_t x,int16_t y,uint8_t phase,uint8_t segments)
{
 static const int8_t dx[16]={0,1,2,2,2,1,0,-1,-2,-2,-2,-1,0,1,2,1};
 static const int8_t dy[16]={-2,-2,-1,0,1,2,2,2,1,0,-1,-2,-2,-2,-1,0};
 uint8_t k;
 OLED_GFX_FillRect(x-1,y-1,3,3,1U);
 for(k=1U;k<=segments;k++){
  int16_t px=(int16_t)(x+dx[phase&15U]*3*k);
  int16_t py=(int16_t)(y+dy[phase&15U]*3*k);
  OLED_GFX_FillRect(px-1,py-1,3,3,1U);
 }
}
static void DrawPodoboo(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x+2,y+2,6,5,1U);
 OLED_GFX_DrawLine(x+2,y+2,x+1,y-1,1U);
 OLED_GFX_DrawLine(x+5,y+1,x+5,y-3,1U);
 OLED_GFX_DrawLine(x+8,y+2,x+10,y-1,1U);
 OLED_GFX_DrawPixel(x+3,y+4,0U);
 OLED_GFX_DrawPixel(x+7,y+4,0U);
}
static void DrawHammerBro(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x+2,y+4,9,8,1); OLED_GFX_FillRect(x+4,y,8,7,1);
 OLED_GFX_DrawPixel(x+9,y+2,0); OLED_GFX_DrawLine(x+2,y+6,x,y+9,1);
 OLED_GFX_DrawLine(x+10,y+7,x+13,y+10,1); OLED_GFX_DrawLine(x+3,y+12,x+2,y+14,1);
 OLED_GFX_DrawLine(x+9,y+12,x+11,y+14,1); OLED_GFX_DrawLine(x+3,y+5,x+10,y+5,0);
}
static void DrawHammer(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x,y,5,4,1); OLED_GFX_DrawRect(x,y,5,4,1);
 OLED_GFX_DrawLine(x+2,y+4,x+4,y+8,1);
}
/* 马里奥按下桥头斧柄的三段手臂动作。 */
static void DrawMarioAxePressPose(int16_t x,int16_t y,uint16_t tick)
{
 if(tick<4U){
  OLED_GFX_DrawLine(x+6,y+7,x+10,y-2,1U);
  OLED_GFX_DrawLine(x+10,y-2,x+13,y-6,1U);
  OLED_GFX_DrawPixel(x+13,y-6,1U);
 }else if(tick<8U){
  OLED_GFX_DrawLine(x+6,y+7,x+11,y-4,1U);
  OLED_GFX_DrawLine(x+11,y-4,x+15,y-7,1U);
  OLED_GFX_DrawPixel(x+15,y-7,1U);
 }else{
  OLED_GFX_DrawLine(x+6,y+7,x+11,y-1,1U);
  OLED_GFX_DrawLine(x+11,y-1,x+15,y-4,1U);
  OLED_GFX_DrawPixel(x+15,y-4,1U);
 }
}
static void DrawCastleLever(int16_t x)
{
 OLED_GFX_DrawLine(x+4,39,x+4,53,1); OLED_GFX_FillRect(x+1,51,8,3,1);
 OLED_GFX_DrawLine(x+4,40,x+10,35,1); OLED_GFX_FillRect(x+8,33,5,4,1);
}
static void DrawLavaPit(int16_t x,int16_t w)
{
 OLED_GFX_FillRect(x,55,w,9,0); OLED_GFX_DrawLine(x,55,x+w-1,55,1);
 OLED_GFX_DrawLine(x+5,58,x+12,56,1); OLED_GFX_DrawLine(x+18,61,x+25,58,1);
 OLED_GFX_DrawLine(x+31,57,x+38,60,1);
}
static void DrawHorizontalPipe(int16_t x)
{
 OLED_GFX_FillRect(x,42,22,9,1); OLED_GFX_DrawRect(x,42,22,9,1);
 OLED_GFX_FillRect(x+15,39,6,15,1); OLED_GFX_DrawRect(x+15,39,6,15,1);
 OLED_GFX_DrawLine(x+3,44,x+12,44,0);
}
/* 关卡终点横向三通管：左侧为管口，右侧接入墙体，顶部有加宽接口。 */
static void DrawHorizontalGoalPipe(int16_t x)
{
 /* 左侧入口、横向主管与顶部支管组成三通结构；入口内侧留黑，便于识别进入方向。 */
 OLED_GFX_FillRect(x+6,39,31,13,1U);
 OLED_GFX_FillRect(x,36,12,19,1U); OLED_GFX_DrawRect(x,36,12,19,1U);
 OLED_GFX_FillRect(x+3,40,6,11,0U); OLED_GFX_DrawRect(x+3,40,6,11,1U);
 OLED_GFX_FillRect(x+23,30,10,11,1U); OLED_GFX_DrawRect(x+23,30,10,11,1U);
 OLED_GFX_DrawLine(x+9,41,x+36,41,0U);
 OLED_GFX_DrawLine(x+9,49,x+36,49,0U);
}
/* 公主救援精灵：王冠、长发、面部和礼服均用 128x64 OLED 原生绘图指令组成。 */
static void DrawPrincess(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x+3,y+3,8,7,1);          /* 长发 */
 OLED_GFX_FillRect(x+4,y+4,7,5,0);          /* 脸部留白 */
 OLED_GFX_DrawLine(x+4,y+2,x+6,y,1);        /* 王冠 */
 OLED_GFX_DrawLine(x+6,y,x+8,y+2,1);
 OLED_GFX_DrawPixel(x+6,y+4,1); OLED_GFX_DrawPixel(x+9,y+4,1); /* 眼睛 */
 OLED_GFX_FillRect(x+2,y+10,10,6,1);        /* 礼服 */
 OLED_GFX_DrawLine(x+2,y+11,x,y+8,1);       /* 左手 */
 OLED_GFX_DrawLine(x+12,y+11,x+14,y+8,1);   /* 右手 */
 OLED_GFX_DrawLine(x+3,y+16,x+1,y+18,1);
 OLED_GFX_DrawLine(x+10,y+16,x+12,y+18,1);
}
static void Mushroom(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x+1,y,9,4,1); OLED_GFX_FillRect(x,y+2,11,3,1);
 OLED_GFX_FillRect(x+3,y+4,5,4,1); OLED_GFX_DrawPixel(x+3,y+1,0); OLED_GFX_DrawPixel(x+8,y+2,0);
}
static void LifeMushroom(int16_t x,int16_t y)
{
 Mushroom(x,y);
 /* 一命蘑菇使用更多小圆点纹理，与普通红蘑菇区分。 */
 OLED_GFX_DrawPixel(x+5,y+1,0);OLED_GFX_DrawPixel(x+1,y+3,0);
 OLED_GFX_DrawPixel(x+9,y+3,0);OLED_GFX_DrawPixel(x+5,y+5,0);
}
static void FireFlower(int16_t x,int16_t y)
{
 /* 花瓣分成上下左右四瓣，中心留白点，茎和叶片独立绘制。 */
 OLED_GFX_FillRect(x+4,y,3,3,1U);
 OLED_GFX_FillRect(x,y+3,4,3,1U);
 OLED_GFX_FillRect(x+7,y+3,4,3,1U);
 OLED_GFX_FillRect(x+3,y+6,5,3,1U);
 OLED_GFX_DrawPixel(x+5,y+4,0U);OLED_GFX_DrawPixel(x+6,y+4,0U);
 OLED_GFX_DrawLine(x+5,y+8,x+5,y+11,1U);
 OLED_GFX_DrawLine(x+5,y+9,x+2,y+8,1U);
 OLED_GFX_DrawPixel(x+1,y+8,1U);OLED_GFX_DrawPixel(x+9,y+10,1U);
}
/* 城堡尺寸随关卡递增：从 WORLD 1-1 到 WORLD 2-4 逐关增大。 */
static int16_t CastleWidth(void) { return (int16_t)(22U+(uint16_t)s_level*3U); }
static int16_t CastleHeight(void) { return (int16_t)(12U+(uint16_t)s_level*2U); }
static void DrawCastleBackdrop(int16_t x)
{
 int16_t w=CastleWidth(),h=CastleHeight(),top=(int16_t)(GROUND_TOP-h);
 uint8_t k;
 /* 主塔身、两侧塔楼和垛口，避免原先只像一块方砖。 */
 OLED_GFX_FillRect(x+5,top+7,w-10,h-7,1U);
 OLED_GFX_FillRect(x,top+4,9,h-4,1U);
 OLED_GFX_FillRect(x+w-9,top+4,9,h-4,1U);
 OLED_GFX_FillRect(x+1,top,3,5,1U);OLED_GFX_FillRect(x+5,top+2,4,3,1U);
 OLED_GFX_FillRect(x+w-4,top,3,5,1U);OLED_GFX_FillRect(x+w-9,top+2,4,3,1U);
 /* 塔身砖缝。 */
 for(k=0U;k<3U;k++){
  int16_t yy=(int16_t)(top+11+(int16_t)k*6);
  OLED_GFX_DrawLine(x+10,yy,x+w-11,yy,0U);
  OLED_GFX_DrawLine(x+((k&1U)?14:18),yy-5,x+((k&1U)?14:18),yy,0U);
 }
 OLED_GFX_FillRect(x+w/2-4,GROUND_TOP-12,8,12,0U);
 OLED_GFX_DrawRect(x+w/2-4,GROUND_TOP-12,8,12,1U);
 OLED_GFX_DrawLine(x+w/2-2,GROUND_TOP-2,x+w/2-2,GROUND_TOP-8,1U);
 if(h>=18){
  OLED_GFX_FillRect(x+2,top+9,3,5,0U);OLED_GFX_FillRect(x+w-5,top+9,3,5,0U);
  OLED_GFX_DrawLine(x+3,top+9,x+3,top+13,1U);OLED_GFX_DrawLine(x+w-4,top+9,x+w-4,top+13,1U);
 }
}
/* 普通关终点旗杆和城堡；Mario 进入城堡时，城堡屋顶旗帜同步升起。 */
static uint8_t CastleRoofFlagRaise(void)
{
 if(s_state==18U){
  uint16_t raise=(uint16_t)(s_state_ms/2U);
  return (raise>14U)?14U:(uint8_t)raise;
 }
 /* 1-1 升旗完成后还要播放自动进管动画，屋顶旗帜保持升起。 */
 return (s_state==3U || s_state==5U || s_state==20U)?14U:0U;
}
static void CastleFlag(int16_t x)
{
 int16_t castle_x=(int16_t)(x+24);
 int16_t w=CastleWidth();
 int16_t top=(int16_t)(GROUND_TOP-CastleHeight());
 int16_t flag_x=(int16_t)(castle_x+w/2);
 int16_t flag_y=(int16_t)(top+6-CastleRoofFlagRaise());
 OLED_GFX_DrawLine(x,12,x,56,1);
 OLED_GFX_FillRect(x+1,s_flag_pole_y,11,6,1);
 DrawCastleBackdrop(castle_x);
 OLED_GFX_DrawLine(flag_x,top-9,flag_x,top+7,1U);
 OLED_GFX_FillRect(flag_x+1,flag_y,8,4,1U);
 OLED_GFX_DrawPixel(flag_x+8,flag_y+2,1U);
}
static void DrawStairs(int16_t sx,uint8_t staircase)
{
 uint8_t row,col,rows=StaircaseRowsFor(staircase);
 /* 反向楼梯仅两层，避免形成过高墙体；正向楼梯保持原高度。 */
 for(row=0U;row<rows;row++)for(col=0U;col<(uint8_t)(rows-row);col++){
  int16_t bx=(int16_t)(sx+(int16_t)(((staircase&1U)?col:(uint8_t)(row+col))*9U));
  int16_t by=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
  OLED_GFX_FillRect(bx,by,9,9,1U);
  OLED_GFX_DrawRect(bx,by,9,9,1U);
 }
}
static int16_t FindLanding(int16_t old_bottom,int16_t new_bottom,int16_t old_camera,int16_t new_camera,uint8_t *platform)
{
 uint8_t i; int16_t a,b,l,r,t,best=32767; *platform=0;
 if(s_velocity_y<0)return -1;
 /* Ground is absent across normal cliff gaps and the collapsed castle bridge pit. */
 {
  int16_t landing_world=(int16_t)(new_camera+MARIO_X+MARIO_W/2);
  uint8_t castle_pit=(uint8_t)(IsCastleLevel() && s_boss_bridge_broken &&
      landing_world>=GoalX()-170 && landing_world<GoalX()-55);
  if(!InCliff(landing_world) && !castle_pit && old_bottom<=GROUND_TOP && new_bottom>=GROUND_TOP)best=GROUND_TOP;
 }
 for(i=0;i<PipeActiveCount();i++){
  a=PipeX(i)-old_camera;b=PipeX(i)-new_camera;l=(a<b)?a:b;r=((a>b)?a:b)+17;t=PipeTop(i);
  if(MARIO_X+MARIO_W>l && MARIO_X<r && old_bottom<=t && new_bottom>=t && t<best){best=t;*platform=1;}
 }
 for(i=0;i<ActiveBlockCount();i++)if(!s_block_broken[i] && !BlockMergedFollower(i)){
  a=BlockX(i)-old_camera;b=BlockX(i)-new_camera;l=(a<b)?a:b;r=((a>b)?a:b)+BlockWidth(i);t=BlockY(i);
  if(MARIO_X+MARIO_W>l && MARIO_X<r && old_bottom<=t && new_bottom>=t && t<best){best=t;*platform=1;}
 }
 /* WORLD 1-3 的蘑菇平台是独立的落脚面，跨越地图中的断崖。 */
 if(s_level==3U){
  static const int16_t px[4]={250,580,920,1200};
  static const int16_t py[4]={34,27,36,29};
  static const uint8_t pw[4]={30,34,30,36};
  for(i=0;i<4;i++){
   a=px[i]-old_camera;b=px[i]-new_camera;l=(a<b)?a:b;r=((a>b)?a:b)+pw[i];t=py[i];
   if(MARIO_X+MARIO_W>l && MARIO_X<r && old_bottom<=t && new_bottom>=t && t<best){best=t;*platform=1;}
  }
 }
 /* WORLD 2-3 是从起点到终点连续铺设的单座桥。 */
 if(s_level==7U && old_bottom<=46 && new_bottom>=46){best=46;*platform=1U;}
 /* 地下关的移动升降台。 */
 if(s_level==2U)for(i=0;i<LIFT_COUNT;i++){
  int16_t wx=s_lift_x[i];a=wx-old_camera;b=wx-new_camera;l=(a<b)?a:b;r=((a>b)?a:b)+24;t=s_lift_y[i];
  if(MARIO_X+MARIO_W>l && MARIO_X<r && old_bottom<=t && new_bottom>=t && t<best){best=t;*platform=1;}
 }
 /* WORLD 2-1 的弹簧顶板：可站立，并在落地分支触发高弹跳。 */
 if(SpringActive()){
  int16_t a0=SpringX()-old_camera,b0=SpringX()-new_camera;
  int16_t l0=(a0<b0)?a0:b0,r0=((a0>b0)?a0:b0)+SPRING_WIDTH;
  if(MARIO_X+MARIO_W>l0 && MARIO_X<r0 && old_bottom<=SPRING_TOP && new_bottom>=SPRING_TOP && SPRING_TOP<best){best=SPRING_TOP;*platform=1U;}
 }
 /* 多组阶梯的每个台阶都参与落地检测；城堡桥前仍不在 Boss 区域堆楼梯。 */
 {
  uint8_t st,row,col;
  for(st=0U;st<StaircaseCount();st++)for(row=0U;row<StaircaseRowsFor(st);row++)for(col=0U;col<(uint8_t)(StaircaseRowsFor(st)-row);col++){
   int16_t wx=StairBlockX(st,row,col);
   int16_t top=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
   a=wx-old_camera;b=wx-new_camera;l=(a<b)?a:b;r=((a>b)?a:b)+9;
   if(MARIO_X+MARIO_W>l && MARIO_X<r && old_bottom<=top && new_bottom>=top && top<best){best=top;*platform=1U;}
  }
 }
 return best==32767?-1:best;
}

/* 摄像机推进等价于马里奥在世界坐标中行走；水管侧壁必须阻止横向穿越。 */
static void MoveCameraRespectPipes(int8_t dir)
{
 int16_t old_x=s_camera,new_x=(int16_t)(s_camera+dir*2);
 uint8_t i;
 if(new_x<0)new_x=0;
 if(new_x>WorldLength()-128)new_x=(int16_t)(WorldLength()-128);
 if(s_sky_mode){
  int16_t sky_min=(int16_t)(s_vine_x-MARIO_X-8);
  int16_t sky_max=(int16_t)(s_vine_x+350-MARIO_X-MARIO_W);
  if(new_x<sky_min)new_x=sky_min;
  if(new_x>sky_max)new_x=sky_max;
 }
 /* 天空奖励地图使用独立浮岛；地面关卡隐藏的水管/砖块不能挡住地面行走。 */
 if(s_sky_mode){
  int16_t sky_min=(int16_t)(s_vine_x-MARIO_X-8);
  int16_t sky_max=(int16_t)(s_vine_x+350-MARIO_X-MARIO_W);
  if(new_x<sky_min)new_x=sky_min;
  if(new_x>sky_max)new_x=sky_max;
  s_camera=new_x;return;
 }
 for(i=0;i<PipeActiveCount();i++){
  int16_t px=PipeX(i);
  if(s_mario_y+MARIO_H>PipeTop(i)+3 && s_mario_y<PipeTop(i)+18){
   if(dir>0 && old_x+MARIO_X+MARIO_W<=px && new_x+MARIO_X+MARIO_W>px)
    new_x=(int16_t)(px-MARIO_X-MARIO_W);
   else if(dir<0 && old_x+MARIO_X>=px+17 && new_x+MARIO_X<px+17)
    new_x=(int16_t)(px+17-MARIO_X);
  }
 }
 /* WORLD 1-2 的升降台有实体侧壁：横向碰到平台侧面时停在平台外侧。 */
 if(s_level==2U){
  int16_t old_left=(int16_t)(old_x+MARIO_X),new_left=(int16_t)(new_x+MARIO_X);
  for(i=0U;i<LIFT_COUNT;i++){
   int16_t lx=s_lift_x[i],ly=s_lift_y[i];
   if(s_mario_y+MARIO_H>ly+1 && s_mario_y<ly+5){
    if(dir>0 && old_left+MARIO_W<=lx && new_left+MARIO_W>lx)
     new_x=(int16_t)(lx-MARIO_X-MARIO_W);
    else if(dir<0 && old_left>=lx+24 && new_left<lx+24)
     new_x=(int16_t)(lx+24-MARIO_X);
   }
  }
 }
 /* WORLD 2-1 的炮弹发射车是实体障碍，必须跳过；火球不能摧毁发射车。 */
 if(s_level==5U && s_mario_y+MARIO_H>45 && s_mario_y<GROUND_TOP){
  for(i=0;i<BULLET_BILL_COUNT;i++){
   int16_t cx=s_bill_cannon_x[i];
   if(dir>0 && old_x+MARIO_X+MARIO_W<=cx && new_x+MARIO_X+MARIO_W>cx)
    new_x=(int16_t)(cx-MARIO_X-MARIO_W);
   else if(dir<0 && old_x+MARIO_X>=cx+17 && new_x+MARIO_X<cx+17)
    new_x=(int16_t)(cx+17-MARIO_X);
  }
 }
 /* 2-2 起点高墙以及其他砖块也具有实体侧面，不能从侧边穿过去。 */
 for(i=0;i<ActiveBlockCount();i++)if(!s_block_broken[i]){
  int16_t bx=BlockX(i),by=BlockY(i);
  if(s_mario_y+MARIO_H>by && s_mario_y<by+9){
   if(dir>0 && old_x+MARIO_X+MARIO_W<=bx && new_x+MARIO_X+MARIO_W>bx)
    new_x=(int16_t)(bx-MARIO_X-MARIO_W);
   else if(dir<0 && old_x+MARIO_X>=bx+BlockWidth(i) && new_x+MARIO_X<bx+BlockWidth(i))
    new_x=(int16_t)(bx+BlockWidth(i)-MARIO_X);
  }
 }
 /* 阶梯方块具有实体侧面：不跳跃时不能直接穿过台阶，跳上后可继续前进。 */
 {
  uint8_t st,row,col;
  for(st=0U;st<StaircaseCount();st++)for(row=0U;row<StaircaseRowsFor(st);row++)for(col=0U;col<(uint8_t)(StaircaseRowsFor(st)-row);col++){
   int16_t bx=StairBlockX(st,row,col);
   int16_t by=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
   if(s_mario_y+MARIO_H>by && s_mario_y<by+9){
    if(dir>0 && old_x+MARIO_X+MARIO_W<=bx && new_x+MARIO_X+MARIO_W>bx)
     new_x=(int16_t)(bx-MARIO_X-MARIO_W);
    else if(dir<0 && old_x+MARIO_X>=bx+9 && new_x+MARIO_X<bx+9)
     new_x=(int16_t)(bx+9-MARIO_X);
   }
  }
 }
 if(new_x<0)new_x=0;
 if(new_x>WorldLength()-128)new_x=(int16_t)(WorldLength()-128);
 s_camera=new_x;
}

/* 食人花沿管道周期升降；返回当前绘制顶端，phase 中间阶段张嘴。 */

/* 1-3 的乌龟第二次被踩中后，朝最近的悬崖边缘走去。 */
static int8_t DirectionToNearestCliff(int16_t wx)
{
 static const int16_t centers[4]={273,603,943,1243};
 uint8_t i,best=0;int16_t distance=(wx>centers[0])?(wx-centers[0]):(centers[0]-wx);
 for(i=1;i<4;i++){int16_t d=(wx>centers[i])?(wx-centers[i]):(centers[i]-wx);if(d<distance){distance=d;best=i;}}
 return (wx<centers[best])?1:-1;
}

static int16_t PiranhaY(uint8_t i)
{
 uint8_t t=(uint8_t)(s_plant_phase[i]%100U);
 int16_t top=PipeTop(i);
 if(t<25U)return (int16_t)(top+2-(t*11U)/25U);
 if(t<50U)return (int16_t)(top-9);
 if(t<75U)return (int16_t)(top-9+((t-50U)*11U)/25U);
 return (int16_t)(top+2);
}

static void DrawCoin(int16_t x,int16_t y)
{
 /* 两帧交替改变金币宽度，模拟原地旋转的正面/侧面。 */
 if(s_frame&1U){
  OLED_GFX_DrawRect(x+2,y,4,8,1);
  OLED_GFX_DrawLine(x+3,y+2,x+4,y+2,1);
  OLED_GFX_DrawLine(x+3,y+5,x+4,y+5,1);
 }else{
  OLED_GFX_DrawLine(x+3,y+1,x+4,y+1,1);
  OLED_GFX_DrawLine(x+3,y+6,x+4,y+6,1);
  OLED_GFX_DrawLine(x+3,y+2,x+3,y+5,1);
  OLED_GFX_DrawLine(x+4,y+2,x+4,y+5,1);
 }
}
static void DrawPowerStar(int16_t x,int16_t y)
{
 static const int8_t sx[10]={4,5,8,6,7,4,1,2,0,3};
 static const int8_t sy[10]={0,3,3,5,8,6,8,5,3,3};
 uint8_t k;
 /* 星星每隔一帧闪亮一次；外轮廓为真正的五角星，而不是十字形。 */
 if((s_frame&1U)==0U)return;
 for(k=0U;k<10U;k++){
  uint8_t n=(uint8_t)((k+1U)%10U);
  OLED_GFX_DrawLine((int16_t)(x+sx[k]),(int16_t)(y+sy[k]),
                    (int16_t)(x+sx[n]),(int16_t)(y+sy[n]),1U);
 }
 OLED_GFX_DrawLine(x+4,y+4,x+4,y+1,1U);
 OLED_GFX_DrawLine(x+4,y+4,x+7,y+3,1U);
 OLED_GFX_DrawLine(x+4,y+4,x+6,y+7,1U);
 OLED_GFX_DrawLine(x+4,y+4,x+1,y+7,1U);
 OLED_GFX_DrawLine(x+4,y+4,x+1,y+3,1U);
}
static void DrawFirework(int16_t cx,int16_t cy,uint8_t phase)
{
 static const int8_t dx[8]={0,1,1,1,0,-1,-1,-1};
 static const int8_t dy[8]={-1,-1,0,1,1,1,0,-1};
 uint8_t r=(uint8_t)(1U+(phase%5U)),k;
 for(k=0U;k<8U;k++){
  OLED_GFX_DrawLine(cx,cy,(int16_t)(cx+dx[k]*r*2),(int16_t)(cy+dy[k]*r*2),1U);
 }
 OLED_GFX_DrawPixel(cx,cy,1U);
}
static void DrawClearFireworks(void)
{
 uint8_t phase=(uint8_t)((s_state_ms/50U)%10U);
 DrawFirework(17,15,phase);
 DrawFirework(110,13,(uint8_t)(phase+3U));
 if(phase>2U)DrawFirework(63,11,(uint8_t)(phase+6U));
}
static void DrawSpikeCloud(int16_t x,int16_t y)
{
 OLED_GFX_FillRect(x+2,y+3,16,6,1); OLED_GFX_FillRect(x+5,y,10,5,1);
 OLED_GFX_DrawPixel(x+7,y+4,0); OLED_GFX_DrawPixel(x+14,y+4,0);
 OLED_GFX_DrawLine(x+4,y+9,x+2,y+12,1); OLED_GFX_DrawLine(x+10,y+9,x+10,y+13,1);
 OLED_GFX_DrawLine(x+16,y+9,x+18,y+12,1);
}

/* 1-3 的蘑菇平台：顶部可站立，下面的缺口仍然会让马里奥掉落。 */
static void DrawMushroomPlatform(int16_t x,int16_t y,uint8_t w)
{
 OLED_GFX_FillRect(x+2,y,w-4,3,1);
 OLED_GFX_DrawLine(x,y+4,x+w,y+4,1);
 OLED_GFX_DrawLine(x+3,y+5,x+w-3,y+5,1);
}

/* WORLD 2-3 木桥：桥面有横向木板纹理，画在水面上方。 */
static void DrawBridge(int16_t x,uint8_t w)
{
 OLED_GFX_FillRect(x,46,w,2,1);
 OLED_GFX_DrawLine(x+4,48,x+4,50,1);
 OLED_GFX_DrawLine(x+w-5,48,x+w-5,50,1);
 {uint8_t k;for(k=9;k<w;k=(uint8_t)(k+12U))OLED_GFX_DrawLine(x+k,46,x+k,47,0);}
}

/* 刺猬怪：尖刺背部，移动方向会改变。 */
static void DrawHedgehog(int16_t x)
{
 OLED_GFX_FillRect(x+2,49,10,6,1);
 OLED_GFX_DrawLine(x+3,49,x+1,45,1); OLED_GFX_DrawLine(x+6,49,x+6,44,1);
 OLED_GFX_DrawLine(x+9,49,x+12,45,1);
 OLED_GFX_DrawPixel(x+4,51,0); OLED_GFX_DrawPixel(x+10,51,0);
 OLED_GFX_DrawLine(x+3,55,x+2,57,1); OLED_GFX_DrawLine(x+10,55,x+12,57,1);
}

/* 结尾署名：使用 5x7 拉丁字模与 16x16 中文点阵，提升“虎王”辨识度。 */
static void DrawMadeByCredit(void)
{
 static const uint8_t latin[7][7]={
  {17,27,21,17,17,17,17}, /* M */
  {0,14,1,15,17,15,0},    /* a */
  {1,1,15,17,17,15,0},    /* d */
  {0,14,17,31,16,14,0},   /* e */
  {0,0,0,0,0,0,0},        /* space */
  {16,16,30,17,17,30,0},  /* b */
  {17,17,15,1,17,14,0}    /* y */
 };
 /* 16x16 汉字点阵：比旧版 8x8 字模加倍，确保“虎王”在 128x64 屏上清晰可辨。 */
 static const uint16_t hu[16]={
  0x0000U,0x0000U,0x01F0U,0x01F8U,0x1FF8U,0x1FFCU,0x1BF8U,0x1FE8U,
  0x19FCU,0x1960U,0x1B60U,0x136CU,0x367CU,0x3C38U,0x0000U,0x0000U
 };
 static const uint16_t wang[16]={
  0x0000U,0x0000U,0x0000U,0x1FF8U,0x0180U,0x0180U,0x0180U,0x1FF8U,
  0x0FF0U,0x0180U,0x0180U,0x0180U,0x3FFCU,0x0000U,0x0000U,0x0000U
 };
 uint8_t i,r,c;int16_t x=33;
 for(i=0U;i<7U;i++){
  for(r=0U;r<7U;r++)for(c=0U;c<5U;c++)
   if(latin[i][r]&(uint8_t)(1U<<(4U-c)))OLED_GFX_DrawPixel((int16_t)(x+c),(int16_t)(49+r),1U);
  x=(int16_t)(x+6);
 }
 x=(int16_t)(x+1);
 for(r=0U;r<16U;r++)for(c=0U;c<16U;c++){
  if(hu[r]&(uint16_t)(1U<<(15U-c)))OLED_GFX_DrawPixel((int16_t)(x+c),(int16_t)(48+r),1U);
  if(wang[r]&(uint16_t)(1U<<(15U-c)))OLED_GFX_DrawPixel((int16_t)(x+18+c),(int16_t)(48+r),1U);
 }
}

/* 根据当前摄像机位置绘制可视区域内的地图、敌人、道具和马里奥。 */
static void DrawScene(void)
{
 int16_t x,sx; uint8_t i;
 OLED_GFX_Clear();
 if(s_state==15U){
  DrawTinyString(46,12,"You win!");
  DrawTinyString(24,34,"Press PB1 to restart");
  DrawMadeByCredit();
  return;
 }
 if(s_state==17U){
  /* 每关独立标题卡：停留 1 秒，期间 PA1 不响应暂停，背景音乐冻结。 */
  DrawTinyString(25,27,LevelName());
  DrawTinyString(45,43,"READY!");
  return;
 }
 if(s_state==9U){
  /* 启动页：PB1 进入选关界面。 */
  DrawTinyString(25,13,"SUPER");DrawTinyString(17,22,"MARIO");
  OLED_GFX_DrawRect(38,36,52,14,1U);DrawTinyString(51,41,"START");
  DrawTinyString(3,55,"V1.0 PRE6");
  DrawTinyString(69,55,"PB1 SELECT");
  return;
 }
 if(s_state==13U){
  /* 选关页：PA1 顺序循环八个关卡，PB1 确认并开始所选关卡。 */
  static const char *const title_level_names[8] = {
   "WORLD 1-1","WORLD 1-2","WORLD 1-3","WORLD 1-4",
   "WORLD 2-1","WORLD 2-2","WORLD 2-3","WORLD 2-4"
  };
  DrawTinyString(39,10,"SELECT");
  DrawTinyString(33,23,title_level_names[(s_title_level>=1U && s_title_level<=8U)?(s_title_level-1U):0U]);
  OLED_GFX_DrawRect(17,34,94,11,1U);
  DrawTinyString(37,37,"PA1 NEXT");
  DrawTinyString(39,52,"PB1 OK");
  return;
 }
 if(s_sewer_mode){
  /* 独立地下奖励场景：砖墙、地面金币和右侧横向出口水管。 */
  for(x=-(s_camera%16);x<128;x+=16){OLED_GFX_DrawRect(x,8,16,10,1);OLED_GFX_DrawLine(x+8,8,x+8,17,1);}
  for(x=0;x<128;x+=8){OLED_GFX_FillRect(x,56,8,8,1);OLED_GFX_DrawLine(x,59,x,63,0);}
  OLED_GFX_DrawLine(0,19,127,19,1);OLED_GFX_DrawLine(0,21,127,21,1);
  for(i=0;i<SEWER_COIN_COUNT;i++)if(!s_sewer_coin_taken[i]){
   sx=(int16_t)(s_sewer_coin_x[i]-s_camera);if(sx>-8&&sx<128)DrawCoin(sx,s_sewer_coin_y[i]);
  }
  sx=(int16_t)(SEWER_EXIT_X-s_camera);if(sx>-40&&sx<128)DrawHorizontalGoalPipe(sx);
  /* 使用统一透明精灵；无敌期间外围矩形框由 DrawMarioSpriteAt() 闪烁绘制。 */
  DrawMarioSpriteAt(MARIO_X,s_mario_y,0U);
  DrawMiniHud();
  DrawTinyString(43,11,"SEWER");
  if(s_state==10U){OLED_GFX_FillRect(31,24,66,18,0U);OLED_GFX_DrawRect(31,24,66,18,1U);DrawTinyString(48,30,"PAUSED");}
  return;
 }
 if(s_level==1U || s_level==3U || s_level==5U || s_level==7U){
  /* 地面关卡背景保持简洁：只绘制天空中的云，不再绘制山丘/地平线纹理。 */
  Cloud(14-(s_camera/3)%150,12); Cloud(88-(s_camera/4)%150,8); Cloud(185-(s_camera/3)%170,15);
 } else if(s_level==2U) {
  /* WORLD 1-2 地下背景：顶部砖格只保留一层，避免原先两层叠排显得过于拥挤。 */
  for(x=-(s_camera%18);x<128;x+=18){
   OLED_GFX_DrawRect(x,7,18,9,1);
   OLED_GFX_DrawLine(x+8,7,x+8,15,1);
  }
 } else if(IsUnderwaterLevel()) {
  /* 水下关卡：波纹和气泡作为背景提示。 */
  for(x=-(s_camera%20);x<128;x+=20){OLED_GFX_DrawLine(x,17,x+8,15,1);OLED_GFX_DrawLine(x+8,15,x+16,17,1);}
  for(x=12;x<128;x+=37){OLED_GFX_DrawPixel(x,(int16_t)(27+(x%3)*5),1);OLED_GFX_DrawPixel(x+2,(int16_t)(25+(x%3)*5),1);}
  /* 水母以小伞状轮廓绘制。 */
  for(i=0;i<JELLY_COUNT;i++)if(s_jelly_alive[i]){sx=s_jelly_x[i]-s_camera;if(sx>-10&&sx<128){OLED_GFX_DrawLine(sx+2,s_jelly_y[i],sx+7,s_jelly_y[i],1);OLED_GFX_DrawLine(sx,s_jelly_y[i]+2,sx+9,s_jelly_y[i]+2,1);OLED_GFX_DrawLine(sx+1,s_jelly_y[i]+4,sx+8,s_jelly_y[i]+4,1);OLED_GFX_DrawLine(sx+2,s_jelly_y[i]+5,sx+1,s_jelly_y[i]+9,1);OLED_GFX_DrawLine(sx+5,s_jelly_y[i]+5,sx+5,s_jelly_y[i]+9,1);OLED_GFX_DrawLine(sx+8,s_jelly_y[i]+5,sx+9,s_jelly_y[i]+9,1);}}
 } else {
  /* 城堡关卡的砖墙背景；WORLD 1-4 顶部只保留一层砖格，减少 HUD 上方的拥挤感。 */
  for(x=-(s_camera%16);x<128;x+=16){
   OLED_GFX_DrawRect(x,8,16,10,1);
   if(s_level!=4U && s_level!=8U)OLED_GFX_DrawRect(x-8,19,16,10,1);
  }
  OLED_GFX_DrawLine(0,54,127,54,1);
 }
 /* 藤蔓奖励区使用独立天空地图，不再叠画原地面关卡。 */
 if(s_sky_mode){
  Cloud(8-(s_camera%150),10);Cloud(82-(s_camera%150),7);Cloud(48-(s_camera%150),35);
  /* 天空奖励区：三层浮岛加下方安全地面，世界坐标随镜头移动。 */
  OLED_GFX_FillRect((int16_t)(s_vine_x+42-s_camera),43,34,3,1);
  OLED_GFX_FillRect((int16_t)(s_vine_x+96-s_camera),34,34,3,1);
  OLED_GFX_FillRect((int16_t)(s_vine_x+151-s_camera),41,34,3,1);
  DrawLift((int16_t)(s_sky_lift_x-s_camera),SKY_LIFT_Y);
  OLED_GFX_FillRect(0,56,128,8,1);
  for(i=0;i<SKY_COIN_COUNT;i++)if(!s_sky_coin_taken[i]){int16_t cx=(int16_t)(s_vine_x+35+i*12-s_camera);DrawCoin(cx,(int16_t)(i%4U==0U?29:(i%4U==1U?20:(i%4U==2U?36:25))));}
  /* 天空地图末尾的回程藤蔓。 */
  DrawVine((int16_t)(s_vine_x+340-s_camera));
  DrawMarioSpriteAt(MARIO_X,s_mario_y,1U);
  if(s_state==10U){OLED_GFX_FillRect(31,24,66,18,0U);OLED_GFX_DrawRect(31,24,66,18,1U);DrawTinyString(48,30,"PAUSED");}
  DrawMiniHud();
  return;
 }
 /* 地面缺口处不绘制地砖，让玩家能看见并掉入断崖。 */
 for(x=0;x<128;x+=8){
  int16_t wx=s_camera+x;
  uint8_t castle_pit=(uint8_t)(IsCastleLevel() && s_boss_bridge_broken &&
      wx+4>=GoalX()-170 && wx+4<GoalX()-55);
  if(!InCliff(wx+4) && !castle_pit){OLED_GFX_FillRect(x,56,8,8,1);OLED_GFX_DrawLine(x,59,x,63,0);}
 }
 for(i=0;i<ActiveBlockCount();i++)if(!s_block_broken[i] && !BlockMergedFollower(i)){sx=BlockX(i)-s_camera;if(sx>-20&&sx<128){Block(sx,BlockY(i),IsQuestionBlock(i),s_block_used[i],IsTenCoinBlock(i),s_coin_block_hits[i]);}}
 if(!s_sky_mode)for(i=0;i<LevelCoinCount();i++)if(!s_coin_taken[i]){int16_t cx=CoinX(i)-s_camera;if(cx>-8&&cx<128)DrawCoin(cx,CoinY(i));}
 if(s_coin_pop_active){sx=s_coin_pop_x-s_camera;if(sx>-8&&sx<128)DrawCoin(sx,s_coin_pop_y);}
 if(s_level==3U)for(i=0;i<CLOUD_COUNT;i++)if(s_cloud_alive[i]){sx=s_cloud_x[i]-s_camera;if(sx>-22&&sx<128)DrawSpikeCloud(sx,(int16_t)(10+i*4));if(s_cloud_spike_active[i]){sx=s_cloud_spike_x[i]-s_camera;if(sx>-5&&sx<128)OLED_GFX_FillRect(sx,s_cloud_spike_y[i],4,5,1);}}
 if(s_level==3U)for(i=0;i<HEDGEHOG_COUNT;i++)if(s_hedgehog_alive[i]){sx=s_hedgehog_x[i]-s_camera;if(sx>-14&&sx<128)DrawHedgehog(sx);}
 if(s_level==3U){DrawMushroomPlatform((int16_t)(250-s_camera),34,30);DrawMushroomPlatform((int16_t)(580-s_camera),27,34);DrawMushroomPlatform((int16_t)(920-s_camera),36,30);DrawMushroomPlatform((int16_t)(1200-s_camera),29,36);}
 if(s_level==7U){DrawBridge(0,128U);}
 /* 城堡桥头设有拉杆；碰到后桥面断开，库巴坠入下方岩浆池。 */
 if(IsCastleLevel()){
  int16_t bridge_x=(int16_t)(BossBridgeLeft()-s_camera);
  /* 1-4/2-4 是桥上 Boss 战，不在旗杆终点额外绘制城堡。 */
  if(!s_boss_bridge_broken){DrawBridge(bridge_x,BossBridgeWidth());DrawCastleLever((int16_t)(GoalX()-44-s_camera));}
  else DrawLavaPit((int16_t)(GoalX()-170-s_camera),115);
 }
 /* WORLD 1-4 的三处小型岩浆池及喷发动画。 */
 if(s_level==4U){
  for(i=0;i<LAVA_COUNT;i++){int16_t lx=s_lava_x[i]-s_camera;if(lx>-18&&lx<128){OLED_GFX_FillRect(lx,56,16,8,0);OLED_GFX_DrawLine(lx,56,lx+15,56,1);OLED_GFX_DrawPixel(lx+3,59,1);OLED_GFX_DrawPixel(lx+11,61,1);if((s_lava_phase[i]/20U)%4U==1U || (s_lava_phase[i]/20U)%4U==2U){OLED_GFX_DrawLine(lx+4,55,lx+2,47,1);OLED_GFX_DrawLine(lx+8,55,lx+8,43,1);OLED_GFX_DrawLine(lx+12,55,lx+14,48,1);}}}
 }
 for(i=0;i<PipeActiveCount();i++){
  if(s_state==24U && s_level==2U && i==0U)continue;
  sx=PipeX(i)-s_camera;if(sx>-20&&sx<128)Pipe(sx,PipeTop(i));
 }
 if(IsHorizontalGoalPipeLevel()){
  sx=(int16_t)(GoalPipeX()-s_camera);
  if(sx>-36&&sx<128)DrawHorizontalGoalPipe(sx);
 }
 if(s_level!=7U)for(i=0;i<ENEMY_COUNT;i++)if(s_enemy_alive[i]){sx=s_enemy_x[i]-s_camera;if(sx>-12&&sx<128)Goomba(sx,s_enemy_y[i]);}
 for(i=0;i<TURTLE_COUNT;i++)if(s_turtle_alive[i]){sx=s_turtle_x[i]-s_camera;if(sx>-14&&sx<128)Koopa(sx,s_turtle_y[i],s_turtle_state[i]);}
 if(s_level==5U){
  for(i=0;i<BULLET_BILL_COUNT;i++){sx=(int16_t)(s_bill_cannon_x[i]-s_camera);if(sx>-20&&sx<128)DrawCannon(sx);if(s_bill_active[i]){sx=(int16_t)(s_bill_x[i]-s_camera);if(sx>-14&&sx<128)DrawBulletBill(sx,s_bill_y[i]);}}
  sx=(int16_t)(SpringX()-s_camera);if(sx>-14&&sx<128)DrawSpring(sx);
  for(i=0U;i<HAMMER_BRO_COUNT;i++)if(s_hammer_bro_alive[i]){sx=(int16_t)(s_hammer_bro_start[i]-s_camera);if(sx>-18&&sx<128)DrawHammerBro(sx,s_hammer_bro_y[i]);}
 }
 if(s_level==5U || IsCastleLevel()){
  for(i=0U;i<HAMMER_COUNT;i++)if(s_hammer_active[i]){sx=(int16_t)(s_hammer_x[i]-s_camera);if(sx>-8&&sx<128)DrawHammer(sx,s_hammer_y[i]);}
 }
 if(s_level==7U){
  for(i=0U;i<FISH_COUNT;i++)if(s_fish_alive[i] && s_fish_y[i]<60){
   sx=(int16_t)(s_fish_x[i]-s_camera);
   if(sx>-14&&sx<128)FlyingFish(sx,s_fish_y[i],(uint8_t)(s_fish_dir[i]<0));
  }
 }
 for(i=0;i<ITEM_COUNT;i++)if(s_item_available[i]){sx=s_item_x[i]-s_camera;if(sx>-12&&sx<128){if(s_item_is_1up)LifeMushroom(sx,s_item_y);else Mushroom(sx,s_item_y);}}
 /* Piranha plants emerge periodically from pipes in 1-1/1-3. */
 for(i=0;i<PIPE_COUNT;i++)if(!s_plant_dead[i] && s_level!=2U && s_level!=4U && s_level!=6U && s_level!=7U && s_level!=8U && !IsCastleLevel()){
  uint8_t t=(uint8_t)(s_plant_phase[i]%100U);
  if(t>=10U && t<68U){sx=PipeX(i)-s_camera;if(sx>-18&&sx<128)Piranha(sx+1,PiranhaY(i),(uint8_t)(((s_frame/2U+i)&1U)==0U));}
 }
 if(s_level==2U){for(i=0;i<LIFT_COUNT;i++)DrawLift((int16_t)(s_lift_x[i]-s_camera),s_lift_y[i]);}
 if(s_vine_active){sx=s_vine_x-s_camera;if(sx>-5&&sx<128)DrawVine(sx);}
 if(s_star_active){sx=s_star_x-s_camera;if(sx>-10&&sx<128)DrawPowerStar(sx,s_star_y);}
  if(s_poison_active){sx=s_poison_x-s_camera;if(sx>-12&&sx<128)PoisonMushroom(sx,s_poison_y);}
 if(s_block_flower_active){sx=s_block_flower_x-s_camera;if(sx>-12&&sx<128)FireFlower(sx,s_block_flower_y);}
 for(i=0;i<2;i++)if(s_fly_turtle_alive[i]){sx=s_fly_turtle_x[i]-s_camera;if(sx>-18&&sx<128)FlyingKoopa(sx,s_fly_turtle_y[i]);}
 if(IsCastleLevel() && !s_boss_defeated && s_boss_y<64){
  sx=(int16_t)(s_boss_x-s_camera);
  if(sx>-20&&sx<128){if(s_boss_falling)DrawBowserFalling(sx,s_boss_y,s_boss_death_frame);else DrawBowser(sx,s_boss_y,s_boss_move_phase);}
  if(s_boss_falling && s_boss_y>=53 && sx>-8 && sx<128){
   OLED_GFX_DrawLine(sx+2,58,sx,54+(s_boss_death_frame&1U),1);
   OLED_GFX_DrawLine(sx+8,57,sx+10,52,1);
   OLED_GFX_DrawPixel(sx+15,58,1);
  }
 }
 for(i=0U;i<BOSS_FIREBALL_COUNT;i++)if(s_boss_fire_active[i]){
  sx=(int16_t)(s_boss_fire_x[i]-s_camera);
  if(sx>-7&&sx<128){
   OLED_GFX_FillRect(sx,s_boss_fire_y[i]+1,6,4,1U);
   OLED_GFX_DrawPixel(sx+2,s_boss_fire_y[i],1U);
   OLED_GFX_DrawPixel(sx+4,s_boss_fire_y[i]+5,1U);
  }
 }
 if(s_level==8U){
  static const int16_t fb_x[FIREBAR_COUNT]={620,1160};
  static const int16_t fb_y[FIREBAR_COUNT]={27,34};
  for(i=0U;i<FIREBAR_COUNT;i++){sx=(int16_t)(fb_x[i]-s_camera);if(sx>-28&&sx<128)DrawFirebar(sx,fb_y[i],s_firebar_phase[i],(uint8_t)(i==0U?2U:3U));}
  for(i=0U;i<PODOBOO_COUNT;i++){
   sx=(int16_t)(s_podoboo_x[i]-s_camera);
   if(sx>-22&&sx<128){DrawLavaPit((int16_t)(sx-4),16U);if(s_podoboo_active[i])DrawPodoboo(sx,s_podoboo_y[i]);}
  }
 }
 if(s_sky_mode){
  OLED_GFX_FillRect(12,28,28,3,1); OLED_GFX_FillRect(58,22,30,3,1); OLED_GFX_FillRect(99,30,24,3,1);
  OLED_GFX_DrawPixel(25,20,1);OLED_GFX_DrawPixel(34,18,1);OLED_GFX_DrawPixel(70,14,1);OLED_GFX_DrawPixel(79,14,1);
 }
 /* 逐一绘制当前活动的火球，槽位数量固定为二。 */
 for(i=0;i<FIREBALL_COUNT;i++)if(s_fireball_active[i]){sx=s_fireball_x[i]-s_camera;if(sx>=0&&sx<128){OLED_GFX_FillRect(sx,s_fireball_y[i],4,4,1);OLED_GFX_DrawPixel(sx+1,s_fireball_y[i]-1,1);}}
 for(i=0U;i<StaircaseCount();i++){sx=(int16_t)(StaircaseX(i)-s_camera);if(sx>-40&&sx<128)DrawStairs(sx,i);}
 if(IsCastleLevel()){
  /* 击败库巴后公主才出现；Boss 关不再额外绘制城堡或普通终点旗杆。 */
  if(s_boss_defeated){sx=PrincessX()-s_camera;if(sx>-18&&sx<128)DrawPrincess(sx,37);}
 }else if(!IsHorizontalGoalPipeLevel()){
  sx=GoalX()-s_camera;if(sx>-60&&sx<128)CastleFlag(sx);
 }
 /* 统一透明像素绘制；1-1 的门洞直接使用城堡原有黑色入口。 */
 if(!(s_state==3U && IsHorizontalGoalPipeLevel()))DrawMarioSpriteAt(s_mario_draw_x,s_mario_y,0U);
 if(s_state==25U)DrawMarioAxePressPose(s_mario_draw_x,s_mario_y,s_state_ms);
 if(s_state==20U){
  int16_t door_x=(int16_t)(GoalX()-s_camera+24+CastleWidth()/2-4);
  if(door_x<128 && door_x+8>0){
   uint8_t cover=(uint8_t)((s_state_ms<8U)?s_state_ms:8U);
   OLED_GFX_FillRect(door_x,GROUND_TOP-12,cover,12,0U);
  }
 }
 if(s_state==16U){
  sx=(int16_t)(GoalPipeX()-s_camera);
  /* 横向终点管入口黑洞压在精灵前方。 */
  OLED_GFX_FillRect(sx+3,40,7,15,0U);
  OLED_GFX_DrawRect(sx+3,40,7,15,1U);
 }else if(s_state==24U){
  /* 1-1 到 1-2 的过场管：绘制在 1-2 起点管附近，不引用地图末端坐标。 */
  sx=(int16_t)(pipe_x_12[0]-s_camera);
  DrawHorizontalGoalPipe(sx);
 }
 if(s_vine_climbing){OLED_GFX_DrawLine(s_mario_draw_x+1,s_mario_y+5,s_mario_draw_x-2,s_mario_y+2+(s_frame&1U),1);OLED_GFX_DrawLine(s_mario_draw_x+8,s_mario_y+5,s_mario_draw_x+11,s_mario_y+2+((s_frame+1U)&1U),1);}
 if(s_state==4U){
  for(i=0;i<PipeActiveCount();i++){
   sx=PipeX(i)-s_camera;
   if(MARIO_X+MARIO_W>sx && MARIO_X<sx+17){
    OLED_GFX_FillRect(sx,PipeTop(i),17,5,1U);
    OLED_GFX_DrawRect(sx,PipeTop(i),17,5,1U);
    OLED_GFX_FillRect(sx+2,PipeTop(i)+4,13,56-PipeTop(i)-4,1U);
   }
  }
 }
 if(s_state==10U){OLED_GFX_FillRect(31,24,66,18,0U);OLED_GFX_DrawRect(31,24,66,18,1U);DrawTinyString(48,30,"PAUSED");}
 DrawMiniHud();
 /* 通关/选关提示直接画进同一帧缓冲，避免字符模式与图形模式轮流写屏。 */
 if(s_state==3U && s_level!=8U && !IsHorizontalGoalPipeLevel()){
  OLED_GFX_FillRect(25,25,78,16,0U);
  OLED_GFX_DrawRect(25,25,78,16,1U);
  DrawTinyString(40,30,"COURSE CLEAR");
 }else if(s_state==5U){
  OLED_GFX_FillRect(25,22,78,25,0U);
  OLED_GFX_DrawRect(25,22,78,25,1U);
  DrawTinyString(47,25,"SELECT");
  if(s_select_group==0U)DrawTinyString(53,33,s_level_select==0U?"1-3":"1-4");
  else DrawTinyString(53,33,s_level_select==0U?"2-3":"2-4");
  DrawTinyString(43,40,"PRESS PB1");
 }
 if(s_state==3U && (s_level==4U || s_level==8U))DrawClearFireworks();
}
/*
 * 当马里奥从下方顶砖时，检查砖块正上方是否站着 Goomba。
 * 砖块上方的怪物会被顶击震落并消灭；返回值用于选择对应音效。
 */
static uint8_t KillEnemyOnTopOfBlock(uint8_t block_index)
{
 uint8_t j,killed=0U;
 int16_t left=BlockX(block_index),top=BlockY(block_index);
 for(j=0;j<ENEMY_COUNT;j++)if(s_enemy_alive[j]){
  int16_t enemy_bottom=(int16_t)(s_enemy_y[j]+7);
  if(s_enemy_x[j]+11>left && s_enemy_x[j]<left+BlockWidth(block_index) &&
     enemy_bottom>=top-2 && enemy_bottom<=top+2){
   s_enemy_alive[j]=0U;killed=1U;
  }
 }
 return killed;
}

static void HitByEnemy(void)
{
 /* 普通受伤有短暂无敌窗口，避免同一次重叠在连续帧内重复扣血。 */
 if(s_state!=0 || s_invuln_ms>0U || s_pipe_invuln_ms>0U)return;
 if(s_fire_powered){
  s_fire_powered=0; s_powered=1;
  s_invuln_ms=1200U; s_velocity_y=-5; s_grounded=0; s_on_platform=0;
  StartGameSfx(powerdown_sfx,(uint8_t)(sizeof(powerdown_sfx)/sizeof(powerdown_sfx[0])));
  return;
 }
 if(s_powered){
  s_powered=0;
  s_invuln_ms=1200U; s_velocity_y=-5; s_grounded=0; s_on_platform=0;
  StartGameSfx(powerdown_sfx,(uint8_t)(sizeof(powerdown_sfx)/sizeof(powerdown_sfx[0])));
  return;
 }
 if(s_lives>0U)s_lives--;
 UpdateLivesHud();
 s_state=1; s_state_ms=0; s_velocity_y=-6; s_grounded=0; s_on_platform=0;
 s_music_restart_request=1U; /* 下一次主循环将背景音乐游标清零。 */
 StartGameSfx(death_sfx,(uint8_t)(sizeof(death_sfx)/sizeof(death_sfx[0])));
}
/* 发射火球：寻找空闲槽位，所以同一时刻最多存在两颗。 */
static void SpawnFireball(void)
{
 uint8_t i;
 if(!s_fire_powered || s_state!=0U)return;
 for(i=0;i<FIREBALL_COUNT;i++)if(!s_fireball_active[i]){
  s_fireball_active[i]=1U;
  s_fireball_x[i]=s_camera+MARIO_X+(s_direction?0:MARIO_W);
  s_fireball_y[i]=(int16_t)(s_mario_y+8);
  s_fireball_dir[i]=s_direction?-1:1;
  StartGameSfx(fire_sfx,(uint8_t)(sizeof(fire_sfx)/sizeof(fire_sfx[0])));
  break;
 }
}
/* 火球移动采用扫掠式实体检测，撞到水管、砖墙、阶梯或电梯侧面立即消失。 */
static uint8_t FireballHitsSolid(int16_t old_x,int16_t new_x,int16_t y)
{
 int16_t left=(old_x<new_x)?old_x:new_x;
 int16_t right=(old_x>new_x)?old_x:new_x;
 uint8_t i,st,row,col;
 right=(int16_t)(right+4);
 if(left<0 || right>WorldLength())return 1U;
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i),top=PipeTop(i);
  if(right>px && left<px+17 && y+4>top && y<GROUND_TOP)return 1U;
 }
 if(IsHorizontalGoalPipeLevel() && right>GoalPipeX() && left<GoalPipeX()+38 && y+4>30 && y<55)return 1U;
 for(i=0U;i<ActiveBlockCount();i++)if(!s_block_broken[i]){
  int16_t bx=BlockX(i),by=BlockY(i);
  if(right>bx && left<bx+BlockWidth(i) && y+4>by && y<by+9)return 1U;
 }
 for(st=0U;st<StaircaseCount();st++)for(row=0U;row<StaircaseRowsFor(st);row++)
  for(col=0U;col<(uint8_t)(StaircaseRowsFor(st)-row);col++){
   int16_t bx=StairBlockX(st,row,col);
   int16_t by=(int16_t)(GROUND_TOP-9-(int16_t)row*9);
   if(right>bx && left<bx+9 && y+4>by && y<by+9)return 1U;
  }
 if(s_level==2U)for(i=0U;i<LIFT_COUNT;i++){
  int16_t lx=s_lift_x[i],ly=s_lift_y[i];
  if(right>lx && left<lx+24 && y+4>ly && y<ly+5)return 1U;
 }
 return 0U;
}
/* 锤子命中水管、砖块或阶梯侧面时立即回收，采用扫掠检测避免高速穿墙。 */
static uint8_t HammerHitsSolid(int16_t old_x,int16_t new_x,int16_t y)
{
 int16_t left=(old_x<new_x)?old_x:new_x;
 int16_t right=(old_x>new_x)?old_x:new_x;
 uint8_t i;
 right=(int16_t)(right+6);
 if(left<0 || right>WorldLength())return 1U;
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i),top=PipeTop(i);
  if(right>px && left<px+17 && y+8>top && y<GROUND_TOP)return 1U;
 }
 for(i=0U;i<ActiveBlockCount();i++)if(!s_block_broken[i]){
  int16_t bx=BlockX(i),by=BlockY(i);
  if(right>bx && left<bx+BlockWidth(i) && y+8>by && y<by+9)return 1U;
 }
 return IntersectsStairBlock(left,y,(uint8_t)(right-left),8U);
}
/* 飞行乌龟检查整个身体是否会撞上水管、砖墙或阶梯；撞击后由移动器反向。 */
static uint8_t FlyingKoopaHitsSolid(int16_t x,int16_t y)
{
 uint8_t i;
 for(i=0U;i<PipeActiveCount();i++){
  int16_t px=PipeX(i),top=PipeTop(i);
  if(x+14>px && x<px+17 && y+12>top && y<GROUND_TOP)return 1U;
 }
 for(i=0U;i<ActiveBlockCount();i++)if(!s_block_broken[i]){
  int16_t bx=BlockX(i),by=BlockY(i);
  if(x+14>bx && x<bx+BlockWidth(i) && y+12>by && y<by+9)return 1U;
 }
 return IntersectsStairBlock(x,y,14U,12U);
}

static void TryEnterPipe(void)
{
 uint8_t i; int16_t sx,center,bottom;
 if(!s_down_latch || s_state!=0)return;
 center=MARIO_X+MARIO_W/2; bottom=s_mario_y+MARIO_H;
 if(s_sewer_mode){
  /* 地下场景最右侧的横向水管是返回地面的唯一出口。 */
  if((s_camera+center)>=SEWER_EXIT_X-22 && s_direction==0U){
   s_sewer_mode=0U;s_camera=s_sewer_return_camera;
   s_pipe_exit_target_y=s_sewer_return_y;
   /* 从进入下水道时记录的地面管道口下方开始，逐帧向上露出。 */
   s_mario_y=(int16_t)(s_pipe_exit_target_y+MARIO_H);
   s_velocity_y=0;s_grounded=0U;s_on_platform=0U;s_state=14U;s_state_ms=0U;
   s_down_latch=0U;
   StartGameSfx(pipe_enter_sfx,(uint8_t)(sizeof(pipe_enter_sfx)/sizeof(pipe_enter_sfx[0])));
  }
  s_down_latch=0U;
  return;
 }
 if(s_sky_mode && (s_camera+center>=s_vine_x+332) && (s_camera+center<=s_vine_x+350) && (s_grounded || s_on_platform)){
  s_vine_climbing=1U;s_vine_anim_tick=0U;s_state=11U;s_state_ms=0U;s_down_latch=0U;s_mario_y=8;s_velocity_y=0;
  StartGameSfx(vine_sfx,(uint8_t)(sizeof(vine_sfx)/sizeof(vine_sfx[0])));return;
 }
 if(!s_sky_mode && s_level==3U && s_vine_active && (s_camera+center>=s_vine_x-8) && (s_camera+center<=s_vine_x+8)){
  s_vine_climbing=1U;s_vine_anim_tick=0U;s_state=6U;s_state_ms=0;s_down_latch=0;StartGameSfx(vine_sfx,(uint8_t)(sizeof(vine_sfx)/sizeof(vine_sfx[0])));return;
 }
 /* 天空奖励地图只保留末端回程藤蔓；地面关卡管道在此场景不可见，
    因此不能让 PA7 误触发隐藏管道传送。 */
 /* If PA7 is pressed while aligned with a pipe, pipe entry takes priority.
    Otherwise Fire Mario uses the same button to throw a projectile. */
 if(!s_sky_mode && (s_grounded || s_on_platform)){
  for(i=0;i<PipeActiveCount();i++){
   sx=PipeX(i)-s_camera;
   if(center>=sx+2 && center<=sx+15 && bottom>=PipeTop(i)-2 && bottom<=PipeTop(i)+3){
    /* 多个关卡的第 2 根管道可进入独立下水道；每次重生前每关只允许一次。 */
    if(i==1U && (s_level==1U || s_level==2U || s_level==3U || s_level==5U || s_level==6U || s_level==7U)){
     uint8_t sewer_bit=(uint8_t)(1U<<(s_level-1U));
     if((s_sewer_used_mask & sewer_bit)!=0U){
      /* 已经游览过该关下水道：本次按键不进入，也不误发火球。 */
      s_down_latch=0U;
      return;
     }
    }
    s_state=4; s_state_ms=0; s_down_latch=0;
    s_pipe_entry_start_y=s_mario_y;
    s_pipe_dest_level=s_level;
    s_pipe_dest_x=PipeX(PipeExitIndex(i));
    s_pipe_dest_top=PipeTop(PipeExitIndex(i));
    s_sewer_enter_pending=0U;
    if(i==1U && (s_level==1U || s_level==2U || s_level==3U || s_level==5U || s_level==6U || s_level==7U)){
     /* 奖励房从配对的另一根地面管道返回，避免原管道进出同口。 */
     s_sewer_return_camera=(int16_t)(s_pipe_dest_x-(MARIO_X+MARIO_W/2-8));
     if(s_sewer_return_camera<0)s_sewer_return_camera=0;
     if(s_sewer_return_camera>WorldLength()-128)s_sewer_return_camera=(int16_t)(WorldLength()-128);
     s_sewer_return_y=(int16_t)(s_pipe_dest_top-MARIO_H);
     s_sewer_enter_pending=1U;
    }
    /* 只有明确指定的入口才跨关传送；普通管道在配对管口之间出入。 */
    if(s_level==1U && i==5U){
     s_pipe_dest_level=2U;
     s_pipe_dest_x=pipe_x_12[0];
     s_pipe_dest_top=pipe_top_12[0];
    }else if(s_level==5U && i==5U){
     s_pipe_dest_level=6U;
     s_pipe_dest_x=pipe_x_22[0];
     s_pipe_dest_top=pipe_top_22[0];
    }
    StartGameSfx(pipe_enter_sfx,(uint8_t)(sizeof(pipe_enter_sfx)/sizeof(pipe_enter_sfx[0])));
    return;
   }
  }
 }
 if(s_fire_powered)SpawnFireball();
 s_down_latch=0;
}

/* 主程序在背景音乐引擎启用后调用；为单声道蜂鸣器开启 BGM 优先策略。 */
void GameScene_SetBackgroundMusicActive(uint8_t active)
{
 s_background_music_active = (active != 0U) ? 1U : 0U;
}

/* 背景音乐优先级：无敌星 > 下水道 > 当前关卡主题。 */
uint8_t GameScene_GetMusicTheme(void)
{
 if(s_star_ms>0U)return (uint8_t)GAME_MUSIC_THEME_INVINCIBILITY;
 if(s_sewer_mode!=0U)return (uint8_t)GAME_MUSIC_THEME_UNDERGROUND;
 if(s_level==2U)return (uint8_t)GAME_MUSIC_THEME_UNDERGROUND;
 if(s_level==4U || s_level==8U)return (uint8_t)GAME_MUSIC_THEME_CASTLE;
 if(s_level==6U)return (uint8_t)GAME_MUSIC_THEME_UNDERWATER;
 return (uint8_t)GAME_MUSIC_THEME_GROUND;
}

void GameScene_Init(void)
{
 GPIO_InitTypeDef gpio;
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC,ENABLE);
 GPIO_StructInit(&gpio);gpio.GPIO_Pin=GPIO_Pin_1|GPIO_Pin_5|GPIO_Pin_7;gpio.GPIO_Mode=GPIO_Mode_IPU;gpio.GPIO_Speed=GPIO_Speed_2MHz;GPIO_Init(GPIOA,&gpio);
 /* PC13 为 OLED 手动恢复键：按键另一端接 GND，低电平有效。 */
 GPIO_StructInit(&gpio);gpio.GPIO_Pin=GPIO_Pin_13;gpio.GPIO_Mode=GPIO_Mode_IPU;gpio.GPIO_Speed=GPIO_Speed_2MHz;GPIO_Init(GPIOC,&gpio);
 s_pa1_last=1U;s_pa1_count=0U;s_pa5_last=1;s_pa5_count=0;s_pa7_last=1;s_pa7_count=0;
 s_pc13_last=1U;s_pc13_count=0U;s_jump_buffer_ms=0U;s_title_level=1U;s_sfx_active=0;s_sfx_is_jump=0U;s_music_restart_request=0;Key_Init();ResetLevel();s_state=9U;
 s_scene_dirty=1U;DrawScene();OLED_GFX_Refresh();s_scene_dirty=0U;UpdateLivesHud();
}
/* 每 10ms 调用一次：消抖 PA1/PA5/PA7，并处理 PB1 启动/跳跃事件。 */
void GameScene_KeyScan10ms(void)
{
 uint8_t sample, jump_event;
 jump_event=Key_GetNum();
 /* 正常游戏中的 PB1 提供 120ms 输入缓冲：即使按下瞬间尚未落地，
  * 只要短时间内落地/接触平台，仍会执行跳跃，减少“按了没跳”的感觉。 */
 if(jump_event && s_state==0U) s_jump_buffer_ms=120U;
 if(s_jump_buffer_ms>0U && s_state==0U && (IsUnderwaterLevel() || s_grounded || s_on_platform))
 {
  s_jump_buffer_ms=0U;
  s_velocity_y=(IsUnderwaterLevel()?-5:-8);s_grounded=0U;s_on_platform=0U;
  if(IsUnderwaterLevel())StartGameSfx(swim_sfx,(uint8_t)(sizeof(swim_sfx)/sizeof(swim_sfx[0])));
  else if(!s_powered && !s_fire_powered)StartGameSfx(small_jump_sfx,(uint8_t)(sizeof(small_jump_sfx)/sizeof(small_jump_sfx[0])));
  else StartGameSfx(jump_sfx,(uint8_t)(sizeof(jump_sfx)/sizeof(jump_sfx[0])));
 }
 /* PC13：检测到一次稳定按下时，重新初始化 SSD1306 并重发当前显存。 */
 sample=(uint8_t)GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13);
 if(sample==s_pc13_last){if(s_pc13_count<3U)s_pc13_count++;}else{s_pc13_last=sample;s_pc13_count=0U;}
 if(s_pc13_count==2U && sample==0U){
  OLED_RecoverDisplay();
  s_pc13_count=3U;
 }
 if(sample==1U && s_pc13_count>=2U)s_pc13_count=0U;

 /* PA1：选关界面切换关卡；正常游戏/暂停界面仍保持原有暂停功能。 */
 sample=(uint8_t)GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1);
 if(sample==s_pa1_last){if(s_pa1_count<3U)s_pa1_count++;}else{s_pa1_last=sample;s_pa1_count=0U;}
 if(s_pa1_count==2U && sample==0U){
  if(s_state==15U){ /* 胜利画面为终态；PA1 不得恢复游戏更新。 */ }
  else if(s_state==13U){
   s_title_level=(s_title_level>=8U)?1U:(uint8_t)(s_title_level+1U);
   s_scene_dirty=1U;
  }
  else if(s_state==0U){
   s_state=10U;s_scene_dirty=1U;
   /* 暂停提示音使用原版 pause 音效；背景音乐冻结，提示音结束后保持静音。 */
   s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_ms=0U;s_sfx_priority=0U;PWM_Stop();
   StartGameSfx(pause_sfx,(uint8_t)(sizeof(pause_sfx)/sizeof(pause_sfx[0])));
  }
  else if(s_state==10U){s_state=0U;s_scene_dirty=1U;StartGameSfx(pause_sfx,(uint8_t)(sizeof(pause_sfx)/sizeof(pause_sfx[0])));}
  s_pa1_count=3U;
 }
 if(sample==1U && s_pa1_count>=2U)s_pa1_count=0U;
 sample=(uint8_t)GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5);
 if(sample==s_pa5_last){if(s_pa5_count<3)s_pa5_count++;}else{s_pa5_last=sample;s_pa5_count=0;}
 /*
  * PA11 已取消，PA5 按场景复用：
  * - 正常游戏中（s_state==0）：切换马里奥朝向，0=向右，1=向左；
  * - 通关后的分支选关界面（s_state==5）：切换候选关卡；
  * - 死亡、传送和通关动画期间不响应，避免改变自动动作方向。
  */
 if(s_pa5_count==2 && sample==0){
  if(s_state==5U) s_level_select^=1U;
  else if(s_state==0U) s_direction^=1U;
  s_pa5_count=3;
 }
 if(sample==1 && s_pa5_count>=2)s_pa5_count=0;
 sample=(uint8_t)GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7);
 if(sample==s_pa7_last){if(s_pa7_count<3)s_pa7_count++;}else{s_pa7_last=sample;s_pa7_count=0;}
 /* PA7 是动作键：对准管道/入口藤条/天空回程藤条时交互，否则火焰形态下发射火球。 */
 if(s_pa7_count==2 && sample==0){if(s_state==0U)s_down_latch=1;s_pa7_count=3;}
 if(sample==1 && s_pa7_count>=2)s_pa7_count=0;
 if(jump_event && s_state==9U){s_state=13U;s_scene_dirty=1U;return;}
 if(jump_event && s_state==13U){
  /* 确认启动界面选择的关卡；重建地图后恢复正常游戏状态。 */
  s_level=s_title_level;
  ResetLevel();BeginLevelIntro();DrawScene();OLED_GFX_Refresh();UpdateLivesHud();return;
 }
 if(jump_event && s_state==5U){
  uint8_t kp=s_powered,kf=s_fire_powered;
  s_level=(s_select_group==0U)?(uint8_t)(s_level_select==0U?3U:4U):(uint8_t)(s_level_select==0U?7U:8U);
  ResetLevel();s_powered=kp;s_fire_powered=kf;BeginLevelIntro();
  DrawScene();OLED_GFX_Refresh();UpdateLivesHud();return;
 }
 if(jump_event && s_state==15U){
  s_level=1U;s_title_level=1U;s_lives=3U;s_coin_count=0U;
  s_powered=0U;s_fire_powered=0U;
  s_checkpoint_x=0;s_checkpoint_level=1U;s_sewer_used_mask=0U;
  s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_priority=0U;PWM_Stop();ResetLevel();BeginLevelIntro();s_scene_dirty=1U;
  DrawScene();OLED_GFX_Refresh();UpdateLivesHud();return;
 }
}
/* 10ms 时基任务：无敌计时、音效播放和状态动画/关卡切换。 */
void GameScene_Task10ms(void)
{
 if(s_jump_buffer_ms>0U){if(s_jump_buffer_ms>=10U)s_jump_buffer_ms-=10U;else s_jump_buffer_ms=0U;}
 if(s_invuln_ms>0U){if(s_invuln_ms>=10U)s_invuln_ms-=10U;else s_invuln_ms=0U;}
 if(s_pipe_invuln_ms>0U && s_state!=17U){if(s_pipe_invuln_ms>=10U)s_pipe_invuln_ms-=10U;else s_pipe_invuln_ms=0U;}
  if(s_star_ms>0U){if(s_star_ms>=10U)s_star_ms-=10U;else s_star_ms=0U;}
 /* 关卡标题卡计时：100 次 10ms = 1 秒；标题期间按键不能暂停或触发跳跃。 */
 if(s_state==17U){
  if(++s_state_ms>=100U){
   s_state=0U;s_state_ms=0U;s_scene_dirty=1U;
   if(s_intro_exit_sfx_pending){
    s_intro_exit_sfx_pending=0U;s_pipe_invuln_ms=500U;
    StartGameSfx(pipe_exit_sfx,(uint8_t)(sizeof(pipe_exit_sfx)/sizeof(pipe_exit_sfx[0])));
   }
  }
  return;
 }
 if(s_state==25U){
  /* 120ms 按斧动作结束后才开始桥梁镜头移动。 */
  if(++s_state_ms>=12U){s_state=21U;s_state_ms=0U;}
  return;
 }
 /* 死亡摘要界面必须完全静音：立即中止残留音效，且不推进音效序列。 */
 if(s_state==8U){
  if(s_sfx_active){s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_ms=0U;}
  PWM_Stop();
 }
 else if(s_sfx_active && ++s_sfx_ms>=s_sfx[s_sfx_index].ticks){
  s_sfx_ms=0;s_sfx_index++;
  if(s_sfx_index>=s_sfx_len){s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_priority=0U;PWM_Stop();}
  else if(s_sfx[s_sfx_index].hz)PWM_SetFrequency(s_sfx[s_sfx_index].hz);else PWM_Stop();
 }
 if(s_state==8U && ++s_state_ms>=100U){
  /* 死亡摘要界面保持 1 秒后才重生；仅显示关卡和剩余 UP。 */
  s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_priority=0U;PWM_Stop();
  if(s_lives==0U){s_lives=3U;s_checkpoint_x=0;s_checkpoint_level=s_level;s_sewer_used_mask=0U;ResetLevel();StartGameSfx(gameover_sfx,(uint8_t)(sizeof(gameover_sfx)/sizeof(gameover_sfx[0])));}
  else {
   /* 死亡摘要结束、真正重生时重新开放本轮已使用过的所有下水道。 */
   s_sewer_used_mask=0U;
   s_camera=s_checkpoint_x;s_mario_y=(s_level==7U)?(int16_t)(46-MARIO_H):(int16_t)(GROUND_TOP-MARIO_H);s_velocity_y=0;
   s_grounded=1U;s_on_platform=(s_level==7U)?1U:0U;s_state=0U;s_state_ms=0U;s_invuln_ms=1500U;s_pipe_invuln_ms=0U;
   {uint8_t k;for(k=0;k<FIREBALL_COUNT;k++)s_fireball_active[k]=0U;}
   s_vine_climbing=0U;s_sky_mode=0U;
  }
  UpdateLivesHud();
 }
 else if(s_state==3 && ++s_state_ms==180U && (s_level==4U || s_level==8U)){
  /* 城堡烟花在通关主旋律之后追加短促烟花音效，不与高优先级主旋律抢占。 */
  if(!s_sfx_active)StartGameSfx(firework_sfx,(uint8_t)(sizeof(firework_sfx)/sizeof(firework_sfx[0])));
 }
 else if(s_state==3 && s_state_ms>=520U){
  s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_priority=0U;PWM_Stop();
  if(s_level==1U){
   uint8_t kp=s_powered,kf=s_fire_powered;
   s_level=2U;ResetLevel();s_powered=kp;s_fire_powered=kf;
   /* 过场管道使用 1-2 起点附近的入口；不能把镜头留在 1-2 的地图末端。 */
   s_camera=(int16_t)(pipe_x_12[0]-90);
   if(s_camera<0)s_camera=0;
   if(s_camera>WorldLength()-128)s_camera=(int16_t)(WorldLength()-128);
   s_mario_draw_x=MARIO_X;s_mario_y=(int16_t)(GROUND_TOP-MARIO_H);
   s_velocity_y=0;s_grounded=1U;s_on_platform=0U;
   s_state=24U;s_state_ms=0U;s_intro_exit_sfx_pending=0U;
   StartGameSfx(pipe_enter_sfx,(uint8_t)(sizeof(pipe_enter_sfx)/sizeof(pipe_enter_sfx[0])));
   DrawScene();OLED_GFX_Refresh();UpdateLivesHud();
  }
  else if(s_level==5U){
   uint8_t kp=s_powered,kf=s_fire_powered;s_level=6U;ResetLevel();s_powered=kp;s_fire_powered=kf;BeginLevelIntro();
   DrawScene();OLED_GFX_Refresh();UpdateLivesHud();
  }
  else if(s_level==2U || s_level==6U){
   s_state=5U;s_level_select=0U;s_select_group=(s_level==2U)?0U:1U;
   DrawScene();OLED_GFX_Refresh();UpdateLivesHud();
  }
  else if(s_level==3U || s_level==7U){
   uint8_t kp=s_powered,kf=s_fire_powered;s_level=(s_level==3U)?4U:8U;ResetLevel();s_powered=kp;s_fire_powered=kf;BeginLevelIntro();
   DrawScene();OLED_GFX_Refresh();UpdateLivesHud();
  }
  else if(s_level==4U){
   uint8_t kp=s_powered,kf=s_fire_powered;s_level=5U;ResetLevel();s_powered=kp;s_fire_powered=kf;BeginLevelIntro();
   DrawScene();OLED_GFX_Refresh();UpdateLivesHud();
  }
  else if(s_level==8U){
   s_state=15U;s_state_ms=0U;s_scene_dirty=1U;s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_priority=0U;PWM_Stop();
  }
  else {s_level=1U;ResetLevel();BeginLevelIntro();DrawScene();OLED_GFX_Refresh();UpdateLivesHud();}
 }
 else if(s_state==16U){
  /* 横向终点管道入口动画：马里奥沿水平方向逐步进入管口。 */
  if((s_state_ms&1U)==0U && s_mario_draw_x<GoalPipeX()-s_camera+21)s_mario_draw_x++;
  if(++s_state_ms>=90U || s_mario_draw_x>=GoalPipeX()-s_camera+21){
   s_state=3U;s_state_ms=0U;
   StartGameSfx(clear_sfx,(uint8_t)(sizeof(clear_sfx)/sizeof(clear_sfx[0])));
  }
 }
 else if(s_state==24U){
  /* WORLD 1-1 通关后：马里奥先横向进入相邻水管，再显示 WORLD 1-2 标题卡。 */
  {
   int16_t pipe_screen=(int16_t)(pipe_x_12[0]-s_camera);
   int16_t target_x=(int16_t)(pipe_screen+21);
   if(s_mario_draw_x<target_x)s_mario_draw_x++;
   if(++s_state_ms>=90U || s_mario_draw_x>=target_x){
    /* 标题卡遮住重定位过程；1-2 真正开始时马里奥与镜头均回到关卡出生点。 */
    s_camera=0;s_mario_draw_x=MARIO_X;s_mario_y=(int16_t)(GROUND_TOP-MARIO_H);
    s_velocity_y=0;s_grounded=1U;s_on_platform=0U;
    s_state=17U;s_state_ms=0U;s_intro_exit_sfx_pending=1U;s_scene_dirty=1U;
   }
  }
 }
 else if(s_state==11U){
  /* 从天空回程藤蔓缓慢向下攀爬，抵达地面后回到 1-3 原路线。 */
  if(++s_vine_anim_tick>=4U){s_vine_anim_tick=0U;if(s_mario_y<GROUND_TOP-MARIO_H)s_mario_y++;}
  if(++s_state_ms>=180U){s_state=0U;s_vine_climbing=0U;s_sky_mode=0U;s_sky_timer=0U;s_mario_y=GROUND_TOP-MARIO_H;s_velocity_y=0;s_grounded=1U;s_on_platform=0U;s_camera=(int16_t)(s_vine_x+340-60);if(s_camera>WorldLength()-128)s_camera=WorldLength()-128;if(s_camera<0)s_camera=0;s_state_ms=0U;}
 }
 else if(s_state==4U && s_state_ms<75U){
  /* 进入水管：每 4 个 10ms tick 下沉 1 像素，最多下沉 13 像素。 */
  s_state_ms++;
  if((s_state_ms%4U)==0U && s_mario_y<s_pipe_entry_start_y+13)
   s_mario_y++;
 }
 else if(s_state==6U){
  /* 攀藤动画：每 4 个 10ms tick 上移 1 像素，身体交替摆臂。 */
  if(++s_vine_anim_tick>=4U){s_vine_anim_tick=0U;if(s_mario_y>8)s_mario_y--;}
  if(++s_state_ms>=180U){uint8_t k;s_state=0U;s_vine_climbing=0U;s_sky_mode=1U;s_sky_timer=0;s_mario_y=42;s_velocity_y=0;s_grounded=1U;s_on_platform=0U;s_camera=s_vine_x-50;if(s_camera<0)s_camera=0;s_sky_lift_x=(int16_t)(s_vine_x+108);s_sky_lift_dir=1;s_sky_lift_delta=0;for(k=0;k<SKY_COIN_COUNT;k++)s_sky_coin_taken[k]=0U;s_state_ms=0;}
 }
 else if(s_state==14U){
  /* 出管动画：每 4 个 10ms tick 向上露出 1 像素，约 0.56 秒完成。 */
  s_state_ms++;
  if((s_state_ms%4U)==0U && s_mario_y>s_pipe_exit_target_y)s_mario_y--;
  if(s_mario_y<=s_pipe_exit_target_y){
   s_mario_y=s_pipe_exit_target_y;s_velocity_y=0;s_grounded=1U;s_on_platform=1U;
   s_state=0U;s_state_ms=0U;s_down_latch=0U;
   s_pipe_invuln_ms=500U; /* 出管保护只阻止伤害/碰撞击杀，不附带无敌星能力。 */
   if(s_pipe_intro_pending){
    s_pipe_intro_pending=0U;BeginLevelIntro();s_intro_exit_sfx_pending=1U;
   }else StartGameSfx(pipe_exit_sfx,(uint8_t)(sizeof(pipe_exit_sfx)/sizeof(pipe_exit_sfx[0])));
  }
 }
 else if(s_state==4 && ++s_state_ms>=75){
  if(s_sewer_enter_pending){
   uint8_t k;
   if(s_level>=1U && s_level<=8U)s_sewer_used_mask|=(uint8_t)(1U<<(s_level-1U));
   s_sewer_enter_pending=0U;s_sewer_mode=1U;s_camera=0;s_mario_y=GROUND_TOP-MARIO_H;
   s_velocity_y=0;s_grounded=1U;s_on_platform=0U;s_state=0U;s_state_ms=0U;s_direction=0U;
   for(k=0;k<SEWER_COIN_COUNT;k++)s_sewer_coin_taken[k]=0U;
   s_down_latch=0U;
   DrawScene();OLED_GFX_Refresh();return;
  }
  /*
   * 管道动画结束后，从目标管道正上方出现。
   * 若目标关卡与当前关卡不同，先切换关卡并重建该关卡数据；
   * 普通管道的目标关卡等于当前关卡，因此只在原管道附近出入。
   */
  if(s_pipe_dest_level!=0U && s_level!=s_pipe_dest_level){
   uint8_t keep_direction=s_direction,keep_powered=s_powered,keep_fire=s_fire_powered;
   uint8_t destination_level=s_pipe_dest_level,destination_top=s_pipe_dest_top;
   int16_t destination_x=s_pipe_dest_x;
   s_level=destination_level;
   ResetLevel(); /* 载入目标关卡自己的敌人、砖块和道具。 */
   /* ResetLevel 会清空临时管道变量，因此先备份再恢复传送目标坐标。 */
   s_pipe_dest_x=destination_x;s_pipe_dest_top=destination_top;s_pipe_dest_level=destination_level;
   s_direction=keep_direction; s_powered=keep_powered; s_fire_powered=keep_fire;
   s_pipe_intro_pending=1U;
  }
  s_camera=s_pipe_dest_x-(MARIO_X+MARIO_W/2-8);
  if(s_camera<0)s_camera=0;
  if(s_camera>WorldLength()-128)s_camera=WorldLength()-128;
  s_pipe_exit_target_y=(int16_t)(s_pipe_dest_top-MARIO_H);
  /* 先把角色放在管口下方，再进入独立出管动画；不会瞬间出现在管口上。 */
  s_mario_y=(int16_t)(s_pipe_exit_target_y+MARIO_H);
  s_velocity_y=0;s_grounded=0U;s_on_platform=0U;
  s_state=14U;s_state_ms=0U;s_down_latch=0U;
  DrawScene();OLED_GFX_Refresh();
  UpdateLivesHud();
 }
}
/* 地下奖励场景使用独立的短地图与简化物理，避免地面敌人/管道碰撞串入。 */
static void UpdateSewerScene(void)
{
 uint8_t i;
 int16_t old_bottom;
 s_frame^=1U;
 if(s_direction==0U){if(s_camera<SEWER_WORLD_LENGTH-128)s_camera+=2;}
 else {if(s_camera>0)s_camera-=2;}
 old_bottom=(int16_t)(s_mario_y+MARIO_H);
 s_velocity_y++;
 if(s_velocity_y>5)s_velocity_y=5;
 s_mario_y=(int16_t)(s_mario_y+s_velocity_y);
 if(s_velocity_y>=0 && s_mario_y+MARIO_H>=GROUND_TOP){
  s_mario_y=GROUND_TOP-MARIO_H;s_velocity_y=0;s_grounded=1U;s_on_platform=0U;
 }else s_grounded=0U;
 (void)old_bottom;
 for(i=0;i<SEWER_COIN_COUNT;i++)if(!s_sewer_coin_taken[i]){
  int16_t cx=(int16_t)(s_sewer_coin_x[i]-s_camera),cy=s_sewer_coin_y[i];
  if(MARIO_X+MARIO_W>cx && MARIO_X<cx+8 && s_mario_y+MARIO_H>cy && s_mario_y<cy+9){
   s_sewer_coin_taken[i]=1U;AwardCoin();
  }
 }
 TryEnterPipe();
 DrawScene();OLED_GFX_Refresh();
}

/* 游戏帧更新：物理、碰撞、敌人行为、摄像机推进和画面刷新。 */
void GameScene_Update(void)
{
 int16_t old_bottom,old_top,landing,old_camera;uint8_t platform,i;
 int16_t ex,ey,world_center;
 /* riding_lift: 0=未搭乘；1~6=正在搭乘对应的升降台。 */
 uint8_t riding_lift=0U;
 uint8_t riding_sky_lift=0U;
 uint8_t stomped_this_frame=0U;
 int16_t lift_old_y[LIFT_COUNT]={0,0,0,0,0,0};
 if(s_state==9U || s_state==10U || s_state==13U || s_state==15U || s_state==17U){
  /* 静态界面只在按键导致内容变化时刷新一次；暂停期间不再反复重写 OLED。 */
  if(s_scene_dirty){DrawScene();OLED_GFX_Refresh();s_scene_dirty=0U;}
  return;
 }
 if(s_state==16U){
  s_frame^=1U;
  DrawScene();OLED_GFX_Refresh();
  return;
 }
 if(s_state==14U){
  /* 出管动画只显示角色逐渐露出的过程，不推进重力、敌人或镜头。 */
  DrawScene();OLED_GFX_Refresh();s_scene_dirty=0U;
  return;
 }
 if(s_state==24U){
  /* 1-1 结束的横向入管动画：只刷新动画，不运行关卡物理和敌人逻辑。 */
  DrawScene();OLED_GFX_Refresh();s_scene_dirty=0U;
  return;
 }
 if(s_state==25U){
  /* 按斧动画期间锁住角色和世界，只更新动作帧。 */
  DrawScene();OLED_GFX_Refresh();s_scene_dirty=0U;
  return;
 }
 if(s_state==21U){
  /* 过场一：马里奥保持世界坐标不变，摄像机横移到桥中央。 */
  if(s_camera<s_boss_cine_target_camera){s_camera=(int16_t)(s_camera+3);if(s_camera>s_boss_cine_target_camera)s_camera=s_boss_cine_target_camera;}
  else if(s_camera>s_boss_cine_target_camera){s_camera=(int16_t)(s_camera-3);if(s_camera<s_boss_cine_target_camera)s_camera=s_boss_cine_target_camera;}
  s_mario_y=s_boss_cine_mario_y;
  s_mario_draw_x=(int16_t)(s_boss_cine_mario_world_x-s_camera);
  if(s_camera==s_boss_cine_target_camera){
   s_boss_bridge_broken=1U;
   if(!s_boss_defeated){BeginBossFall();s_state=22U;}
   else{s_boss_cine_timer=16U;s_state=23U;}
  }
  DrawScene();OLED_GFX_Refresh();return;
 }
 if(s_state==22U){
  /* 过场二：只推进库巴坠落动画，不处理马里奥物理或敌人。 */
  AdvanceBossFallFrame();s_mario_y=s_boss_cine_mario_y;
  s_mario_draw_x=(int16_t)(s_boss_cine_mario_world_x-s_camera);
  if(!s_boss_falling){s_boss_cine_timer=16U;s_state=23U;}
  DrawScene();OLED_GFX_Refresh();return;
 }
 if(s_state==23U){
  /* 过场三：短暂停留后镜头回到斧头位置，马里奥重新回到原屏幕位置。 */
  s_mario_y=s_boss_cine_mario_y;
  s_mario_draw_x=(int16_t)(s_boss_cine_mario_world_x-s_camera);
  if(s_boss_cine_timer>0U)s_boss_cine_timer--;
  else if(s_camera<s_boss_cine_return_camera){s_camera=(int16_t)(s_camera+3);if(s_camera>s_boss_cine_return_camera)s_camera=s_boss_cine_return_camera;}
  else if(s_camera>s_boss_cine_return_camera){s_camera=(int16_t)(s_camera-3);if(s_camera<s_boss_cine_return_camera)s_camera=s_boss_cine_return_camera;}
  else{s_state=0U;s_state_ms=0U;s_grounded=1U;s_on_platform=1U;s_velocity_y=0;s_mario_draw_x=MARIO_X;}
  DrawScene();OLED_GFX_Refresh();return;
 }
 if(s_sewer_mode && s_state==0U){UpdateSewerScene();return;}
 if(s_state==1U){
  /* 死亡动画：先向上弹起，再受重力拉回并坠出屏幕底部。 */
  s_mario_y=(int16_t)(s_mario_y+s_velocity_y);
  if(s_velocity_y<7)s_velocity_y++;
  if(s_mario_y>64){
   s_state=8U;s_state_ms=0U;s_velocity_y=0;
   /* 从死亡动画切入摘要画面的瞬间关闭蜂鸣器，确保整个 1 秒界面静音。 */
   s_sfx_active=0U;s_sfx_is_jump=0U;s_sfx_ms=0U;s_sfx_priority=0U;PWM_Stop();
  }
 } else if(s_state==12U){
  /* 普通关触碰旗杆后先沿旗杆下滑；旗帜同步下降，即使角色已接近地面也完整落到底。 */
  s_frame^=1U;
  if(s_mario_y<(GROUND_TOP-MARIO_H)){
   s_mario_y=(int16_t)(s_mario_y+2);
   if(s_mario_y>(GROUND_TOP-MARIO_H))s_mario_y=(GROUND_TOP-MARIO_H);
  }
  /* 马里奥和旗帜以相同的每帧位移下降；角色先落地时，旗帜继续降到底部。 */
  if(s_flag_pole_y<48){s_flag_pole_y=(int16_t)(s_flag_pole_y+2);if(s_flag_pole_y>48)s_flag_pole_y=48;}
  if(s_state_ms<255U)s_state_ms++;
  if(s_mario_y>=(GROUND_TOP-MARIO_H) && s_flag_pole_y>=48 && s_state_ms>=4U){
   s_mario_y=(GROUND_TOP-MARIO_H);
   s_velocity_y=0;
   s_grounded=1U;
   s_on_platform=0U;
   s_state=19U; /* 旗子已降至底部，马里奥在旗杆旁停留 1.5 秒。 */
   s_state_ms=0U;
  }
 } else if(s_state==19U){
  if(++s_state_ms>=30U){s_state=7U;s_state_ms=0U;}
 } else if(s_state==7U){
  /* 自动走向公主/城堡期间锁定地面高度，防止此前的跳跃速度造成浮空。 */
  s_mario_y=(int16_t)(GROUND_TOP-MARIO_H);s_velocity_y=0;
  s_grounded=1U;s_on_platform=0U;
  uint8_t target_x=68U;
  s_frame^=1U;
  if(IsCastleLevel()){
   int16_t princess_screen=(int16_t)(PrincessX()-s_camera-MARIO_W+1);
   if(princess_screen<40)princess_screen=40;
   if(princess_screen>116)princess_screen=116;
   target_x=(uint8_t)princess_screen;
  }else{
   int16_t castle_left=(int16_t)(GoalX()-s_camera+24);
   int16_t doorway=(int16_t)(castle_left+CastleWidth()/2-MARIO_W/2);
   if(doorway<40)doorway=40;
   if(doorway>116)doorway=116;
   target_x=(uint8_t)doorway;
  }
  if(s_mario_draw_x<target_x)s_mario_draw_x++;
  else if(s_mario_draw_x>target_x)s_mario_draw_x--;
  else{s_state=18U;s_state_ms=0U;}
 } else if(s_state==18U){
  /* 只有马里奥完全进入城堡后，城堡顶旗才开始升起。 */
  if(++s_state_ms>=28U){
   if(s_level==1U){s_state=20U;s_state_ms=0U;}
   else{
    s_state=3U;s_state_ms=0U;
    if(IsCastleLevel())StartGameSfx(princess_rescue_sfx,(uint8_t)(sizeof(princess_rescue_sfx)/sizeof(princess_rescue_sfx[0])));
    else StartGameSfx(clear_sfx,(uint8_t)(sizeof(clear_sfx)/sizeof(clear_sfx[0])));
   }
  }
 } else if(s_state==20U){
  /* 1-1：马里奥停在城堡门口，由城堡黑色门洞逐渐遮住；不生成额外水管。 */
  if(++s_state_ms>=28U){
   s_state=3U;s_state_ms=0U;
   StartGameSfx(clear_sfx,(uint8_t)(sizeof(clear_sfx)/sizeof(clear_sfx[0])));
  }
 } else if(s_state==0){
  s_frame^=1U;old_camera=s_camera;
  for(i=0;i<PIPE_COUNT;i++)s_plant_phase[i]++;
  if(s_level==8U){
   static const int16_t fb_x[FIREBAR_COUNT]={620,1160};
   static const int16_t fb_y[FIREBAR_COUNT]={27,34};
   if(++s_firebar_slow_tick>=3U)s_firebar_slow_tick=0U;
   for(i=0U;i<FIREBAR_COUNT;i++){
    uint8_t k,segments=(uint8_t)(i==0U?2U:3U);
    if(s_firebar_slow_tick==0U)s_firebar_phase[i]=(uint8_t)((s_firebar_phase[i]+(uint8_t)(s_firebar_dir[i]>0?1U:15U))&15U);
    ex=(int16_t)(fb_x[i]-s_camera);
    for(k=1U;k<=segments;k++){
     static const int8_t dx[16]={0,1,2,2,2,1,0,-1,-2,-2,-2,-1,0,1,2,1};
     static const int8_t dy[16]={-2,-2,-1,0,1,2,2,2,1,0,-1,-2,-2,-2,-1,0};
     int16_t hx=(int16_t)(ex+dx[s_firebar_phase[i]&15U]*3*k);
     int16_t hy=(int16_t)(fb_y[i]+dy[s_firebar_phase[i]&15U]*3*k);
     if(s_pipe_invuln_ms==0U && MARIO_X+MARIO_W>hx-1 && MARIO_X<hx+2 && s_mario_y+MARIO_H>hy-1 && s_mario_y<hy+2){
      if(s_star_ms==0U && s_invuln_ms==0U)HitByEnemy();
     }
    }
   }
   for(i=0U;i<PODOBOO_COUNT;i++){
    if(!s_podoboo_active[i]){
     if(s_podoboo_timer[i]<88U)s_podoboo_timer[i]++;
     else{s_podoboo_timer[i]=0U;s_podoboo_active[i]=1U;s_podoboo_y[i]=GROUND_TOP-8;s_podoboo_vy[i]=-7;}
    }else{
     s_podoboo_y[i]=(int16_t)(s_podoboo_y[i]+s_podoboo_vy[i]);
     if(s_podoboo_vy[i]<4)s_podoboo_vy[i]++;
     if(s_podoboo_y[i]>=GROUND_TOP-8){s_podoboo_y[i]=GROUND_TOP-8;s_podoboo_active[i]=0U;}
     ex=(int16_t)(s_podoboo_x[i]-s_camera);
     if(s_podoboo_active[i] && s_pipe_invuln_ms==0U && s_star_ms==0U && s_invuln_ms==0U && MARIO_X+MARIO_W>ex && MARIO_X<ex+10 && s_mario_y+MARIO_H>s_podoboo_y[i] && s_mario_y<s_podoboo_y[i]+9)HitByEnemy();
    }
   }
  }
  /* 自动记录两个阶段检查点：越过 1/3 和 2/3 关卡长度后更新。
     死亡时使用最后到达的检查点，因此总是在已通过路线中最近的位置重生。 */
  {
   int16_t checkpoint_one=(int16_t)(WorldLength()/3U);
   int16_t checkpoint_two=(int16_t)((WorldLength()*2U)/3U);
   if(s_camera>=checkpoint_one && s_checkpoint_x<checkpoint_one)s_checkpoint_x=checkpoint_one;
   if(s_camera>=checkpoint_two && s_checkpoint_x<checkpoint_two)s_checkpoint_x=checkpoint_two;
  }
  if(IsCastleLevel() && s_boss_falling)AdvanceBossFallFrame();
  else if(IsCastleLevel() && !s_boss_defeated){
   s_boss_move_phase=(uint8_t)((s_boss_move_phase+1U)&31U);
   /* 库巴沿 y=46 的桥面左右巡逻，活动范围完全落在桥面之内。 */
   s_boss_x=(int16_t)(s_boss_x+s_boss_walk_dir);
   if(s_boss_x>=s_boss_home_x+24)s_boss_walk_dir=-1;
   else if(s_boss_x<=s_boss_home_x-24)s_boss_walk_dir=1;
   /* 每隔一段时间从桥面起跳，受重力回落并准确落到桥面顶端。 */
   if(s_boss_y>=BossStandingY() && s_boss_jump_vy==0){
    if(++s_boss_jump_timer>=62U){s_boss_jump_timer=0U;s_boss_jump_vy=-6;}
   }
   if(s_boss_jump_vy!=0){
    s_boss_y=(int16_t)(s_boss_y+s_boss_jump_vy);
    if(s_boss_jump_vy<7)s_boss_jump_vy++;
    if(s_boss_y>=BossStandingY()){s_boss_y=BossStandingY();s_boss_jump_vy=0;}
   }
  }
  if(!s_sky_mode && s_level==3U)for(i=0;i<CLOUD_COUNT;i++)if(s_cloud_alive[i]){
   int16_t cloud_y=(int16_t)(10+i*4);
   int16_t next_cloud_x=(int16_t)(s_cloud_x[i]+(i==0U?-1:1));
   if(++s_cloud_timer[i]>=55U && !s_cloud_spike_active[i]){s_cloud_timer[i]=0;s_cloud_spike_active[i]=1;s_cloud_spike_x[i]=(int16_t)(s_cloud_x[i]+8);s_cloud_spike_y[i]=19;}
   if(s_cloud_spike_active[i]){s_cloud_spike_y[i]+=2;if(s_cloud_spike_y[i]>GROUND_TOP-5)s_cloud_spike_active[i]=0;}
   if(IntersectsStairBlock(next_cloud_x,cloud_y,20U,13U)){
    next_cloud_x=(int16_t)(s_cloud_x[i]+(i==0U?1:-1));
    if(IntersectsStairBlock(next_cloud_x,cloud_y,20U,13U))next_cloud_x=s_cloud_x[i];
   }
   s_cloud_x[i]=next_cloud_x;
   if(s_cloud_x[i]<s_camera-30){
    int16_t respawn=(int16_t)(s_camera+150+i*80);
    s_cloud_x[i]=SpawnOutsideStairs(respawn,cloud_y,20U,13U);
   }
  }
  /* 水下 2-2 的水母缓慢上下浮动；触碰会受伤，无敌星星可直接消灭。 */
  if(IsUnderwaterLevel())for(i=0;i<JELLY_COUNT;i++)if(s_jelly_alive[i]){
   s_jelly_y[i]+=s_jelly_dir[i];
   if(s_jelly_y[i]<18){s_jelly_y[i]=18;s_jelly_dir[i]=1;}
   if(s_jelly_y[i]>43){s_jelly_y[i]=43;s_jelly_dir[i]=-1;}
   s_jelly_x[i]+=(i&1U)?-1:1;
   if(s_jelly_x[i]<s_camera-15)s_jelly_x[i]=(int16_t)(s_camera+145+i*28);
   ex=s_jelly_x[i]-s_camera;
   if(MARIO_X+MARIO_W>ex && MARIO_X<ex+10 && s_mario_y+MARIO_H>s_jelly_y[i] && s_mario_y<s_jelly_y[i]+10){if(s_star_ms>0U)s_jelly_alive[i]=0U;else HitByEnemy();}
  }
  /* 岩浆喷发按相位循环：先蓄势，再向上喷出，最后回落。 */
  if(s_level==4U)for(i=0;i<LAVA_COUNT;i++)s_lava_phase[i]=(uint8_t)((s_lava_phase[i]+1U)%80U);
  if(s_level==4U)for(i=0;i<LAVA_COUNT;i++){
   uint8_t phase=(uint8_t)(s_lava_phase[i]/20U);
   if(phase==1U || phase==2U){int16_t lx=s_lava_x[i]-s_camera;int16_t top=(phase==1U)?43:35;if(MARIO_X+MARIO_W>lx && MARIO_X<lx+16 && s_mario_y+MARIO_H>top && s_mario_y<56){if(s_star_ms==0U)HitByEnemy();}}
  }
  if(s_level==2U){
   /*
    * 先用上一帧电梯高度判断马里奥是否正站在电梯上，再更新电梯位置。
    * 旧逻辑只在物理结算结束后修正 Y 坐标：电梯向上移动时，落地检测
    * 会把马里奥判定为“没有落在平台上”，下一帧便会穿过/掉下电梯。
    * 这里在重力结算前按电梯位移同步搬运角色，并在本帧跳过重力。
    */
   for(i=0;i<LIFT_COUNT;i++)lift_old_y[i]=s_lift_y[i];
   if(s_on_platform && s_velocity_y>=0){
    int16_t mario_world_left=(int16_t)(s_camera+MARIO_X);
    int16_t mario_bottom=(int16_t)(s_mario_y+MARIO_H);
    for(i=0;i<LIFT_COUNT;i++){
     int16_t lift_x=s_lift_x[i];
     if(mario_world_left+MARIO_W>lift_x && mario_world_left<lift_x+24 &&
        mario_bottom>=lift_old_y[i]-2 && mario_bottom<=lift_old_y[i]+3){
      riding_lift=(uint8_t)(i+1U);
      break;
     }
    }
   }
   for(i=0;i<LIFT_COUNT;i++){
    s_lift_phase[i]=(uint8_t)((s_lift_phase[i]+1U)%LIFT_PERIOD);
    s_lift_y[i]=(int16_t)(LIFT_TOP_Y +
        (s_lift_phase[i]<=LIFT_HALF_CYCLE ? s_lift_phase[i] :
         (LIFT_PERIOD-s_lift_phase[i])));
   }
   if(riding_lift!=0U){
    i=(uint8_t)(riding_lift-1U);
    s_mario_y=(int16_t)(s_mario_y+s_lift_y[i]-lift_old_y[i]);
    s_velocity_y=0;
    s_grounded=1U;
    s_on_platform=1U;
   }
  }
  /* 刺猬只在 1-3 出现，沿固定平台区间往返移动；垂直碰撞由后续踩踏判定负责。 */
  if(!s_sky_mode && s_level==3U)for(i=0;i<HEDGEHOG_COUNT;i++)if(s_hedgehog_alive[i]){
   int16_t next_hedgehog_x=(int16_t)(s_hedgehog_x[i]+s_hedgehog_dir[i]);
   if(next_hedgehog_x<640+i*400){next_hedgehog_x=(int16_t)(640+i*400);s_hedgehog_dir[i]=1;}
   if(next_hedgehog_x>760+i*400){next_hedgehog_x=(int16_t)(760+i*400);s_hedgehog_dir[i]=-1;}
   if(IntersectsStairBlock(next_hedgehog_x,44,13U,14U)){
    s_hedgehog_dir[i]=(int8_t)(-s_hedgehog_dir[i]);
    next_hedgehog_x=(int16_t)(s_hedgehog_x[i]+s_hedgehog_dir[i]);
    if(IntersectsStairBlock(next_hedgehog_x,44,13U,14U))next_hedgehog_x=s_hedgehog_x[i];
   }
   s_hedgehog_x[i]=next_hedgehog_x;
  }
  /* 1-3 天空横向电梯：站在电梯顶面时，随平台左右移动而平移世界镜头。 */
  if(s_sky_mode){
   int16_t old_lift_x=s_sky_lift_x;
   riding_sky_lift=(uint8_t)(s_on_platform && s_velocity_y>=0 &&
      (s_camera+MARIO_X+MARIO_W)>old_lift_x && (s_camera+MARIO_X)<old_lift_x+SKY_LIFT_WIDTH &&
      s_mario_y+MARIO_H>=SKY_LIFT_Y-2 && s_mario_y+MARIO_H<=SKY_LIFT_Y+3);
   if(s_sky_lift_x<=s_vine_x+56)s_sky_lift_dir=1;
   else if(s_sky_lift_x>=s_vine_x+224)s_sky_lift_dir=-1;
   s_sky_lift_x=(int16_t)(s_sky_lift_x+s_sky_lift_dir);
   s_sky_lift_delta=(int8_t)(s_sky_lift_x-old_lift_x);
   if(riding_sky_lift)s_camera=(int16_t)(s_camera+s_sky_lift_delta);
  }
  if((s_sky_mode && !riding_sky_lift) || (!s_sky_mode && riding_lift==0U)){MoveCameraRespectPipes((int8_t)(s_direction==0U?1:-1));}
  old_bottom=s_mario_y+MARIO_H;old_top=s_mario_y;
  if(s_sky_mode){
   /* 天空地图使用独立重力和三层浮岛碰撞，PB1 可正常跳跃。 */
   s_sky_timer++;
   s_velocity_y++;if(s_velocity_y>5)s_velocity_y=5;s_mario_y=(int16_t)(s_mario_y+s_velocity_y);
   if(s_velocity_y>=0){int16_t b=(int16_t)(s_mario_y+MARIO_H),support=56;int16_t wx=(int16_t)(s_camera+MARIO_X);
    if(wx+MARIO_W>s_vine_x+42 && wx<s_vine_x+76 && old_bottom<=43 && b>=43)support=43;
    if(wx+MARIO_W>s_vine_x+96 && wx<s_vine_x+130 && old_bottom<=34 && b>=34 && 34<support)support=34;
    if(wx+MARIO_W>s_vine_x+151 && wx<s_vine_x+185 && old_bottom<=41 && b>=41 && 41<support)support=41;
    if(wx+MARIO_W>s_sky_lift_x && wx<s_sky_lift_x+SKY_LIFT_WIDTH && old_bottom<=SKY_LIFT_Y && b>=SKY_LIFT_Y && SKY_LIFT_Y<support)support=SKY_LIFT_Y;
    if(b>=support){s_mario_y=(int16_t)(support-MARIO_H);s_velocity_y=0;s_grounded=1U;s_on_platform=(support!=56);}
    else{s_grounded=0U;s_on_platform=0U;}
   }else{s_grounded=0U;s_on_platform=0U;}
   if(s_mario_y>64){s_mario_y=42;s_velocity_y=0;s_grounded=1U;s_on_platform=0U;}
  }
  else if(riding_lift!=0U){
   /* 已在前面随电梯完成垂直位移，本帧不再施加重力，保持脚底贴合平台。 */
   s_velocity_y=0;
  }
  else {
   /* 水下 2-2 的重力较弱，模拟原版水中较慢、较轻的跳跃手感。 */
   s_velocity_y++;
   if(s_velocity_y>(IsUnderwaterLevel()?3:7))s_velocity_y=(IsUnderwaterLevel()?3:7);
   s_mario_y+=s_velocity_y;
   /* 水下 2-2：每次按 PB1 都产生一次向上的游泳冲量；顶部 y=13 为水面，不能游出画面。 */
   if(IsUnderwaterLevel() && s_mario_y<13){s_mario_y=13;s_velocity_y=0;}
  }
  /* Robust swept underside collision. Test the complete horizontal world-space
     interval traversed this frame and the vertical crossing of the block bottom.
     Normal bricks break; question blocks become used but remain solid. */
  if(!s_sky_mode && s_velocity_y<0){
   int16_t old_world_left=old_camera+MARIO_X;
   int16_t new_world_left=s_camera+MARIO_X;
   int16_t sweep_left=(old_world_left<new_world_left)?old_world_left:new_world_left;
   int16_t sweep_right=((old_world_left>new_world_left)?old_world_left:new_world_left)+MARIO_W;
   for(i=0;i<ActiveBlockCount();i++)if(!s_block_broken[i] && !BlockMergedFollower(i)){
    int16_t block_left=BlockX(i);
    int16_t block_bottom=BlockY(i)+9;
    if(sweep_right>block_left && sweep_left<block_left+BlockWidth(i) &&
       old_top>=block_bottom-2 && s_mario_y<=block_bottom){
     uint8_t enemy_killed=KillEnemyOnTopOfBlock(i);
     s_mario_y=block_bottom; s_velocity_y=0;
     CollectCoinAboveBlock(i);
     if(IsTenCoinBlock(i)){
      if(s_coin_block_hits[i]<10U){
       s_coin_block_hits[i]++;
       if(s_coin_block_hits[i]>=10U)s_block_used[i]=1U;
       s_coin_pop_active=1U;s_coin_pop_frame=0U;
       s_coin_pop_x=BlockX(i);s_coin_pop_y=(int16_t)(BlockY(i)-8);
       AwardCoin();
      }else StartGameSfx(bump_sfx,(uint8_t)(sizeof(bump_sfx)/sizeof(bump_sfx[0])));
     }else if(IsHiddenCoinBlock(i)){
      if(!s_block_used[i]){
       s_block_used[i]=1U;s_coin_pop_active=1U;s_coin_pop_frame=0U;
       s_coin_pop_x=BlockX(i);s_coin_pop_y=(int16_t)(BlockY(i)-8);
       AwardCoin();
      }else StartGameSfx(bump_sfx,(uint8_t)(sizeof(bump_sfx)/sizeof(bump_sfx[0])));
     }else if(IsQuestionBlock(i)){
      if(!s_block_used[i]){
       s_block_used[i]=1;
       {
        uint8_t reward=QuestionBlockReward(i);
        if(reward==1U){s_vine_active=1U;s_vine_x=BlockX(i)+4;StartGameSfx(vine_sfx,(uint8_t)(sizeof(vine_sfx)/sizeof(vine_sfx[0])));}
        else if(reward==2U){SpawnQuestionGoomba(i);StartGameSfx(item_sfx,(uint8_t)(sizeof(item_sfx)/sizeof(item_sfx[0])));}
        else if(reward==3U){s_coin_pop_active=1U;s_coin_pop_frame=0U;s_coin_pop_x=BlockX(i);s_coin_pop_y=(int16_t)(BlockY(i)-8);AwardCoin();}
        else SpawnQuestionPowerup(i);
       }
      }
      /* 问号箱被顶起时播放“碰撞/顶箱”音效；已使用箱再次顶起仍有反馈。 */
      StartGameSfx(bump_sfx,(uint8_t)(sizeof(bump_sfx)/sizeof(bump_sfx[0])));
     }else{
      s_block_broken[i]=1U;
      /* World 1-1 至 1-4 的独立中段砖块（索引 26）均可掉落无敌星星。 */
      if(i==26U && s_level>=1U && s_level<=4U){s_star_active=1U;s_star_x=(int16_t)(BlockX(i)+9);s_star_y=(int16_t)(BlockY(i)-8);s_star_dir=1; s_star_vy=-3;StartGameSfx(item_sfx,(uint8_t)(sizeof(item_sfx)/sizeof(item_sfx[0])));}
      StartGameSfx(brick_sfx,(uint8_t)(sizeof(brick_sfx)/sizeof(brick_sfx[0])));
     }
     /* 若砖块顶上有 Goomba，顶击消灭音效优先于普通顶砖音效。 */
     if(enemy_killed)StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));
     break;
    }
   }
   /* 阶梯是实体方块：马里奥从下方顶到台阶底面时停止上升，不能穿模。 */
   {
    uint8_t st,row,col,stair_hit=0U;
    for(st=0U;st<StaircaseCount() && stair_hit==0U;st++){
     for(row=0U;row<StaircaseRowsFor(st) && stair_hit==0U;row++)for(col=0U;col<(uint8_t)(StaircaseRowsFor(st)-row);col++){
      int16_t block_left=StairBlockX(st,row,col);
      int16_t block_bottom=(int16_t)(GROUND_TOP-(int16_t)row*9);
      if(sweep_right>block_left && sweep_left<block_left+9 &&
         old_top>=block_bottom-2 && s_mario_y<=block_bottom){
       s_mario_y=block_bottom;s_velocity_y=0;stair_hit=1U;break;
      }
     }
    }
   }
  }
  landing=s_sky_mode?-1:FindLanding(old_bottom,s_mario_y+MARIO_H,old_camera,s_camera,&platform);
  if(s_sky_mode){ /* 天空浮岛支撑已在独立物理分支中处理。 */ }
  else if(landing>=0){
   s_mario_y=landing-MARIO_H;s_velocity_y=0;s_grounded=1;s_on_platform=platform;
   if(SpringActive() && landing==SPRING_TOP && s_camera+MARIO_X+MARIO_W>SpringX() && s_camera+MARIO_X<SpringX()+SPRING_WIDTH){
    s_velocity_y=-12;s_grounded=0U;s_on_platform=0U;
    StartGameSfx(spring_sfx,(uint8_t)(sizeof(spring_sfx)/sizeof(spring_sfx[0])));
   }
  }
  else{s_grounded=0;s_on_platform=0;}
  world_center=s_camera+MARIO_X+MARIO_W/2;
  if(!s_sky_mode && !InCliff(world_center) && s_mario_y+MARIO_H>GROUND_TOP){s_mario_y=GROUND_TOP-MARIO_H;s_velocity_y=0;s_grounded=1;s_on_platform=0;}
  if(!s_sky_mode && InCliff(world_center) && s_mario_y+MARIO_H>GROUND_TOP){HitByEnemy();}
  /*
   * 天空奖励地图是独立的安全场景。其世界坐标与地面关卡重叠，
   * 地面 Goomba、乌龟、云刺和飞行敌人即使在天空画面中不可见，
   * 仍可能与马里奥坐标相交并造成隐形伤害。天空模式下暂停这些
   * 地面敌人与危险物的移动和碰撞，返回地面后再从原状态继续。
   */
  /* Goomba 在世界坐标中巡逻；离开砖块边缘后会受重力影响落向下层平台/地面。 */
  if(!s_sky_mode)for(i=0;i<ENEMY_COUNT;i++)if(s_enemy_alive[i]){
   int16_t enemy_bottom,enemy_support,enemy_next_bottom;
   int16_t next_enemy_x=(int16_t)(s_enemy_x[i]+s_enemy_dir[i]);
   /*
    * 先检测下一步是否会与水管发生侧面碰撞。若会碰到，则反转方向并原路退回，
    * 不把 Goomba 坐标推进到管道内部；站在管口顶面时仍可正常行走。
    */
   if(EnemyIntersectsPipe(s_enemy_x[i],s_enemy_y[i])){
    /* 已因垂直下落进入管体时，沿最近的水平出口持续退出。 */
    s_enemy_dir[i]=EnemyDirectionAwayFromPipe(s_enemy_x[i],s_enemy_y[i],s_enemy_dir[i]);
    next_enemy_x=(int16_t)(s_enemy_x[i]+s_enemy_dir[i]);
   }else if(EnemyIntersectsPipe(next_enemy_x,s_enemy_y[i])){
    /* 正常从侧面接近管道：原地掉头，并向来路退一步。 */
    s_enemy_dir[i]=(int8_t)(-s_enemy_dir[i]);
    next_enemy_x=(int16_t)(s_enemy_x[i]+s_enemy_dir[i]);
    if(EnemyIntersectsPipe(next_enemy_x,s_enemy_y[i]))next_enemy_x=s_enemy_x[i];
   }else if(IntersectsStairBlock(next_enemy_x,s_enemy_y[i],11U,7U)){
    /* 普通怪物不能从阶梯侧面穿过去，会在台阶前掉头。 */
    s_enemy_dir[i]=(int8_t)(-s_enemy_dir[i]);
    next_enemy_x=(int16_t)(s_enemy_x[i]+s_enemy_dir[i]);
    if(IntersectsStairBlock(next_enemy_x,s_enemy_y[i],11U,7U))next_enemy_x=s_enemy_x[i];
   }
   s_enemy_x[i]=next_enemy_x;
   /* 一旦怪物中心进入悬崖，不再按巡逻半径掉头；继续前进并受重力下坠。 */
   if(!InCliff((int16_t)(s_enemy_x[i]+5))){
    if(s_enemy_x[i]<s_enemy_home_x[i]-38){s_enemy_x[i]=(int16_t)(s_enemy_home_x[i]-38);s_enemy_dir[i]=1;}
    if(s_enemy_x[i]>s_enemy_home_x[i]+38){s_enemy_x[i]=(int16_t)(s_enemy_home_x[i]+38);s_enemy_dir[i]=-1;}
   }

   /* 先检查当前脚底是否仍有支撑；没有支撑时逐帧增加下落速度。 */
   enemy_bottom=(int16_t)(s_enemy_y[i]+7);
   enemy_support=EnemyFindSupport((int16_t)(s_enemy_x[i]+5),enemy_bottom);
   if(enemy_support>=0 && enemy_support<=enemy_bottom+1){
    s_enemy_y[i]=(int16_t)(enemy_support-7);
    s_enemy_vy[i]=0;
   }else{
    if(s_enemy_vy[i]<4)s_enemy_vy[i]++;
    enemy_next_bottom=(int16_t)(enemy_bottom+s_enemy_vy[i]);
    enemy_support=EnemyFindSupport((int16_t)(s_enemy_x[i]+5),enemy_bottom);
    if(enemy_support>=enemy_bottom && enemy_support<=enemy_next_bottom){
     s_enemy_y[i]=(int16_t)(enemy_support-7);
     s_enemy_vy[i]=0;
    }else{
     s_enemy_y[i]=(int16_t)(s_enemy_y[i]+s_enemy_vy[i]);
     if(s_enemy_y[i]>64){s_enemy_alive[i]=0U;continue;}
    }
   }
   ex=s_enemy_x[i]-s_camera;ey=s_enemy_y[i];
   if(s_pipe_invuln_ms==0U && MARIO_X+MARIO_W>ex && MARIO_X<ex+11 && s_mario_y+MARIO_H>ey && s_mario_y<ey+7){
     if(s_star_ms>0U || stomped_this_frame){s_enemy_alive[i]=0U;continue;}
     if(s_invuln_ms==0U){
      if(s_velocity_y>=0 && old_bottom<=ey+3){
       s_enemy_alive[i]=0U;stomped_this_frame=1U;s_velocity_y=-5;s_grounded=0;s_on_platform=0;
       StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));
      } else {HitByEnemy();break;}
     }
   }
  }
  /*
   * Koopa Troopas：行走、缩壳、踢壳和朝悬崖移动均使用同一套水平/垂直碰撞。
   * 失去地面或砖块支撑时施加重力；接触水管侧壁时停在管外并掉头。
   */
  if(!s_sky_mode)for(i=0;i<TURTLE_COUNT;i++)if(s_turtle_alive[i]){
   int16_t tx,ty,left,right;
   int16_t move_delta=0;
   if(s_turtle_state[i]==3U){
    if(s_turtle_timer[i]<120U)s_turtle_timer[i]++;
    else {s_turtle_alive[i]=0U;continue;}
    move_delta=(int16_t)(s_turtle_dir[i]*2);
   }else if(s_turtle_state[i]==0U){
    move_delta=s_turtle_dir[i];
   }else if(s_turtle_state[i]==1U){
    if(s_turtle_timer[i]<60U)s_turtle_timer[i]++;
    else {s_turtle_state[i]=0U;s_turtle_timer[i]=0U;s_turtle_dir[i]=-1;move_delta=s_turtle_dir[i];}
   }else{
    move_delta=(int16_t)(s_turtle_dir[i]*4);
   }
   if(move_delta!=0){
    TurtleMoveRespectPipes(i,move_delta);
    if(s_turtle_state[i]==0U){
     if(s_turtle_x[i]<s_turtle_home_x[i]-34){s_turtle_x[i]=(int16_t)(s_turtle_home_x[i]-34);s_turtle_dir[i]=1;}
     if(s_turtle_x[i]>s_turtle_home_x[i]+34){s_turtle_x[i]=(int16_t)(s_turtle_home_x[i]+34);s_turtle_dir[i]=-1;}
    }
    if(s_turtle_state[i]==2U && (s_turtle_x[i]<0 || s_turtle_x[i]>WorldLength()-TURTLE_W)){
     s_turtle_state[i]=1U;s_turtle_timer[i]=0U;
     if(s_turtle_x[i]<0)s_turtle_x[i]=0;
     if(s_turtle_x[i]>WorldLength()-TURTLE_W)s_turtle_x[i]=(int16_t)(WorldLength()-TURTLE_W);
    }
   }
   UpdateTurtleVertical(i);
   if(!s_turtle_alive[i])continue;
   tx=(int16_t)(s_turtle_x[i]-s_camera);
   ty=s_turtle_y[i];left=tx;right=(int16_t)(tx+TURTLE_W);
   if(s_pipe_invuln_ms==0U && MARIO_X+MARIO_W>left && MARIO_X<right &&
      s_mario_y+MARIO_H>ty && s_mario_y<ty+TURTLE_H){
    if(s_turtle_state[i]==3U){ /* 朝悬崖移动的壳体不参与玩家碰撞。 */ }
    else if(s_star_ms>0U){s_turtle_alive[i]=0U;continue;}
    else if((s_velocity_y>=0 && old_bottom<=ty+3) || stomped_this_frame){
     if(s_turtle_state[i]==0U){s_turtle_state[i]=1U;s_turtle_timer[i]=0U;}
     else if(s_turtle_state[i]==1U){
      if(s_level==3U){int16_t wx=s_turtle_x[i];s_turtle_state[i]=3U;s_turtle_timer[i]=0U;s_turtle_dir[i]=DirectionToNearestCliff(wx);}
      else {s_turtle_state[i]=2U;s_turtle_dir[i]=(MARIO_X+MARIO_W/2<tx+6)?1:-1;}
     }else {s_turtle_state[i]=1U;s_turtle_timer[i]=0U;}
     s_turtle_vy[i]=0;
     s_mario_y=(int16_t)(ty-MARIO_H);s_velocity_y=-5;s_grounded=0;s_on_platform=0;
     StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));
    }else if(s_turtle_state[i]==1U){
     /* Touching a stationary shell kicks it away, as in the original game. */
     s_turtle_state[i]=2U;s_turtle_dir[i]=(MARIO_X+MARIO_W/2<tx+6)?1:-1;
     StartGameSfx(kick_sfx,(uint8_t)(sizeof(kick_sfx)/sizeof(kick_sfx[0])));
    }else{
     HitByEnemy();
    }
   }
   if(s_turtle_state[i]==2U){
    uint8_t j;
    for(j=0;j<ENEMY_COUNT;j++)if(s_enemy_alive[j] && s_turtle_x[i]+TURTLE_W>s_enemy_x[j] && s_turtle_x[i]<s_enemy_x[j]+11)s_enemy_alive[j]=0U;
    for(j=0U;j<2U;j++)if(s_fly_turtle_alive[j] && s_turtle_x[i]+TURTLE_W>s_fly_turtle_x[j] && s_turtle_x[i]<s_fly_turtle_x[j]+14)s_fly_turtle_alive[j]=0U;
    for(j=0U;j<HAMMER_BRO_COUNT;j++)if(s_hammer_bro_alive[j] && s_turtle_x[i]+TURTLE_W>s_hammer_bro_start[j] && s_turtle_x[i]<s_hammer_bro_start[j]+14)s_hammer_bro_alive[j]=0U;
    for(j=0;j<TURTLE_COUNT;j++)if(j!=i && s_turtle_alive[j] && s_turtle_x[i]+TURTLE_W>s_turtle_x[j] && s_turtle_x[i]<s_turtle_x[j]+TURTLE_W && s_turtle_state[j]!=2U){s_turtle_state[j]=1U;s_turtle_timer[j]=0U;}
    /* 原版机制：踢出的龟壳可以消灭炮弹，火球则不能摧毁炮弹。 */
    for(j=0U;j<BULLET_BILL_COUNT;j++)if(s_bill_active[j] &&
       s_turtle_x[i]+TURTLE_W>s_bill_x[j] && s_turtle_x[i]<s_bill_x[j]+12 &&
       s_turtle_y[i]+TURTLE_H>s_bill_y[j] && s_turtle_y[i]<s_bill_y[j]+8)s_bill_active[j]=0U;
    for(j=0U;j<PIPE_COUNT;j++)if(!s_plant_dead[j] && s_level!=2U && s_level!=4U && s_level!=6U && s_level!=7U && s_level!=8U && !IsCastleLevel() &&
       s_turtle_x[i]+TURTLE_W>PipeX(j) && s_turtle_x[i]<PipeX(j)+17 &&
       s_turtle_y[i]+TURTLE_H>PiranhaY(j) && s_turtle_y[i]<PiranhaY(j)+9)s_plant_dead[j]=1U;
   }
  }
  /* WORLD 2-1 炮弹车：炮台在玩家接近时发射炮弹，踩踏/无敌可消灭炮弹。 */
  if(s_level==5U){
   for(i=0;i<BULLET_BILL_COUNT;i++){
    int16_t cannon_screen=(int16_t)(s_bill_cannon_x[i]-s_camera);
    if(s_bill_cannon_timer[i]<100U)s_bill_cannon_timer[i]++;
    if(!s_bill_active[i] && s_bill_cannon_timer[i]>=28U && cannon_screen>=75 && cannon_screen<=145){
     s_bill_active[i]=1U;s_bill_x[i]=(int16_t)(s_bill_cannon_x[i]+5);s_bill_y[i]=45;s_bill_cannon_timer[i]=0U;StartGameSfx(cannon_sfx,(uint8_t)(sizeof(cannon_sfx)/sizeof(cannon_sfx[0])));
    }
    if(s_bill_active[i]){
     int16_t bx;
     s_bill_x[i]-=3;bx=(int16_t)(s_bill_x[i]-s_camera);
     if(bx<-16 || bx>140){s_bill_active[i]=0U;continue;}
     if(MARIO_X+MARIO_W>bx && MARIO_X<bx+12 && s_mario_y+MARIO_H>s_bill_y[i] && s_mario_y<s_bill_y[i]+8){
      if(s_star_ms>0U){s_bill_active[i]=0U;}
      else if(s_velocity_y>=0 && old_bottom<=s_bill_y[i]+2){s_bill_active[i]=0U;s_velocity_y=-5;s_grounded=0U;s_on_platform=0U;StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));}
      else HitByEnemy();
     }
    }
   }
  }
  /* WORLD 2-3：飞鱼从木桥间的水面跃出，走完整抛物线后潜回水中。 */
  if(s_level==7U){
   for(i=0U;i<FISH_COUNT;i++){
    uint8_t phase;
    if(!s_fish_alive[i]){
     if(s_fish_respawn_frames[i]>0U)s_fish_respawn_frames[i]--;
     if(s_fish_respawn_frames[i]==0U){s_fish_alive[i]=1U;s_fish_x[i]=(int16_t)(s_fish_left[i]+14);s_fish_y[i]=62;s_fish_phase[i]=0U;s_fish_dir[i]=(i&1U)?-1:1;}
    }
    if(!s_fish_alive[i])continue;
    s_fish_phase[i]=(uint8_t)((s_fish_phase[i]+1U)%64U);
    s_fish_x[i]=(int16_t)(s_fish_x[i]+s_fish_dir[i]);
    if(s_fish_x[i]<=s_fish_left[i]){s_fish_x[i]=s_fish_left[i];s_fish_dir[i]=1;}
    if(s_fish_x[i]>=s_fish_right[i]){s_fish_x[i]=s_fish_right[i];s_fish_dir[i]=-1;}
    phase=s_fish_phase[i];
    if(phase<40U){
     /* 原版飞鱼以近似抛物线从水面跃起，再落回水中。 */
     s_fish_y[i]=(int16_t)(62-((int16_t)phase*(40-(int16_t)phase)*47)/400);
    }else s_fish_y[i]=62;
    ex=(int16_t)(s_fish_x[i]-s_camera);
    if(s_fish_y[i]<60 && MARIO_X+MARIO_W>ex && MARIO_X<ex+12 &&
       s_mario_y+MARIO_H>s_fish_y[i] && s_mario_y<s_fish_y[i]+8 && s_pipe_invuln_ms==0U){
     if(s_star_ms>0U){s_fish_alive[i]=0U;s_fish_respawn_frames[i]=30U;}
     else if(s_velocity_y>=0 && old_bottom<=s_fish_y[i]+2){s_fish_alive[i]=0U;s_fish_respawn_frames[i]=30U;s_velocity_y=-5;s_grounded=0U;s_on_platform=0U;StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));}
     else HitByEnemy();
    }
   }
  }
  /* WORLD 2-1 锤子兄弟站在砖台上巡逻；每名兄弟独立同时投出两枚锤子。 */
  if(s_level==5U){
   for(i=0U;i<HAMMER_BRO_COUNT;i++)if(s_hammer_bro_alive[i]){
    uint8_t spawned;int16_t bro_x;
    /* 每 2 帧横向移动 1px，在三块砖平台范围内往返巡逻。 */
    s_hammer_bro_walk_timer[i]++;
    if(s_hammer_bro_walk_timer[i]>=2U){
     int16_t next_x;
     s_hammer_bro_walk_timer[i]=0U;
     next_x=(int16_t)(s_hammer_bro_start[i]+s_hammer_bro_dir[i]);
     if(next_x<s_hammer_bro_min_x[i] || next_x>s_hammer_bro_max_x[i]){
      s_hammer_bro_dir[i]=(int8_t)-s_hammer_bro_dir[i];
      next_x=(int16_t)(s_hammer_bro_start[i]+s_hammer_bro_dir[i]);
     }
     s_hammer_bro_start[i]=next_x;
    }
    bro_x=s_hammer_bro_start[i];
    if(s_hammer_bro_timer[i]<62U)s_hammer_bro_timer[i]++;
    else{
     int8_t dir=(int8_t)(((s_camera+MARIO_X+5)<bro_x)?-1:1);
     s_hammer_bro_timer[i]=0U;
     /* 每名兄弟固定使用自己的两个弹体槽位，确保双锤同帧发射。 */
     for(spawned=0U;spawned<2U;spawned++){
      uint8_t h=(uint8_t)(i*2U+spawned);
      if(!s_hammer_active[h]){
       s_hammer_active[h]=1U;
       /* 两枚锤子从不同高度和横向位置出手，避免视觉上重叠成一枚。 */
       s_hammer_x[h]=(int16_t)(bro_x+4+(int16_t)spawned*5);
       s_hammer_y[h]=(int16_t)(s_hammer_bro_y[i]-2-(int16_t)spawned*5);
       s_hammer_vx[h]=(int8_t)(dir*(spawned==0U?2:3));
       s_hammer_vy[h]=(int8_t)(spawned==0U?-6:-4);
      }
     }
    }
    s_hammer_bro_y[i]=(int16_t)(s_hammer_bro_home_y[i]-((s_hammer_bro_timer[i]/10U+i)%2U));
    ex=(int16_t)(bro_x-s_camera);
    if(s_pipe_invuln_ms==0U && MARIO_X+MARIO_W>ex && MARIO_X<ex+14 && s_mario_y+MARIO_H>s_hammer_bro_y[i] && s_mario_y<s_hammer_bro_y[i]+15){
     if(s_star_ms>0U)s_hammer_bro_alive[i]=0U;
     else if(s_velocity_y>=0 && old_bottom<=s_hammer_bro_y[i]+3){s_hammer_bro_alive[i]=0U;s_velocity_y=-5;s_grounded=0U;s_on_platform=0U;StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));}
     else HitByEnemy();
    }
   }
   for(i=0U;i<HAMMER_COUNT;i++)if(s_hammer_active[i]){
    int16_t hx,hy,old_hammer_x=s_hammer_x[i];
    s_hammer_x[i]=(int16_t)(s_hammer_x[i]+s_hammer_vx[i]);
    s_hammer_y[i]=(int16_t)(s_hammer_y[i]+s_hammer_vy[i]);
    if(s_hammer_vy[i]<6)s_hammer_vy[i]++;
    hx=(int16_t)(s_hammer_x[i]-s_camera);hy=s_hammer_y[i];
    if(hy>GROUND_TOP || HammerHitsSolid(old_hammer_x,s_hammer_x[i],hy) || hx<-12 || hx>140){s_hammer_active[i]=0U;continue;}
    if(s_pipe_invuln_ms==0U && MARIO_X+MARIO_W>hx && MARIO_X<hx+6 && s_mario_y+MARIO_H>hy && s_mario_y<hy+8){
     s_hammer_active[i]=0U;
     if(s_star_ms==0U)HitByEnemy();
    }
   }
  }
  for(i=0U;i<ITEM_COUNT;i++)if(s_item_available[i]){
   if(!MoveWorldItem(&s_item_x[i],&s_item_y,&s_item_vx[i],&s_item_vy[i],&s_item_age,1U,11U,8U,0U))s_item_available[i]=0U;
   ex=s_item_x[i]-s_camera;
   if(MARIO_X+MARIO_W>ex && MARIO_X<ex+11 && s_mario_y+MARIO_H>s_item_y && s_mario_y<s_item_y+8){
    s_item_available[i]=0U;
    if(s_item_is_1up){if(s_lives<9U)s_lives++;UpdateLivesHud();StartGameSfx(oneup_sfx,(uint8_t)(sizeof(oneup_sfx)/sizeof(oneup_sfx[0])));}
    else {s_powered=1U;StartGameSfx(powerup_sfx,(uint8_t)(sizeof(powerup_sfx)/sizeof(powerup_sfx[0])));}
   }
  }
  if(s_sky_mode)for(i=0;i<SKY_COIN_COUNT;i++)if(!s_sky_coin_taken[i]){
   int16_t cx=(int16_t)(s_vine_x+35+i*12-s_camera);
   int16_t cy=(int16_t)(i%4U==0U?29:(i%4U==1U?20:(i%4U==2U?36:25)));
   if(MARIO_X+MARIO_W>cx && MARIO_X<cx+8 && s_mario_y+MARIO_H>cy && s_mario_y<cy+9){
    s_sky_coin_taken[i]=1U;AwardCoin();
   }
  }
  if(!s_sky_mode)for(i=0;i<LevelCoinCount();i++)if(!s_coin_taken[i]){
   int16_t cx=(int16_t)(CoinX(i)-s_camera);
   int16_t cy=CoinY(i);
   if(MARIO_X+MARIO_W>cx && MARIO_X<cx+8 && s_mario_y+MARIO_H>cy && s_mario_y<cy+8){
    s_coin_taken[i]=1U;AwardCoin();
   }
  }
  /* 1-3 尖刺雲可被踩踏消滅：只在玩家由上向下穿过云顶时触发，云投出的尖刺仍有伤害。 */
  if(!s_sky_mode && s_level==3U)for(i=0;i<CLOUD_COUNT;i++)if(s_cloud_alive[i]){
   int16_t cloud_top=(int16_t)(10+i*4+3);
   ex=s_cloud_x[i]-s_camera;
   if(MARIO_X+MARIO_W>ex && MARIO_X<ex+23 && s_velocity_y>=0 &&
      old_bottom<=cloud_top && s_mario_y+MARIO_H>=cloud_top){
    s_cloud_alive[i]=0U;
    s_cloud_spike_active[i]=0U;
    s_velocity_y=-5;
    s_grounded=0U;
    s_on_platform=0U;
    stomped_this_frame=1U;
    StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));
   }else if(s_star_ms>0U && MARIO_X+MARIO_W>ex && MARIO_X<ex+23 &&
            s_mario_y+MARIO_H>10+i*4 && s_mario_y<22+i*4){
    s_cloud_alive[i]=0U;s_cloud_spike_active[i]=0U;
   }
   if(s_cloud_alive[i] && s_cloud_spike_active[i]){
    ex=s_cloud_spike_x[i]-s_camera;
    if(s_star_ms==0U && MARIO_X+MARIO_W>ex && MARIO_X<ex+4 &&
       s_mario_y+MARIO_H>s_cloud_spike_y[i] && s_mario_y<s_cloud_spike_y[i]+5)HitByEnemy();
   }
  }
  /* 刺猬的尖刺顶端为 y=44；从上方下落并越过尖刺顶端时视为踩踏，侧面接触仍会受伤。 */
  if(!s_sky_mode && s_level==3U)for(i=0;i<HEDGEHOG_COUNT;i++)if(s_hedgehog_alive[i]){
   int16_t mario_bottom=(int16_t)(s_mario_y+MARIO_H);
   ex=s_hedgehog_x[i]-s_camera;
   if(MARIO_X+MARIO_W>ex && MARIO_X<ex+14 && mario_bottom>44 && s_mario_y<58){
    if(s_star_ms>0U){s_hedgehog_alive[i]=0U;}
    else if(s_velocity_y>=0 && old_bottom<=46 && mario_bottom>=44){
     s_hedgehog_alive[i]=0U;
     s_velocity_y=-5;s_grounded=0U;s_on_platform=0U;
     stomped_this_frame=1U;
     StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));
    }else if(!stomped_this_frame){HitByEnemy();}
   }
  }
  if(s_star_active){
   if(!MoveWorldItem(&s_star_x,&s_star_y,&s_star_dir,&s_star_vy,&s_star_age,0U,9U,8U,1U))s_star_active=0U;
   ex=s_star_x-s_camera;
   if(s_star_active && MARIO_X+MARIO_W>ex && MARIO_X<ex+9 && s_mario_y+MARIO_H>s_star_y && s_mario_y<s_star_y+9){
    s_star_active=0U;s_star_ms=10000U;s_invuln_ms=10000U;
    StartGameSfx(star_sfx,(uint8_t)(sizeof(star_sfx)/sizeof(star_sfx[0])));
   }
   if(s_star_x<s_camera-12 || s_star_x>s_camera+140)s_star_active=0U;
  }
  if(s_coin_pop_active){s_coin_pop_y--;if(++s_coin_pop_frame>=8U)s_coin_pop_active=0U;}
  if(s_block_flower_active){
   /* 火焰花弹出箱口后只上升 8 帧，随后原地静止。 */
   if(s_block_flower_age<8U){s_block_flower_y--;s_block_flower_age++;}
   ex=s_block_flower_x-s_camera;
   if(s_block_flower_active && MARIO_X+MARIO_W>ex && MARIO_X<ex+11 && s_mario_y+MARIO_H>s_block_flower_y && s_mario_y<s_block_flower_y+8){
    s_block_flower_active=0U;
    if(s_fire_powered){if(s_lives<9U)s_lives++;UpdateLivesHud();StartGameSfx(oneup_sfx,(uint8_t)(sizeof(oneup_sfx)/sizeof(oneup_sfx[0])));}
    else{s_fire_powered=1U;s_powered=1U;StartGameSfx(powerup_sfx,(uint8_t)(sizeof(powerup_sfx)/sizeof(powerup_sfx[0])));}
   }
  }

  /* Piranha plant contact hurts Mario when a plant is visibly above a pipe. */
  for(i=0;!s_sky_mode && i<PIPE_COUNT;i++)if(!s_plant_dead[i] && s_level!=2U && s_level!=4U && s_level!=6U && s_level!=7U && s_level!=8U && !IsCastleLevel()){uint8_t t=(uint8_t)(s_plant_phase[i]%100U);if(t>=10U&&t<68U){ex=PipeX(i)-s_camera;ey=PiranhaY(i);if(MARIO_X+MARIO_W>ex+1 && MARIO_X<ex+16 && s_mario_y+MARIO_H>ey && s_mario_y<ey+9){
    if(s_star_ms>0U)s_plant_dead[i]=1U;else HitByEnemy();break;
   }}}
  /* 电梯承载已在本帧重力结算前完成；此处不再二次修正角色坐标。 */
  /* Flying Koopas in 1-3: stomp them to remove their wings and make them walk. */
  if(!s_sky_mode && s_level==3U)for(i=0;i<2;i++)if(s_fly_turtle_alive[i]){
   int16_t fly_next_x=(int16_t)(s_fly_turtle_x[i]+s_fly_turtle_dir[i]);
   s_fly_turtle_y[i]=(int16_t)(20+((s_plant_phase[i]/3U+i*5U)%12U));
   if(fly_next_x<16 || fly_next_x+14>WorldLength() || FlyingKoopaHitsSolid(fly_next_x,s_fly_turtle_y[i])){
    s_fly_turtle_dir[i]=(int8_t)(-s_fly_turtle_dir[i]);
    fly_next_x=(int16_t)(s_fly_turtle_x[i]+s_fly_turtle_dir[i]);
    if(fly_next_x<16 || fly_next_x+14>WorldLength() || FlyingKoopaHitsSolid(fly_next_x,s_fly_turtle_y[i]))fly_next_x=s_fly_turtle_x[i];
   }
   s_fly_turtle_x[i]=fly_next_x;ex=s_fly_turtle_x[i]-s_camera;
   if(MARIO_X+MARIO_W>ex && MARIO_X<ex+14 && s_mario_y+MARIO_H>s_fly_turtle_y[i] && s_mario_y<s_fly_turtle_y[i]+12){
    if(s_pipe_invuln_ms>0U){ /* 出管保护期间不击杀、不伤害敌人。 */ }
    else if(s_star_ms>0U){s_fly_turtle_alive[i]=0U;}
    else if(s_velocity_y>=0 && old_bottom<=s_fly_turtle_y[i]+3){ConvertFlyingKoopaToTurtle(i);s_velocity_y=-5;s_grounded=0;StartGameSfx(stomp_sfx,(uint8_t)(sizeof(stomp_sfx)/sizeof(stomp_sfx[0])));}
    else HitByEnemy();
   }
  }
  if(!s_sky_mode && s_poison_active){
   if(!MoveWorldItem(&s_poison_x,&s_poison_y,&s_poison_vx,&s_poison_vy,&s_poison_age,1U,11U,8U,0U))s_poison_active=0U;
   if(s_poison_x<s_camera-16)s_poison_active=0U;
   ex=s_poison_x-s_camera;
   if(s_poison_active && MARIO_X+MARIO_W>ex && MARIO_X<ex+11 && s_mario_y+MARIO_H>s_poison_y && s_mario_y<s_poison_y+8){s_poison_active=0U;HitByEnemy();}
  }
  /* 触碰桥头斧头后暂停马里奥，镜头先移向桥中央，再播放库巴坠落。 */
  if(IsCastleLevel() && !s_boss_bridge_broken){
   int16_t lever_world=(int16_t)(GoalX()-40);
   int16_t mario_world_left=(int16_t)(s_camera+MARIO_X);
   if(mario_world_left+MARIO_W>lever_world-5 && mario_world_left<lever_world+6 &&
      s_mario_y+MARIO_H>=45 && s_grounded){
    s_boss_cine_return_camera=s_camera;
    s_boss_cine_target_camera=(int16_t)(s_boss_x-52);
    if(s_boss_cine_target_camera<0)s_boss_cine_target_camera=0;
    if(s_boss_cine_target_camera>WorldLength()-128)s_boss_cine_target_camera=(int16_t)(WorldLength()-128);
    s_boss_cine_mario_y=s_mario_y;
    s_boss_cine_mario_world_x=(int16_t)(s_camera+s_mario_draw_x);
    s_boss_cine_timer=0U;s_direction=0U;s_state=25U;s_state_ms=0U;
    DrawScene();OLED_GFX_Refresh();return;
   }
  }
  /* 库巴会朝马里奥所在的一侧连续喷射火球；玩家在左/右两边均能正常触发攻击。 */
  if(IsCastleLevel() && !s_boss_defeated && !s_boss_falling){
   int16_t mario_world_x=(int16_t)(s_camera+MARIO_X+MARIO_W/2);
   if(++s_boss_attack_timer>=58U){
    uint8_t b;s_boss_attack_timer=0U;
    if((mario_world_x>=s_boss_x-512) && (mario_world_x<=s_boss_x+BOSS_WIDTH+512)){
     for(b=0U;b<BOSS_FIREBALL_COUNT;b++)if(!s_boss_fire_active[b]){
      int8_t dir=(int8_t)((mario_world_x<s_boss_x)?-1:1);
      s_boss_fire_active[b]=1U;
      s_boss_fire_x[b]=(int16_t)(dir<0?s_boss_x-5:s_boss_x+BOSS_WIDTH);
      s_boss_fire_y[b]=(int16_t)(s_boss_y+7);
      s_boss_fire_vx[b]=(int8_t)(dir*4);
      s_boss_fire_vy[b]=(int8_t)((s_boss_move_phase&1U)?1:-1);
      s_boss_fire_phase[b]=0U;
      break;
     }
    }
   }
   /* 库巴每隔一段时间向马里奥投掷一组带重力的抛物线锤子。 */
   if(++s_boss_hammer_timer>=96U){
    uint8_t h,spawned=0U;
    int8_t dir=(int8_t)((mario_world_x<s_boss_x)?-1:1);
    s_boss_hammer_timer=0U;
    if((mario_world_x>=s_boss_x-512) && (mario_world_x<=s_boss_x+BOSS_WIDTH+512)){
     for(h=0U;h<HAMMER_COUNT && spawned<2U;h++)if(!s_hammer_active[h]){
      s_hammer_active[h]=1U;
      s_hammer_x[h]=(int16_t)(dir<0?s_boss_x-5:s_boss_x+BOSS_WIDTH-1);
      s_hammer_y[h]=(int16_t)(s_boss_y+4-(int16_t)spawned*2);
      s_hammer_vx[h]=(int8_t)(dir*(spawned==0U?2:3));
      s_hammer_vy[h]=(int8_t)(spawned==0U?-7:-5);
      spawned++;
     }
    }
   }
   for(i=0U;i<HAMMER_COUNT;i++)if(s_hammer_active[i]){
    int16_t old_hammer_x=s_hammer_x[i];
    s_hammer_x[i]=(int16_t)(s_hammer_x[i]+s_hammer_vx[i]);
    s_hammer_y[i]=(int16_t)(s_hammer_y[i]+s_hammer_vy[i]);
    if(s_hammer_vy[i]<7)s_hammer_vy[i]++;
    if(s_hammer_y[i]>GROUND_TOP || HammerHitsSolid(old_hammer_x,s_hammer_x[i],s_hammer_y[i]) ||
       s_hammer_x[i]-s_camera<-12 || s_hammer_x[i]-s_camera>140){
     s_hammer_active[i]=0U;continue;
    }
    if(s_pipe_invuln_ms==0U && s_hammer_x[i]+6>s_camera+MARIO_X &&
       s_hammer_x[i]<s_camera+MARIO_X+MARIO_W &&
       s_hammer_y[i]+8>s_mario_y && s_hammer_y[i]<s_mario_y+MARIO_H){
     s_hammer_active[i]=0U;
     if(s_star_ms==0U && s_invuln_ms==0U)HitByEnemy();
    }
   }
   for(i=0U;i<BOSS_FIREBALL_COUNT;i++)if(s_boss_fire_active[i]){
    int16_t old_x=s_boss_fire_x[i];
    s_boss_fire_x[i]=(int16_t)(s_boss_fire_x[i]+s_boss_fire_vx[i]);
    if((++s_boss_fire_phase[i]&3U)==0U)s_boss_fire_y[i]=(int16_t)(s_boss_fire_y[i]+s_boss_fire_vy[i]);
    if(s_boss_fire_y[i]<s_boss_y+2)s_boss_fire_vy[i]=1;
    if(s_boss_fire_y[i]>s_boss_y+12)s_boss_fire_vy[i]=-1;
    if((!IsCastleLevel() && FireballHitsSolid(old_x,s_boss_fire_x[i],s_boss_fire_y[i])) ||
       s_boss_fire_x[i]<0 || s_boss_fire_x[i]>WorldLength()){
     s_boss_fire_active[i]=0U;continue;
    }
    if(s_boss_fire_x[i]+6>s_camera+MARIO_X && s_boss_fire_x[i]<s_camera+MARIO_X+MARIO_W &&
       s_boss_fire_y[i]+5>s_mario_y && s_boss_fire_y[i]<s_mario_y+MARIO_H){
     s_boss_fire_active[i]=0U;
     if(s_star_ms==0U && s_invuln_ms==0U)HitByEnemy();
    }
   }
   ex=(int16_t)(s_boss_x-s_camera);if(s_pipe_invuln_ms==0U && MARIO_X+MARIO_W>ex && MARIO_X<ex+18 && s_mario_y+MARIO_H>s_boss_y && s_mario_y<s_boss_y+16){
     if(s_star_ms>0U){BeginBossFall();}
     else if(s_velocity_y>=0 && old_bottom<=s_boss_y+3){s_velocity_y=-5;s_grounded=0U;s_on_platform=0U;}
     else HitByEnemy();
    }
  }
  /* 两个火球分别移动、离屏回收，并依次检查怪物和食人花碰撞。 */
  {
   uint8_t b;
   for(b=0;b<FIREBALL_COUNT;b++)if(s_fireball_active[b]){
    uint8_t hit=0U;
    int16_t old_fireball_x=s_fireball_x[b];
    s_fireball_x[b]+=(int16_t)(s_fireball_dir[b]*8);
    /* 碰到世界边界、水管、砖墙、阶梯或电梯侧面时，火球立即消失。 */
    if(FireballHitsSolid(old_fireball_x,s_fireball_x[b],s_fireball_y[b])){s_fireball_active[b]=0U;continue;}
    /* 超出 OLED 可视区即释放槽位，下一次按键可再次使用。 */
    if(s_fireball_x[b]-s_camera < -5 || s_fireball_x[b]-s_camera > 133){s_fireball_active[b]=0U;continue;}
    for(i=0;i<ENEMY_COUNT;i++)if(s_enemy_alive[i] && s_fireball_x[b]>=s_enemy_x[i]-4 && s_fireball_x[b]<=s_enemy_x[i]+14 && s_fireball_y[b]+4>=s_enemy_y[i] && s_fireball_y[b]<=s_enemy_y[i]+7){s_enemy_alive[i]=0U;hit=1U;break;}
    if(!hit)for(i=0;i<TURTLE_COUNT;i++)if(s_turtle_alive[i] && s_turtle_state[i]!=2U && s_fireball_x[b]>=s_turtle_x[i]-4 && s_fireball_x[b]<=s_turtle_x[i]+16 && s_fireball_y[b]+4>=s_turtle_y[i] && s_fireball_y[b]<=s_turtle_y[i]+TURTLE_H){s_turtle_alive[i]=0U;hit=1U;break;}
    /* 水下水母可被火球击杀；与玩家接触仍会造成伤害。 */
    if(!hit && IsUnderwaterLevel())for(i=0;i<JELLY_COUNT;i++)if(s_jelly_alive[i] && s_fireball_x[b]>=s_jelly_x[i]-4 && s_fireball_x[b]<=s_jelly_x[i]+14 && s_fireball_y[b]+4>=s_jelly_y[i] && s_fireball_y[b]<=s_jelly_y[i]+10){s_jelly_alive[i]=0U;hit=1U;break;}
    /* 2-3 不再配置锤子兄弟。 */
    if(!hit)for(i=0;i<2;i++)if(s_fly_turtle_alive[i] && s_fireball_x[b]>=s_fly_turtle_x[i]-4 && s_fireball_x[b]<=s_fly_turtle_x[i]+16 && s_fireball_y[b]+4>=s_fly_turtle_y[i] && s_fireball_y[b]<=s_fly_turtle_y[i]+12){ConvertFlyingKoopaToTurtle(i);hit=1U;break;}
    if(!hit && s_level==7U)for(i=0U;i<FISH_COUNT;i++)if(s_fish_alive[i] && s_fish_y[i]<60 &&
       s_fireball_x[b]>=s_fish_x[i]-4 && s_fireball_x[b]<=s_fish_x[i]+14 &&
       s_fireball_y[b]+4>=s_fish_y[i] && s_fireball_y[b]<=s_fish_y[i]+8){s_fish_alive[i]=0U;s_fish_respawn_frames[i]=30U;hit=1U;break;}
    if(!hit && s_level==3U)for(i=0;i<HEDGEHOG_COUNT;i++)if(s_hedgehog_alive[i] && s_fireball_x[b]>=s_hedgehog_x[i]-4 && s_fireball_x[b]<=s_hedgehog_x[i]+16 && s_fireball_y[b]+4>=45 && s_fireball_y[b]<=58){s_hedgehog_alive[i]=0U;hit=1U;break;}
    if(!hit && s_level==5U)for(i=0U;i<HAMMER_BRO_COUNT;i++)if(s_hammer_bro_alive[i] &&
       s_fireball_x[b]>=s_hammer_bro_start[i]-4 && s_fireball_x[b]<=s_hammer_bro_start[i]+17 &&
       s_fireball_y[b]+4>=s_hammer_bro_y[i] && s_fireball_y[b]<=s_hammer_bro_y[i]+15){s_hammer_bro_alive[i]=0U;hit=1U;break;}
    /* 火球击中食人花后设置永久死亡标志，本关重置前不再从管道出现。 */
    if(!hit)for(i=0;i<PIPE_COUNT;i++)if(!s_plant_dead[i] && s_level!=2U && s_level!=4U && s_level!=6U && s_level!=7U && s_level!=8U && !IsCastleLevel()){
     int16_t px=PipeX(i);
     if(s_fireball_x[b]>=px-2 && s_fireball_x[b]<=px+18 && s_fireball_y[b]+4>=PiranhaY(i) && s_fireball_y[b]<=PiranhaY(i)+10){s_plant_dead[i]=1U;hit=1U;StartGameSfx(kick_sfx,(uint8_t)(sizeof(kick_sfx)/sizeof(kick_sfx[0])));break;}
    }
    if(!hit && IsCastleLevel() && !s_boss_defeated && !s_boss_falling && s_fireball_x[b]>s_boss_x-8 && s_fireball_x[b]<s_boss_x+24 && s_fireball_y[b]+4>=s_boss_y && s_fireball_y[b]<=s_boss_y+16){
     if(s_boss_hp>0U)s_boss_hp--;
     if(s_boss_hp==0U){DefeatBossByFireball();}
     else StartGameSfx(kick_sfx,(uint8_t)(sizeof(kick_sfx)/sizeof(kick_sfx[0])));
     hit=1U;
    }
    if(hit){
     s_fireball_active[b]=0U;
     /* 普通敌人被火球击中时播放踢击/消灭音效；植物和 Boss 已有专用音效。 */
     if(!s_sfx_active)StartGameSfx(kick_sfx,(uint8_t)(sizeof(kick_sfx)/sizeof(kick_sfx[0])));
    }
   }
  }
  TryEnterPipe();
  if(s_state==0U && IsHorizontalGoalPipeLevel() && s_direction==0U &&
     s_camera>=WorldLength()-128 && s_grounded){
   s_state=16U;s_state_ms=0U;s_mario_draw_x=MARIO_X;
   StartGameSfx(pipe_enter_sfx,(uint8_t)(sizeof(pipe_enter_sfx)/sizeof(pipe_enter_sfx[0])));
  }
  if(s_state==0 && s_down_latch) s_down_latch=0; /* one attempt per press */
  if(s_direction==0 && s_camera>=WorldLength()-128 && s_state==0 && !IsHorizontalGoalPipeLevel() &&
     (!IsCastleLevel() || s_boss_defeated) &&
     (int16_t)(s_camera+MARIO_X+MARIO_W)>=GoalX()-2 &&
     (int16_t)(s_camera+MARIO_X)<=GoalX()+8){
   s_state_ms=0U;
   if(!IsCastleLevel()){
    int16_t pole_screen=(int16_t)(GoalX()-s_camera);
    /* 对齐旗杆中心；把角色限制在屏幕内，防止滑落动画时被边缘裁切。 */
    s_mario_draw_x=(int16_t)(pole_screen-5);
    if(s_mario_draw_x<0)s_mario_draw_x=0;
    if(s_mario_draw_x>117)s_mario_draw_x=117;
    s_direction=0U;
    if(s_mario_y>(GROUND_TOP-MARIO_H))s_mario_y=(GROUND_TOP-MARIO_H);
       s_flag_pole_y=16;
    s_velocity_y=0;
    s_grounded=0U;
    s_on_platform=0U;
    s_state=12U; /* 先从当前高度滑到地面，再切换到向城堡行走状态。 */
    StartGameSfx(flag_slide_sfx,(uint8_t)(sizeof(flag_slide_sfx)/sizeof(flag_slide_sfx[0])));
   }else{
    /* 城堡关在击败 Boss 后以公主为终点；先落到地面，再开始自动走向公主。 */
    s_mario_y=(int16_t)(GROUND_TOP-MARIO_H);s_velocity_y=0;
    s_grounded=1U;s_on_platform=0U;
    s_state=7U;s_state_ms=0U;
    s_mario_draw_x=MARIO_X;
   }
  }
 }
 if(s_state==8U){
  char lives_text[2]={(char)('0'+(s_lives%10U)),'\0'};
  /* 死亡摘要也完全使用图形帧缓冲，避免先清屏再用字符接口写入造成周期性闪黑。 */
  OLED_GFX_Clear();
  DrawTinyString(27,20,LevelName());
  DrawTinyString(48,38,"UP");
  DrawTinyString(60,38,lives_text);
  OLED_GFX_Refresh();
  s_scene_dirty=0U;
  return;
 }
 DrawScene();
 OLED_GFX_Refresh();
 s_scene_dirty=0U;
 /* HUD、通关提示和选关文字均在 DrawScene() 中一次性合成后统一刷新。 */
}
/*
 * 非零表示背景音乐调度器必须让出 PA0：包括正在播放 SFX，
 * 以及必须保持静音的 1 秒死亡摘要界面（s_state==8）。
 */
uint8_t GameScene_SfxActive(void){return (s_sfx_active || s_state==8U || s_state==15U || s_state==16U || s_state==17U) ? 1U : 0U;}
uint8_t GameScene_JumpSfxActive(void){return (s_sfx_active && s_sfx_is_jump) ? 1U : 0U;}

/* PA1 暂停时主程序必须停止背景音乐时钟并保持蜂鸣器静音。 */
uint8_t GameScene_AudioPaused(void){return (s_state==10U || s_state==17U) ? 1U : 0U;}

/* 主程序读取一次性事件；返回 1 表示死亡后需要从头播放背景音乐。 */
uint8_t GameScene_TakeMusicRestartRequest(void)
{
 uint8_t request=s_music_restart_request;
 s_music_restart_request=0U;
 return request;
}

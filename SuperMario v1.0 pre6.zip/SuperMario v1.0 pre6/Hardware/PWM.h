/* PA0/TIM2_CH1 无源蜂鸣器接口。 */
#ifndef __PWM_H
#define __PWM_H

#include "stm32f10x.h"
#include <stdint.h>

/* TIM2_CH1/PA0 无源蜂鸣器：输入频率（Hz）产生方波，Stop 关闭输出。 */
void PWM_Init(void);
void PWM_SetFrequency(uint32_t frequency_hz);
void PWM_Stop(void);

#endif
